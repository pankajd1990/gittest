import { NgControl } from '@angular/forms';
import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
    selector: '[TextUpperCase]'
})

export class UpperCaseDirective {

    private el: HTMLInputElement;

    constructor(private elRef: ElementRef, private control: NgControl) {
        this.el = this.elRef.nativeElement;
    }

    ngOnInit() {
        if (this.el.value) {
            this.el.value = (this.el.value.toUpperCase());
        } else {
            this.el.value = '';
            this.control.control.setValue('');
        }
    }

    @HostListener('change', ['$event']) onchange(value) {
        if (this.el.value) {
            try {
                var upper = this.el.value.toUpperCase();
                this.el.value = upper;
                this.control.control.setValue(upper)
            } catch (error) {
                
            }
        } else {
            this.el.value = '';
            this.control.control.setValue('');
        }
    }

}