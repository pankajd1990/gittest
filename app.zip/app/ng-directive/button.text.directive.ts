import { Directive, ElementRef, AfterViewInit } from '@angular/core';

@Directive({
    selector: '[ButtonText]'
})

export class ButtonTextDirective implements AfterViewInit {

    constructor(private elRef: ElementRef) { }

    ngAfterViewInit(): void {
        var htmlText = '';
        var buttonText = this.elRef.nativeElement.innerText;
        switch (buttonText) {
            case 'Ok':
                htmlText = '<u>O</u>k';
                break;
            case 'Search':
                htmlText = '<u>S</u>earch';
                break;
            case 'Clear':
                htmlText = 'Cl<u>e</u>ar';
                break;
            case 'Add':
                htmlText = '<u>A</u>dd';
                break;
            case 'Modify':
                htmlText = '<u>M</u>odify';
                break;
            case 'Submit':
                htmlText = 'S<u>u</u>bmit';
                break;
            case 'Close':
                htmlText = 'C<u>l</u>ose';
                break;
            case 'Refresh':
                htmlText = '<u>R</u>efresh';
                break;
            case 'Policy':
                htmlText = 'Polic<u>y</u>';
                break;
            case 'Cancel':
                htmlText = '<u>C</u>ancel';
                break;
            case 'Initiate':
                htmlText = 'I<u>n</u>itiate';
                break;
            case 'Display':
                htmlText = 'Dis<u>p</u>lay';
                break;    
            case 'Save':
                htmlText = '<u>S</u>ave';
                break;
            case 'Delete':
                htmlText = '<u>D</u>elete';
                break;
            case 'OK':
                htmlText = '<u>O</u>K';
                break;
        }
        this.elRef.nativeElement.innerHTML = htmlText;
    }

}