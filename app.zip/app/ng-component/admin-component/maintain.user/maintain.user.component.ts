import { Subscription } from 'rxjs/Subscription';
import { GridOptions, GridApi } from 'ag-grid';
import { Component, OnInit, ViewChild, Renderer } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import Util from '../../../ng-utility/util';
import { CONSTANT } from '../../../ng-utility/ng.constant';
import { GridColumnDefs } from '../../../ng-utility/grid.config';
import { MessageConstant } from '../../../ng-utility/ng.message.constant';

import { GenericComponent } from '../../generic-component/misc-component/generic.component';
import { RestService, Command } from '../../../ng-service/rest.service';
import {EncrDecrService} from '../../../ng-service/encr-decr.service';

@Component({
  templateUrl: './maintain.user.component.html'
})

export class MaintainUserComponent implements OnInit {

  private searchForm: FormGroup;
  private actionForm: FormGroup;
  private subscription: Subscription;
  private addSubscription: Subscription;
  private modSubscription: Subscription;

  public searchUserName: any;
  public userTypeLov: any;
  public userGroupNumLov: any;
  public userStatusLov: any;
  public userAuthTypeLov: any;
  public userTypeLovData: any = [];
  public userGroupNumLovData: any = [];
  public userStatusLovData: any = [];
  public userAuthTypeLovData: any = [];

  public gridApiUser: GridApi;
  public gridOptionsUser: GridOptions;

  private dataSize: number;
  private requestData: any = {};
  private paginationData: any = {};

  constructor(private restService: RestService, public genericComponent: GenericComponent, private EncrDecr: EncrDecrService) {
    this.subscription = this.restService.commands.subscribe(c => this.handleCommand(c));
    this.addSubscription = this.genericComponent.addRecordCall$.subscribe(data => this.addRecordEvent(data));
    this.modSubscription = this.genericComponent.modifyRecordCall$.subscribe(data => this.modifyRecordEvent(data));
    this.gridOptionsUser = {
      rowData: [],
      floatingFilter: true,
      columnDefs: GridColumnDefs.MaintainUser
    };
  }

  handleCommand = (command: Command) => {
    switch (command.name) {
      case 'Search': this.searchButtonClickEvent(this.searchForm); break;
      case 'Clear': this.clearButtonClickEvent(); break;
      case 'Add': this.addButtonClickEvent(); break;
      case 'Modify': this.modifyButtonClickEvent(); break;
      case 'Submit': this.genericComponent.submitButtonClickEvent(this.actionForm); break;
      case 'Close': this.cancelButtonClickEvent(); break;
    }
  }

  get f() {
    return this.actionForm.controls;
  }

  ngOnInit() {
    this.genericComponent.initOpenForm();
    this.searchForm = new FormGroup({
      uadUserId: new FormControl()
    });
    this.actionForm = new FormGroup({
      uadUserId: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z0-9_]+$')]),
      uadUserFirstName: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]),
      uadUserLastName: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]),
      uadUserEmail: new FormControl('', [Validators.required, Validators.pattern('^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$')]),
      uadUserType: new FormControl('', Validators.required),
      uadUserGroupNum: new FormControl('', Validators.required),
      uadUserStatus: new FormControl('', Validators.required),
      uadUserAuthType: new FormControl('', Validators.required)
    });
    this.restService.postRequest('getAllUserName').subscribe(data => { this.getAllUserCallBack(data) });
  }

  private getAllUserCallBack(data) {
    if (Util.checkResponse(data)) {
      this.searchUserName = JSON.parse(data.resultData);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public searchButtonClickEvent(form: FormGroup) {
    this.genericComponent.resetTransactionForm();
    this.requestData = {
      uadUserNum: form.value.uadUserId != null ? form.value.uadUserId.key : null
    };
    this.restService.postRequestWithParamater('searchUserCountDetail', this.requestData).subscribe(data => { this.searchUserCountCallBack(data) });
  }

  private searchUserCountCallBack(data) {
    if (Util.checkResponse(data)) {
      this.dataSize = data.resultData;
      this.searchMaintainUserData(1);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  private searchMaintainUserData(pageNum: number) {
    this.requestData.pageSize = CONSTANT.GridPagination.RecordPerPage;
    this.requestData.from = pageNum == 1 ? 0 : ((pageNum - 1) * CONSTANT.GridPagination.RecordPerPage);
    this.paginationData = {};
    this.restService.postRequestWithParamater('searchUserDetail', this.requestData).subscribe(data => { this.searchButtonCallBack(data, pageNum) });
  }

  private searchButtonCallBack(data, pageNum: number) {
    if (Util.checkResponse(data)) {
      this.gridOptionsUser.api.setRowData(data.resultData);
      this.paginationData = this.genericComponent.setPagination({}, pageNum, this.dataSize);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public clearButtonClickEvent() {
    this.paginationData = {};
    this.searchForm.reset();
    this.gridOptionsUser.api.setRowData([]);
    this.genericComponent.resetTransactionForm();
  }

  public addButtonClickEvent() {
    this.actionForm.reset();
    this.genericComponent.openAddForm();
    this.getUserLovData();
  }

  public modifyButtonClickEvent() {
    this.actionForm.reset();
    if (this.genericComponent.checkModifyRecordSelection(this.gridApiUser)) {
      this.genericComponent.openModForm();
      this.getUserLovData();
    }else{
      this.genericComponent.showWarningMessage(MessageConstant.MarketWatch.RowToModify);
    }
  }

  private getUserLovData() {
    this.restService.postRequest('getUserLovData').subscribe(data => { this.getUserLovDataCallBack(data) });
  }

  private getUserLovDataCallBack(data) {
    if (Util.checkResponse(data)) {
      this.userTypeLov = JSON.parse(data.resultData.userType);
      this.userGroupNumLov = JSON.parse(data.resultData.userGroup);
      this.userStatusLov = JSON.parse(data.resultData.userStatus);
      this.userAuthTypeLov = JSON.parse(data.resultData.userAuthType);
      this.userTypeLovData = JSON.parse(data.resultData.userType);
      this.userGroupNumLovData = JSON.parse(data.resultData.userGroup);
      this.userStatusLovData = JSON.parse(data.resultData.userStatus);
      this.userAuthTypeLovData = JSON.parse(data.resultData.userAuthType);
      if (!this.genericComponent.transactionFlag) {
        var rowData = this.gridApiUser.getSelectedRows()[0];
        this.fillForm(rowData, this.actionForm);
      }
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  private fillForm(data, form: FormGroup) {
    if (data) {
      let textFieldArray: Array<string> = ['uadUserId', 'uadUserFirstName', 'uadUserLastName', 'uadUserEmail'];
      Object.keys(form.value).forEach(name => {
        if (textFieldArray.includes(name)) {
          form.controls[name].setValue(data[name]);
        } else {
          switch (name) {
            case 'uadUserType':
              form.controls[name].setValue(this.userTypeLovData.find(x => x.key == data[name]));
              break;
            case 'uadUserGroupNum':
              form.controls[name].setValue(this.userGroupNumLovData.find(x => x.key == data[name]));
              break;
            case 'uadUserStatus':
              form.controls[name].setValue(this.userStatusLovData.find(x => x.key == data[name]));
              break;
            case 'uadUserAuthType':
              form.controls[name].setValue(this.userAuthTypeLovData.find(x => x.key == data[name]));
              break;
          }
        }
      });
    }
  }

  private addRecordEvent(form) {
    var jsonData = {
      uadUserNum: this.gridApiUser.getSelectedRows().length > 0 ? this.gridApiUser.getSelectedRows()[0].uadUserNum : null,
      uadUserId: form.value.uadUserId,
      uadUserFirstName: form.value.uadUserFirstName,
      uadUserLastName: form.value.uadUserLastName,
      uadUserEmail: form.value.uadUserEmail,
      uadUserType: form.value.uadUserType != null ? form.value.uadUserType.key : null,
      uadUserGroupNum: form.value.uadUserGroupNum != null ? form.value.uadUserGroupNum.key : null,
      uadUserStatus: form.value.uadUserStatus != null ? form.value.uadUserStatus.key : null,
      uadUserAuthType: form.value.uadUserAuthType != null ? form.value.uadUserAuthType.key : null
    };
    this.restService.postRequestWithParamater('addUserDetail', jsonData).subscribe(data => { this.transactionEventCallBack(data) });
  }

  private modifyRecordEvent(form) {
    var jsonData = {
      uadUserNum: this.gridApiUser.getSelectedRows().length > 0 ? this.gridApiUser.getSelectedRows()[0].uadUserNum : null,
      uadUserId: form.value.uadUserId,
      uadUserFirstName: form.value.uadUserFirstName,
      uadUserLastName: form.value.uadUserLastName,
      uadUserEmail: form.value.uadUserEmail,
      uadUserType: form.value.uadUserType != null ? form.value.uadUserType.key : null,
      uadUserGroupNum: form.value.uadUserGroupNum != null ? form.value.uadUserGroupNum.key : null,
      uadUserStatus: form.value.uadUserStatus != null ? form.value.uadUserStatus.key : null,
      uadUserAuthType: form.value.uadUserAuthType != null ? form.value.uadUserAuthType.key : null
    };
    this.restService.postRequestWithParamater('modifyUserDetail', jsonData).subscribe(data => { this.transactionEventCallBack(data) });
  }

  private transactionEventCallBack(data) {
    if (Util.checkResponse(data)) {
      this.genericComponent.showSuccessMessage(data.responseMsg);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public cancelButtonClickEvent() {
    this.genericComponent.clearMessages();
    this.genericComponent.resetTransactionForm();
  }

  public onGridReadyUser(params) {
    this.gridApiUser = params.api;
  }

  public ngOnDestroy() {
    this.addSubscription.unsubscribe();
    this.modSubscription.unsubscribe();
  }

}