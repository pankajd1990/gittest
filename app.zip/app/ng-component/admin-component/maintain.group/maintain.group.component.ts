import { Subscription } from 'rxjs/Subscription';
import { GridOptions, GridApi } from 'ag-grid';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, ViewChild, Renderer, OnDestroy } from '@angular/core';

import Util from '../../../ng-utility/util';
import { CONSTANT } from '../../../ng-utility/ng.constant';
import { GridColumnDefs } from '../../../ng-utility/grid.config';
import { MessageConstant } from '../../../ng-utility/ng.message.constant';

import { RestService, Command } from '../../../ng-service/rest.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';
import { DataShareService } from '../../../ng-service/data.share.service';

@Component({
  templateUrl: './maintain.group.component.html'
})

export class MaintainGroupComponent implements OnInit, OnDestroy {

  private searchForm: FormGroup;
  private actionForm: FormGroup;
  private subscription: Subscription;
  private addSubscription: Subscription;
  private modSubscription: Subscription;

  private groupName: any;
  private userParentGroup: any;
  private parentGroupNumData: any = [];

  private gridApiGroup: GridApi;
  private gridOptionsGroup: GridOptions;

  private dataSize: number;
  private requestData: any = {};
  private paginationData: any = {};

  constructor(private restService: RestService, public genericComponent: GenericComponent) {

    this.subscription = this.restService.commands.subscribe(c => this.handleCommand(c));
    this.addSubscription = this.genericComponent.addRecordCall$.subscribe(data => this.addRecordEvent(data));
    this.modSubscription = this.genericComponent.modifyRecordCall$.subscribe(data => this.modifyRecordEvent(data));

    this.gridOptionsGroup = {
      rowData: [],
      floatingFilter: true,
      columnDefs: GridColumnDefs.MaintainGroup
    };

  }

  handleCommand = (command: Command) => {
    switch (command.name) {
      case 'Search': this.searchButtonClickEvent(this.searchForm); break;
      case 'Clear': this.clearButtonClickEvent(); break;
      case 'Add': this.addButtonClickEvent(); break;
      case 'Modify': this.modifyButtonClickEvent(); break;
      case 'Submit': this.genericComponent.submitButtonClickEvent(this.actionForm); break;
      case 'Close': this.cancelButtonClickEvent(); break;
    }
  }

  get f() {
    return this.actionForm.controls;
  }

  ngOnInit() {
    this.genericComponent.initOpenForm();
    this.searchForm = new FormGroup({
      uadUserGroupName: new FormControl()
    });
    this.actionForm = new FormGroup({
      uadUserGroupNum: new FormControl(),
      uadUserGroupName: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]),
      uadUserParentGroupNum: new FormControl('', Validators.required),
      uadQueryNotallwdWrkngDays: new FormControl('', Validators.required),
      uadUpdtDate : new FormControl()
    });
    this.restService.postRequest('getAllUserGroups').subscribe(data => { this.getAllGroupsCallBack(data) });
  }

  private getAllGroupsCallBack(data) {
    if (Util.checkResponse(data)) {
      this.groupName = JSON.parse(data.resultData);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public searchButtonClickEvent(form: FormGroup) {
    this.genericComponent.resetTransactionForm();
    this.requestData = {};
    this.requestData.uadUserGroupNum = form.value.uadUserGroupName != null ? form.value.uadUserGroupName.key : null
    this.gridOptionsGroup.api.setRowData([]);
    this.restService.postRequestWithParamater('searchUserGroupsCount', this.requestData).subscribe(data => { this.searchUserGroupsCountCallback(data) });
  }

  private searchUserGroupsCountCallback(data) {
    if (Util.checkResponse(data)) {
      this.dataSize = data.resultData;
      this.searchMaintainGroupData(1);
    } else {
      this.genericComponent.showErrorMessage(MessageConstant.ErrorMessage.NoDataFound);
    }
  }

  public searchMaintainGroupData(pageNum: number) {
    this.requestData.pageSize = CONSTANT.GridPagination.RecordPerPage;
    this.requestData.from = pageNum == 1 ? 0 : ((pageNum - 1) * CONSTANT.GridPagination.RecordPerPage);
    this.paginationData = {};
    this.restService.postRequestWithParamater('searchUserGroupsData', this.requestData).subscribe(data => { this.searchButtonCallBack(data, pageNum) });
  }

  private searchButtonCallBack(data, pageNum: number) {
    if (Util.checkResponse(data)) {
      this.gridOptionsGroup.api.setRowData(data.resultData);
      this.paginationData = this.genericComponent.setPagination({}, pageNum, this.dataSize);
    } else {
      this.genericComponent.showErrorMessage(MessageConstant.ErrorMessage.NoDataFound);
    }
  }

  public clearButtonClickEvent() {
    this.searchForm.reset();
    this.genericComponent.resetTransactionForm();
    this.gridOptionsGroup.api.setRowData([]);
    this.paginationData = {};
  }

  public addButtonClickEvent() {
    this.actionForm.reset();
    this.genericComponent.openAddForm();
    this.restService.postRequest('getAllParentGroup').subscribe(data => {
      if (Util.checkResponse(data)) {
        this.userParentGroup = JSON.parse(data.resultData);
        this.parentGroupNumData = JSON.parse(data.resultData);
      } else {
        this.genericComponent.showErrorMessage(data.responseMsg);
      }
    });
  }

  public modifyButtonClickEvent() {
    this.actionForm.reset();
    if (this.genericComponent.checkModifyRecordSelection(this.gridApiGroup)) {
      this.genericComponent.openModForm();
      this.restService.postRequest('getAllParentGroup').subscribe(data => {
        if (Util.checkResponse(data)) {
          this.userParentGroup = JSON.parse(data.resultData);
          this.parentGroupNumData = JSON.parse(data.resultData);
          var rowData = this.gridApiGroup.getSelectedRows()[0];
          this.fillForm(rowData, this.actionForm);
        } else {
          this.genericComponent.showErrorMessage(data.responseMsg);
        }
      });
    }else{
      this.genericComponent.showWarningMessage(MessageConstant.MarketWatch.RowToModify);
    }
  }

  private fillForm(data, form: FormGroup) {
    if (data) {
      Object.keys(form.value).forEach(name => {
        if (name == 'uadUserGroupName') {
          form.controls[name].setValue(data[name]);
        } else if (name == 'uadUserParentGroupNum') {
          form.controls[name].setValue(this.parentGroupNumData.find(x => x.key == data[name]));
        } else {
          form.controls[name].setValue(data[name]);
        }
      });
    }
  }

  private addRecordEvent(form) {
    let jsonData = {
      uadUserGroupName: form.value.uadUserGroupName,
      uadUserParentGroupNum: form.value.uadUserParentGroupNum != null ? form.value.uadUserParentGroupNum.key : null,
      uadQueryNotallwdWrkngDays: form.value.uadQueryNotallwdWrkngDays
    };
    this.restService.postRequestWithParamater('addUserGroup', jsonData).subscribe(data => { this.transactionEventCallBack(data) });
  }

  private modifyRecordEvent(form) {
    let jsonData = {
      uadUserGroupNum: form.value.uadUserGroupNum,
      uadUserGroupName: form.value.uadUserGroupName,
      uadUserParentGroupNum: form.value.uadUserParentGroupNum != null ? form.value.uadUserParentGroupNum.key : null,
      uadQueryNotallwdWrkngDays: form.value.uadQueryNotallwdWrkngDays,
      uadUpdtDate: form.value.uadUpdtDate,
    };
    this.restService.postRequestWithParamater('modifyUserGroup', jsonData).subscribe(data => { this.transactionEventCallBack(data) });
  }

  private transactionEventCallBack(data) {
    if (Util.checkResponse(data)) {
      this.genericComponent.showSuccessMessage(data.responseMsg);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public cancelButtonClickEvent() {
    this.genericComponent.clearMessages();
    this.genericComponent.resetTransactionForm();
  }

  public onGridReadyGroup(params) {
    params.api.sizeColumnsToFit();
    this.gridApiGroup = params.api;
  }

  public ngOnDestroy() {
    this.addSubscription.unsubscribe();
    this.modSubscription.unsubscribe();
  }

}