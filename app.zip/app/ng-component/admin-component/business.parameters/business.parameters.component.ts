import * as moment from 'moment';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common'
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import Util from '../../../ng-utility/util';
import { RestService } from '../../../ng-service/rest.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';

@Component({
    templateUrl: './business.parameters.component.html'
})

export class BusinessParametersComponent implements OnInit {

    public businessForm: FormGroup;

    constructor(private router: Router, public genericComponent: GenericComponent, private restService: RestService) { }

    ngOnInit() {
        this.genericComponent.initOpenForm();
        this.businessForm = new FormGroup({
            bsdtSegInd: new FormControl(),
            bsdtSystemStat: new FormControl(),
            bsdtCurrBussDate: new FormControl(),
            bsdtPrevBussDate: new FormControl(),
            bsdtNextBussDate: new FormControl(),
        });
        this.restService.postRequest('getBusinessParameters').subscribe(data => { this.getBusinessParametersCallBack(data) });
    }

    getBusinessParametersCallBack(data) {
        if (Util.checkResponse(data)) {
            this.fillForm(data.resultData, this.businessForm);
        } else {
            this.genericComponent.showErrorMessage(data.responseMsg);
        }
    }

    fillForm(data, form: FormGroup) {
        if (data) {
            Object.keys(form.value).forEach(name => {
                if (name === 'bsdtPrevBussDate' || name === 'bsdtCurrBussDate' || name === 'bsdtNextBussDate') {
                    form.controls[name].setValue(moment(data[name]).format('DD-MMM-YYYY'));
                } else {
                    form.controls[name].setValue(data[name]);
                }
            });
        }
    }

}