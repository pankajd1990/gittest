import { TreeviewItem } from 'ngx-treeview';
import { Subscription } from 'rxjs/Subscription';
import { Component, OnInit, Renderer } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import Util from '../../../ng-utility/util';
import { RestService, Command } from '../../../ng-service/rest.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';

@Component({
  templateUrl: './map.role.menu.component.html',
})

export class MapRoleMenuComponent implements OnInit {

  private subscription: Subscription;
  private searchMapRoleMenuForm: FormGroup;

  private ids: any;
  private roleName: any;
  private items: TreeviewItem[];

  constructor(public restService: RestService, public genericComponent: GenericComponent) {
    this.subscription = this.restService.commands.subscribe(c => this.handleCommand(c));
  }

  handleCommand = (command: Command) => {
    switch (command.name) {
      case 'Search': this.searchButtonClickEvent(this.searchMapRoleMenuForm); break;
      case 'Modify': this.modifyButtonClickEvent(this.searchMapRoleMenuForm); break;
      case 'Clear': this.clearButtonClickEvent(); break;
    }
  }

  ngOnInit() {
    this.genericComponent.initOpenForm();
    this.searchMapRoleMenuForm = new FormGroup({
      roleNameDesc: new FormControl('', Validators.required)
    });
    this.restService.postRequest('loadAllRoles').subscribe(data => { this.loadAllRolesCallBack(data) });
  }

  private loadAllRolesCallBack(data) {
    if (Util.checkResponse(data)) {
      this.roleName = JSON.parse(data.resultData);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public roleNameDropDownClickEvent() {
    this.items = [];
    this.genericComponent.clearMessages();
  }

  public searchButtonClickEvent(form: FormGroup) {
    this.genericComponent.clearMessages();
    if(!form.valid){
      return;
    }
    var jSonData = {
      roleNum: form.value.roleNameDesc.key,
    }
    this.restService.postRequestWithParamater('getMenuTree', jSonData).subscribe(data => { this.loadMenuTreeCallBack(data) });
  }

  private loadMenuTreeCallBack(data) {
    if (Util.checkResponse(data)) {
      const menuTreeList = JSON.parse(data.resultData);
      let menuTreeListObj: Array<TreeviewItem> = new Array();
      menuTreeList.forEach((x) => {
        menuTreeListObj.push(new TreeviewItem(x, false));
      });
      this.items = menuTreeListObj;
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public modifyButtonClickEvent(form: FormGroup) {
    this.genericComponent.clearMessages();
    this.ids = [];
    for (var i = 0; i < this.items.length; i++) {
      if (this.items[i].checked == true || this.items[i].checked == undefined) {
        this.ids.push(this.items[i].value);
        this.getChild(this.items[i]);
      }
    }
    var jSonData = {
      roleNum: form.value.roleNameDesc.key,
      menuSelected: this.ids
    };
    this.restService.postRequestWithParamater('modifyMapRoleMenu', jSonData).subscribe(data => { this.modifyButtonClickEventCallback(data) });
  }

  getChild(parent) {
    if (parent.internalChildren != undefined) {
      for (var i = 0; i < parent.internalChildren.length; i++) {
        if (parent.internalChildren[i].checked == true || parent.internalChildren[i].checked == undefined) {
          this.ids.push(parent.internalChildren[i].value);
          this.getChild(parent.internalChildren[i]);
        }
      }
    }
  }

  private modifyButtonClickEventCallback(data) {
    if (Util.checkResponse(data)) {
      this.genericComponent.showSuccessMessage(data.responseMsg);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public clearButtonClickEvent() {
    this.items = [];
    this.searchMapRoleMenuForm.reset();
    this.genericComponent.clearMessages();
  }

}