import { Subscription } from 'rxjs/Subscription';
import { RestService, Command } from '../../../ng-service/rest.service';
import { Component, OnInit, ViewChild, Renderer } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import Util from '../../../ng-utility/util';
import { MessageConstant } from '../../../ng-utility/ng.message.constant';

import { GenericComponent } from '../../generic-component/misc-component/generic.component';

@Component({
    selector: 'change-password',
    templateUrl: './change.password.component.html',
})

export class ChangePasswordComponent implements OnInit {

    private subscription: Subscription;
    private resetPasswordForm: FormGroup;
    private isError = false;

    constructor(private restService: RestService, private genericComponent: GenericComponent) {
        this.subscription = this.restService.commands.subscribe(c => this.handleCommand(c));
    }

    ngOnInit() {
        this.resetPasswordForm = new FormGroup({
            username: new FormControl('', Validators.required),
            resetPasswordOldPassword: new FormControl('', Validators.required),
            resetPasswordNewPassword: new FormControl('', Validators.required),
            resetPasswordConfirmPassword: new FormControl('', Validators.required),
        });
    }

    handleCommand = (command: Command) => {
        switch (command.name) {
            case 'Submit': this.submitResetPasswordForm(this.resetPasswordForm); break;
            case 'Policy': this.genericComponent.displayPasswordPolicy = true; break;
            case 'Ok': this.genericComponent.displayPasswordPolicy = false; break;
        }
    }

    get f() {
        return this.resetPasswordForm.controls;
    }

    onDialogClose() {
        this.isError = false;
        this.resetPasswordForm.reset();
    }

    submitResetPasswordForm(resetPasswordForm: FormGroup) {
        this.isError = true;
        if (this.resetPasswordForm.valid) {
            let oldPassword = resetPasswordForm.value.resetPasswordOldPassword != null ? resetPasswordForm.value.resetPasswordOldPassword : null;
            let newPassword = resetPasswordForm.value.resetPasswordNewPassword != null ? resetPasswordForm.value.resetPasswordNewPassword : null;
            let newCnfmPassword = resetPasswordForm.value.resetPasswordConfirmPassword != null ? resetPasswordForm.value.resetPasswordConfirmPassword : null;

            if (oldPassword === newPassword) {
                this.genericComponent.showErrorMessage(MessageConstant.ChangePassword.NewOldSame);
                return false;
            }

            if (newPassword !== newCnfmPassword) {
                this.genericComponent.showErrorMessage(MessageConstant.ChangePassword.NewConfirmNotSame);
                return false;
            }

            var jsonData = {
                username: this.genericComponent.psswrdUserId,
                oldPassword: resetPasswordForm.value.resetPasswordOldPassword != null ? resetPasswordForm.value.resetPasswordOldPassword : null,
                newPassword: resetPasswordForm.value.resetPasswordNewPassword != null ? resetPasswordForm.value.resetPasswordNewPassword : null,
            };
            this.restService.postRequestWithParamater('changePassword', jsonData).subscribe(data => { this.changePasswordCallBack(data) });
        }
    }

    changePasswordCallBack(data) {
        if (Util.checkResponse(data)) {
            this.genericComponent.displayResetPassword = false;
            this.genericComponent.displayPasswordPolicy = false;
            this.genericComponent.showSuccessMessage(data.responseMsg);
        } else {
            this.genericComponent.showErrorMessage(data.responseMsg);
        }
    }

    changePasswordShowEvent() {
        this.resetPasswordForm.reset();
        this.resetPasswordForm.controls['username'].setValue(this.genericComponent.psswrdUserId);
    }

}