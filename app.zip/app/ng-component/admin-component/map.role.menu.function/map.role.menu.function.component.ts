import { Subscription } from 'rxjs/Subscription';
import { GridOptions, GridApi, RowNode } from 'ag-grid';
import { Component, OnInit, ViewChild, Renderer } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import Util from '../../../ng-utility/util';
import { GridColumnDefs } from '../../../ng-utility/grid.config';

import { RestService, Command } from '../../../ng-service/rest.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';

@Component({
  templateUrl: './map.role.menu.function.component.html',
})

export class MapRoleMenuFunctionComponent implements OnInit {

  public searchForm: FormGroup;
  private subscription: Subscription;

  private roleDesc: any;
  private roleName: any;
  private menuName: any;

  private gridApiGroup: GridApi;
  private gridOptionsGroup: GridOptions;

  constructor(private restService: RestService, public genericComponent: GenericComponent) {
    this.subscription = this.restService.commands.subscribe(c => this.handleCommand(c));
    this.gridOptionsGroup = {
      rowData: [],
      columnDefs: GridColumnDefs.MapRoleMenuFunction,
    };
  }

  handleCommand = (command: Command) => {
    switch (command.name) {
      case 'Search': this.searchButtonClickEvent(this.searchForm); break;
      case 'Clear': this.clearButtonClickEvent(); break;
      case 'Modify': this.modifyButtonClickEvent(); break;
    }
  }

  get f() {
    return this.searchForm.controls;
  }

  ngOnInit() {
    this.genericComponent.initOpenForm();
    this.searchForm = new FormGroup({
      roleName: new FormControl('', Validators.required),
      menuName: new FormControl('', Validators.required),
    });
    this.restService.postRequest('getAllRoles').subscribe(data => { this.getAllRolesCallBack(data) });
  }

  private getAllRolesCallBack(data) {
    if (Util.checkResponse(data)) {
      this.roleName = JSON.parse(data.resultData);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public roleNameDropDownClickEvent(form: FormGroup) {
    var jsonData = {
      uadRoleNum: form.value.roleName != null ? form.value.roleName.value : null
    }
    this.restService.postRequestWithParamater('getMenuNames', jsonData).subscribe(data => { this.roleNameDropDownCallBack(data) });
  }

  private roleNameDropDownCallBack(data) {
    if (Util.checkResponse(data)) {
      this.menuName = JSON.parse(data.resultData);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public searchButtonClickEvent(form: FormGroup) {
    this.genericComponent.clearMessages();
    if (!this.searchForm.valid) {
      this.gridOptionsGroup.api.setRowData([]);
      return;
    }
    var jasonData = {
      roleNum: form.value.roleName != null ? form.value.roleName.value : null,
      menuNum: form.value.menuName != null ? form.value.menuName.value : null
    };
    this.restService.postRequestWithParamater('searchMapRoleMenuData', jasonData).subscribe(data => { this.searchButtonCallBack(data) });
  }

  private searchButtonCallBack(data) {
    if (Util.checkResponse(data)) {
      this.gridOptionsGroup.api.setRowData(data.resultData);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public clearButtonClickEvent() {
    this.searchForm.reset();
    this.genericComponent.clearMessages();
    this.gridOptionsGroup.api.setRowData([]);
  }

  public modifyButtonClickEvent() {
    this.genericComponent.clearMessages();
    var rowData = [];
    this.gridApiGroup.forEachNode(function (rowNode) {
      let data = rowNode.data;
      if (data.inquiry == null) {
        data.inquiry = false;
      }
      if (data.transaction == null) {
        data.transaction = false;
      }
      rowData.push(rowNode.data);
    });
    var jsonData = {
      roleNum: this.searchForm.value.roleName != null ? this.searchForm.value.roleName.value : null,
      listRoleMenuFun: rowData
    };
    this.restService.postRequestWithParamater('modifyRoleMenuFunction', jsonData).subscribe(data => { this.modifyButtonCallBack(data) });
  }

  private modifyButtonCallBack(data) {
    if (Util.checkResponse(data)) {
      this.genericComponent.showSuccessMessage(data.responseMsg);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public onGridReadyGroup(params) {
    params.api.sizeColumnsToFit();
    this.gridApiGroup = params.api;
  }

}