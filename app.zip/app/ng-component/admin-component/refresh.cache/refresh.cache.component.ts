import { Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { Component, OnInit, ViewChild, Renderer } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import Util from '../../../ng-utility/util';
import { RestService, Command } from '../../../ng-service/rest.service';
import { DataShareService } from '../../../ng-service/data.share.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';

@Component({
  templateUrl: './refresh.cache.component.html',
})

export class RefreshCacheComponent implements OnInit {

  private subscription: Subscription;
  private refreshCacheForm: FormGroup;

  constructor(private renderer: Renderer, private restService: RestService, public genericComponent: GenericComponent) {
    this.subscription = this.restService.commands.subscribe(c => this.handleCommand(c));
  }

  ngOnInit() {
    this.genericComponent.initOpenForm();
  }

  handleCommand = (command: Command) => {
    switch (command.name) {
      case 'Refresh': this.refreshCacheClickEvent(this.refreshCacheForm); break;
    }
  }

  refreshCacheClickEvent(form: FormGroup) {
    this.genericComponent.clearMessages();
    this.restService.postRequest('refreshSystemCache').subscribe(data => { this.refreshSystemCacheCallBack(data) });
  }

  refreshSystemCacheCallBack(data) {
    if (Util.checkResponse(data)) {
      this.genericComponent.showSuccessMessage(data.responseMsg);
      this.genericComponent.setBusinessDate(new Date(data.resultData.bsdtCurrBussDate));
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

}