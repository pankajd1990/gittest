import { Subscription } from 'rxjs/Subscription';
import { GridOptions, GridApi } from 'ag-grid';
import { Component, OnInit, Renderer } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import Util from '../../../ng-utility/util';
import { CONSTANT } from '../../../ng-utility/ng.constant';
import { GridColumnDefs } from '../../../ng-utility/grid.config';
import { MessageConstant } from '../../../ng-utility/ng.message.constant';

import { RestService, Command } from '../../../ng-service/rest.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';

@Component({
  templateUrl: './map.user.role.component.html'
})

export class MapUserRoleComponent implements OnInit {

  private userName: any;
  private subscription: Subscription;
  private searchForm: FormGroup;

  private gridApiUserRole: GridApi;
  private gridOptionsUserRole: GridOptions;

  private dataSize: number;
  private requestData: any = {};
  private paginationData: any = {};

  constructor(private restService: RestService, public genericComponent: GenericComponent) {
    this.subscription = this.restService.commands.subscribe(c => this.handleCommand(c));
    this.gridOptionsUserRole = {
      rowData: [],
      floatingFilter: true,
      columnDefs: GridColumnDefs.MaintainUserRole
    };
  }

  handleCommand = (command: Command) => {
    switch (command.name) {
      case 'Search': this.searchButtonClickEvent(this.searchForm); break;
      case 'Clear': this.clearButtonClickEvent(); break;
      case 'Modify': this.modifyButtonClickEvent(); break;
    }
  }

  ngOnInit() {
    this.genericComponent.initOpenForm();
    this.searchForm = new FormGroup({
      userName: new FormControl('', Validators.required)
    });
    this.restService.postRequest('getAllUserByUserGroupNum').subscribe(data => { this.getAllGroupsCallBack(data) });
  }

  private getAllGroupsCallBack(data) {
    if (Util.checkResponse(data)) {
      this.userName = JSON.parse(data.resultData);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public searchButtonClickEvent(form: FormGroup) {
    this.genericComponent.resetTransactionForm();
    if(!form.valid){
      return;
    }
    this.requestData = {};
    this.requestData.userId = form.value.userName != null ? form.value.userName.value : null
    this.gridOptionsUserRole.api.setRowData([]);
    this.restService.postRequestWithParamater('searchUserRoleCountDetails', this.requestData).subscribe(data => { this.searchMapUserRoleCountCallback(data) });
  }

  private searchMapUserRoleCountCallback(data) {
    if (Util.checkResponse(data)) {
      this.dataSize = data.resultData;
      this.searchMapUserRoleData(1);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  private searchMapUserRoleData(pageNum: number) {
    this.requestData.pageSize = CONSTANT.GridPagination.RecordPerPage;
    this.requestData.from = pageNum == 1 ? 0 : ((pageNum - 1) * CONSTANT.GridPagination.RecordPerPage);
    this.paginationData = {};
    this.restService.postRequestWithParamater('searchUserRoleDetails', this.requestData).subscribe(data => { this.searchMapUserRoleDataCallBack(data, pageNum) });
  }

  private searchMapUserRoleDataCallBack(data, pageNum: number) {
    if (Util.checkResponse(data)) {
      this.gridOptionsUserRole.api.setRowData(data.resultData.roleMaster);
      if (data.resultData.userRole != undefined && data.resultData.userRole != null) {
        this.gridOptionsUserRole.api.forEachNode(function (node) {
          if (data.resultData.userRole.indexOf(node.data.uadRoleNum) != -1) {
            node.setSelected(true);
          } else {
            node.setSelected(false);
          }
        });
      }
      this.paginationData = this.genericComponent.setPagination({}, pageNum, this.dataSize);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public clearButtonClickEvent() {
    this.searchForm.reset();
    this.gridOptionsUserRole.api.setRowData([]);
    this.paginationData = {};
  }

  public modifyButtonClickEvent() {
    this.genericComponent.clearMessages();
    if (this.genericComponent.checkModifyRecordSelection(this.gridApiUserRole)) {
      var rowData = this.gridApiUserRole.getSelectedRows();
      var jsonData = {
        userId: this.searchForm.value.userName != null ? this.searchForm.value.userName.value : null,
        listRoleMaster: rowData
      };
      this.restService.postRequestWithParamater('modifyUserRole', jsonData).subscribe(data => { this.modifyButtonCallBack(data) });
    }else{
      this.genericComponent.showWarningMessage(MessageConstant.MarketWatch.RowToModify);
    }
  }

  private modifyButtonCallBack(data) {
    if (Util.checkResponse(data)) {
      this.genericComponent.showSuccessMessage(data.responseMsg);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public onGridReadyGroup(params) {
    params.api.sizeColumnsToFit();
    this.gridApiUserRole = params.api;
  }

}
