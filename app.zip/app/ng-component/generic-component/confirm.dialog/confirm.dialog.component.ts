import { Component, OnInit } from '@angular/core';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';
import { Subscription } from 'rxjs/Subscription';
import { RestService, Command } from '../../../ng-service/rest.service';

@Component({
    selector: 'confirm-dialog',
    templateUrl: './confirm.dialog.component.html',
})

export class ConfirmDialogComponent implements OnInit {
    subscription: Subscription;
    constructor(public genericComponent: GenericComponent, public restService: RestService) {
        this.subscription = this.restService.commands.subscribe(c => this.handleCommand(c));
     }

    ngOnInit() { }

    handleCommand = (command: Command) => {
        switch (command.name) {
          case 'Ok': this.positiveButtonClickEvent(); break;
          case 'Cancel': this.negativeButtonClickEvent(); break;
        }
      }

    positiveButtonClickEvent() {
        this.genericComponent.genericConfirmationDialogEvent(true);     
    }

    negativeButtonClickEvent(){
        this.genericComponent.genericConfirmationDialogEvent(false);
    }

}