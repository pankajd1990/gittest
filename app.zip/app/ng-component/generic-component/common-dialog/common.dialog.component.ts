import { GridOptions } from 'ag-grid';
import { Component, OnDestroy, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'common-dialog',
    templateUrl: './common.dialog.component.html'
})

export class CommonDialogComponent implements OnDestroy {
    
    private BuyOrderLog: any;
    private gridOptionsBuyOrderLog: GridOptions;
    
    @Input() display: boolean;
    @Output() displayChange = new EventEmitter();

    constructor() {
        this.BuyOrderLog = [
            { headerName: 'Price', field: 'price', width: 80 },
            { headerName: 'Quantity', field: 'quantity', width: 60 },
            { headerName: 'Order Count', field: 'orderCount', width: 80 }
        ];
        this.gridOptionsBuyOrderLog = {
            suppressHorizontalScroll: false,
            columnDefs: this.BuyOrderLog,
        };
    }

    onClose() {
        this.displayChange.emit(false);
    }

    ngOnDestroy(): void {
        this.displayChange.unsubscribe();
    }

}