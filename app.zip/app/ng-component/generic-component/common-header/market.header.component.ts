import * as moment from 'moment';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/primeng';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { DataShareService } from '../../../ng-service/data.share.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';

@Component({
    selector: 'market-header',
    template: `<div class="row">
                    <div class="col-sm-9"></div>
                    <div class="col-sm-3 row" style="color:white;">
                        <div class="sdiv">
                            <button class="sbutton">Welcome {{loginUserName}}</button>
                            <div class="sdropdown" (mouseenter) ="setBusinessDate()">
                                <button class="cbutton" style="border-left:1px solid white">
                                    <i class="fa fa-caret-down"></i>
                                </button>
                                <div class="sdropdown-content">
                                    <span>Business Date:<br>{{businessDate}}</span>
                                    <span>Last Login:<br>{{lastLoginDetails}}</span>
                                    <span (click)="changePasswordEvent()" style="cursor: pointer;">Change Password</span>
                                    <span (click)="helpFunction()" style="cursor: pointer;">Help</span>
                                </div>
                            </div>
                        </div>
                        <div class="logoutClass">
                            <span class="logout-text" (click)="logoutClickEvent()">
                             <img src="./assets/images/logout.png" width="30%" />
                                Logout
                            </span>
                        </div>
                    </div>
                    <change-password></change-password>
                </div>`,
})

export class MarketHeaderComponent implements OnInit {

    @Output() someEvent = new EventEmitter<string>();
    
    public loginData: any;
    public businessDate: String;
    public loginUserName: String;
    public lastLoginDetails: String;

    constructor(private dataShareService: DataShareService, private router: Router, public genericComponent: GenericComponent) { }

    ngOnInit() {
        this.loginUserName = null;
        this.dataShareService.loginMessage.subscribe(message => this.loginData = message);
        this.loginUserName = this.loginData.userFullName;
        this.lastLoginDetails = moment(this.loginData.lastLoginDate).format('DD-MMM-YYYY, h:mm:ss a');
    }

    setBusinessDate() {
        this.businessDate = this.genericComponent.businessDate;
    }

    changePasswordEvent() {
        this.genericComponent.psswrdUserId = this.loginData.userId;
        this.genericComponent.showChangePasswordDialog();
    }

    logoutClickEvent() {
        this.genericComponent.closeForm();
        this.router.navigateByUrl('/login', { skipLocationChange: true });
    }

    helpFunction() {
        
    }

}