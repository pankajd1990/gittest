import { Subscription } from 'rxjs';
import { Component, OnInit, forwardRef, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR, NG_VALIDATORS, Validator } from '@angular/forms';

import { RestService } from '../../../ng-service/rest.service';
import { MessageService } from '../../../ng-service/message.service';


@Component({
    selector: 'common-floating-lov',
    templateUrl: './common.floating.lov.component.html',
    providers: [{
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => CommonFloatingLovComponent),
            multi: true,
        },{
            provide: NG_VALIDATORS,
            useExisting: forwardRef(() => CommonFloatingLovComponent),
            multi: true,
        }
    ]
})

export class CommonFloatingLovComponent implements OnInit {

    @Input("popupdata") popupdata;
    @Input("searchLovData") searchLovData;
    @Input("symbolSeriesPaginationData") symbolSeriesPaginationData;
    @Input("fieldDisabled") fieldDisabled;
    @Input("lovSrchBtnDis") lovSrchBtnDis;
    @Output() getLovData: any = new EventEmitter();
    @Output() getSymbolSeriesData: any = new EventEmitter();
    @Output() populateSelectedValue: any = new EventEmitter();

    private uservalue: any;
    private isvalid: any;
    private isdiable: boolean = false;
    private data: any;
    private popupfields: any;
    private gridOptions: any;
    private lovData: any;
    private paginationData: any;
    private searchName: string = "";
    private searchCode: string = "";
    public visible: Boolean = false;
    public searchForm: FormGroup;
    private disablefield: boolean = false;
    private disLovSrchBtn: boolean = false;
    

    constructor(private messageService: MessageService,private restService: RestService) {
        
    }

    ngOnInit() {
        this.popupfields = {
            header: this.popupdata.header,
            label:{
                code:this.popupdata.srchFields[0].name1,
                name:this.popupdata.srchFields[1].name2
            }
        }

        this.gridOptions = {
            rowSelection: 'single',
            columnDefs: this.popupdata.columnDefs,
            onGridReady: function (params) {},
            suppressHorizontalScroll:true
        }
        
    }

    public writeValue(obj: any) {
        if (obj) {
            this.data = obj;
            this.uservalue = this.data;
        } else {
            this.uservalue = ""
        }
    }

    // registers 'fn' that will be fired wheb changes are made
    // this is how we emit the changes back to the form
    public registerOnChange(fn: any) {
        this.propagateChange = fn;
    }

    ngOnChanges() {
        this.lovData = this.searchLovData;
        this.paginationData = this.symbolSeriesPaginationData;
        this.disablefield = this.fieldDisabled;
        this.disLovSrchBtn = this.lovSrchBtnDis;
    }

    // validates the form, returns null when valid else the validation object
    // in this case we're checking if the json parsing has passed or failed from the onChange method
    public validate(c: FormControl) {

        return (this.isvalid) ? null : {
            valid: {
                valid: false,
            },
        };
    }

    // not used, used for touch input
    public registerOnTouched() { }

    // the method set in registerOnChange to emit changes back to the form
    private propagateChange = (_: any) => { };
    setDisabledState(isDisabled: boolean): void {
        this.isdiable = isDisabled;
    }
    
    clearButtonClickEvent() {
        this.lovData = [];
        this.searchCode = "";
        this.searchName = "";
    }

    showDialog(pageNum:number) {
        this.searchCode = "";
        this.searchName = "";
        this.visible = true;
        this.data = {
            searchCode:this.uservalue,
            pageNum: pageNum
        }
        this.searchCode=this.data.searchCode;
        this.getLovData.emit(this.data);
    }

    popupSearchData(pageNum:number) {
        this.data = {
            searchCode:this.searchCode,
            searchName:this.searchName,
            pageNum:pageNum
        }

        this.propagateChange(this.data);
        this.getLovData.emit(this.data);
    }

    paginateData(pageNum:number) {
        this.data = {
            searchCode:this.searchCode,
            searchName:this.searchName,
            pageNum:pageNum
        }

        this.propagateChange(this.data);
        this.getSymbolSeriesData.emit(this.data);
    }

    selectedGridRows(obj) {
        if (obj) {
        this.uservalue = obj.data.symbol;
        this.data = {
            searchCode:obj.data.symbol,
            searchName:obj.data.series
        }

        this.populateSelectedValue.emit(this.data);
        //   this.propagateChange(this.data);
        this.visible = false;
        }
    }

    setValue(obj){
        var searchCode = obj.target['value'];
        this.data = {
            searchCode:searchCode
        }
        this.populateSelectedValue.emit(this.data);

    }

    
}