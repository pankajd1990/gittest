import * as moment from 'moment';

import { Subject } from 'rxjs/Subject';
import { Observable, of } from 'rxjs';
import { Router } from '@angular/router';
import { IMyOptions } from 'mydatepicker';
import { NgbTimeStruct } from '@ng-bootstrap/ng-bootstrap';
import { Injectable, ViewChild, Component } from '@angular/core';

import { survConst } from '../../../ng-utility/survConst';
import { MessageConstant } from '../../../ng-utility/ng.message.constant';

import { RestService } from '../../../ng-service/rest.service';
import { MessageService } from '../../../ng-service/message.service';
import { DataShareService } from '../../../ng-service/data.share.service';

@Injectable()
export class GenericComponent {

    //form Button attribute
    public isButtonVisible: Boolean = false;

    //form title attribute
    public formTitle: String;
    public showFormTitle: Boolean;

    //grid selction attribute
    public singleRowSelection: String = 'single';
    public multipleRowSelection: String = 'multiple';

    //Business Date
    public businessDate: String;

    //confirmation dialog attribute
    public confirmDialogBody: String = '';
    public confirmDialogHeader: String = '';
    public showConfirmDialogPopup: Boolean = false;

    //change password attribute
    public psswrdUserId: String = '';
    public displayResetPassword: Boolean = false;
    public displayPasswordPolicy: Boolean = false;

    //transaction form attribute
    public isTransactionSubmit: Boolean;
    public transactionFlag: Boolean;
    public transactionFormTitle: String;
    public showTransactionForm: Boolean;

    //transaction button click event
    public addRecordCallSource = new Subject<any>();
    addRecordCall$ = this.addRecordCallSource.asObservable();

    public modifyRecordCallSource = new Subject<any>();
    modifyRecordCall$ = this.modifyRecordCallSource.asObservable();
    public showConfirmDialog:boolean=false;

    public myDatePickerOptions: IMyOptions = {
        dateFormat: 'dd-mmm-yyyy',
        componentDisabled: false,
        showClearDateBtn: false,
    };

    constructor(private restService: RestService, private messageService: MessageService,
        private router: Router, private dataShareService: DataShareService) {

    }

    public initOpenForm() {
        this.isButtonVisible = false;
        let menuData = null;
        this.dataShareService.applicationMessage.subscribe(message => menuData = JSON.parse(message));
        let data = menuData.MenuFunction;

        if (data == undefined || data == null) {
            this.isButtonVisible = false;
            return;
        }

        this.formTitle = '';
        let page = this.router.url;
        page = page.substring(page.lastIndexOf('/') + 1, page.length);

        for (let index = 0; index < data.length; index++) {
            if (data[index].url == page) {
                this.showFormTitle = true;
                this.formTitle = data[index].label;
                if (data[index].function == 1) {
                    this.isButtonVisible = true;
                    break;
                }
            }
        }

        this.clearMessages();
        this.resetTransactionForm();
    }

    public closeForm() {
        this.messageService.clearMessages();
        this.router.navigateByUrl('/dashboard', { skipLocationChange: true });
        this.showFormTitle = false;
    }

    public clearMessages() {
        this.messageService.clearMessages();
    }

    public showSuccessMessage(message) {
        this.messageService.putSuccessMessage(message);
    }

    public showErrorMessage(message) {
        this.messageService.putErrorMessage(message);
    }

    public showWarningMessage(message) {
        this.messageService.putWarningMessage(message);
    }

    public openAddForm() {
        this.transactionFlag = true;
        this.showTransactionForm = true;
        this.isTransactionSubmit = false;
        this.transactionFormTitle = MessageConstant.TransactionForm.AddRecord;
    }

    public openModForm() {
        this.transactionFlag = false;
        this.showTransactionForm = true;
        this.isTransactionSubmit = false;
        this.transactionFormTitle = MessageConstant.TransactionForm.ModRecord;
    }

    public resetTransactionForm() {
        this.transactionFlag = null;
        this.showTransactionForm = false;
        this.transactionFormTitle = '';
        this.isTransactionSubmit = false;
        this.clearMessages();
    }

    public submitButtonClickEvent(form) {
        this.isTransactionSubmit = true;
        if (this.transactionFlag == null) {
            return;
        }
        this.clearMessages();
        if (!form.valid) {
            return;
        }
        if(!form.dirty){
            this.showErrorMessage(MessageConstant.ErrorMessage.NoChangeToSave);
            return;
        }
        if (this.transactionFlag) {
            this.addRecordCallSource.next(form);
        } else {
            this.modifyRecordCallSource.next(form)
        }
    }

    public checkModifyRecordSelection(grid) {
        if (grid != undefined && grid != null) {
            var length = grid.getSelectedRows().length;
            if (length != undefined && length != null && length > 0) {
                return true;
            }else{
                return false;
                //this.showWarningMessage(MessageConstant.TransactionForm.ModRowSelection);
            }
        }
    }

    public setBusinessDate(date : Date){
        this.businessDate = moment(date).format('DD-MMM-YYYY');
    }

    //TODO: check the code
    public showConfirmDialogEvent(dialogHeader: String, dialogBody: String) {
        if (dialogHeader != undefined && dialogHeader != null && dialogHeader != '') {
            this.confirmDialogHeader = dialogHeader;
        } else {
            this.confirmDialogHeader = MessageConstant.ConfirmDialog.confirmation;
        }
        if (dialogBody != undefined && dialogBody != null && dialogBody != '') {
            this.confirmDialogBody = dialogBody;
        } else {
            this.confirmDialogBody = MessageConstant.ConfirmDialog.proceedMessage;
        }
        this.showConfirmDialogPopup = true;
    }

    public genericConfirmationDialogEvent(flag: Boolean) {
        if (flag) {
            this.closeForm();
            this.showConfirmDialogPopup = false;
        } else {
            this.showConfirmDialogPopup = false;
        }
    }

    public showChangePasswordDialog() {
        this.displayPasswordPolicy = false;
        this.displayResetPassword = true;
    }

    public dateFormatRenderer(data) {
        return data.value !== '' && data.value != undefined ? moment(data.value).format('DD-MMM-YYYY hh:mm:ss a') : null;
    }

    public setPagination(paginate_data: any, pageNumber: number, totalrecord: any) {
        if (totalrecord > 0) {
            let totalLength = paginate_data.total_records = totalrecord;
            let totalPage;

            if (totalLength % survConst.RECORDS_PER_PAGE > 0) {
                totalPage = Math.floor(totalLength / survConst.RECORDS_PER_PAGE + 1);
            } else {
                totalPage = totalLength / survConst.RECORDS_PER_PAGE;
            }

            paginate_data = {
                current_page: pageNumber,
                total_records: totalLength,
                total_pages: totalPage,
                enableFirstLast: survConst.ENABLE_FIRST_LAST,
                enablego: survConst.ENABLE_GO,
            };

        } else {
            return paginate_data = {
                current_page: 0,
                total_records: 0,
                total_pages: 0,
                enableFirstLast: false
            }
        }
        return paginate_data;
    }

    public getDateObject(date: Date): any {
        var dateString = moment(date).format('YYYY-MM-DD');
        return {
            year: Number(dateString.split('-')[0]),
            month: Number(dateString.split('-')[1]),
            day: Number(dateString.split('-')[2])
        };
    }

    public getTimeObject(time: string): NgbTimeStruct {
        return {
            hour: Number(time.split(':')[0]),
            minute: Number(time.split(':')[1]),
            second: Number(time.split(':')[2])
        };
    }

    public compareTimes(time1: string, time2: string): Boolean {
        var time1InMinutesForTime1 = this.getTimeAsNumberOfSeconds(time1);
        var time1InMinutesForTime2 = this.getTimeAsNumberOfSeconds(time2);
        return time1InMinutesForTime1 < time1InMinutesForTime2;
    }


    private getTimeAsNumberOfSeconds(time): Number {
        var timeParts = time.split(":");
        var timeInMinutes = (timeParts[0] * 3600) + (timeParts[1] * 60) + (timeParts[2] * 1);
        return timeInMinutes;
    }

    public setMinDate(options: IMyOptions, date: Date): IMyOptions {
        var dte = new Date(date.getTime());
        dte.setDate(dte.getDate() - 1);

        var dateString = moment(dte).format('YYYY-MM-DD');
        options.disableUntil = {
            year: Number(dateString.split('-')[0]),
            month: Number(dateString.split('-')[1]),
            day: Number(dateString.split('-')[2])
        };
        return options;
    }

    public setMaxDate(options: IMyOptions, date: Date): IMyOptions {
        var dte = new Date(date.getTime());
        dte.setDate(dte.getDate() + 1);

        var dateString = moment(dte).format('YYYY-MM-DD');
        options.disableSince = {
            year: Number(dateString.split('-')[0]),
            month: Number(dateString.split('-')[1]),
            day: Number(dateString.split('-')[2])
        };
        return options;
    }

    //Filter json
    public filterArrJsonValue(arr: any, filtValue: String) {
        var filtArr = arr.filter(
            task => task.mrRcrdIndctr === filtValue);
        return filtArr;
    }

    public sortArray(prop) {
        return function (a, b) {
            if (a[prop] > b[prop]) {
                return 1;
            } else if (a[prop] < b[prop]) {
                return -1;
            }
            return 0;
        }
    }

}