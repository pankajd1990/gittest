import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChange, SimpleChanges } from '@angular/core';
import { survConst } from '../../../ng-utility/survConst';

@Component({
  selector: 'ng-pagination',
  templateUrl: './ng.pagination.component.html'
})
export class NgPaginationComponent implements OnInit {
  @Input() paginate_data: any;
  @Output() paginate: EventEmitter<any> = new EventEmitter();
  page_sequence = [];
  next = 1;
  previous = 1;
  err = false;
  last_page = 1;
  per_page = survConst.RECORDS_PER_PAGE;
  total_page_links = survConst.TOTAL_PAGE_LINKS;
  isNaN: Function = Number.isNaN;
  current_page: number;
  
  constructor() { }

  ngOnInit() {
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    this.err=false;
    let local_paginate_data;
    for (let propName in changes) {
      local_paginate_data = changes[propName].currentValue;
    }
    this.page_sequence = [];
    if (local_paginate_data.per_page) {
      this.per_page = local_paginate_data.per_page;
    } else {
      local_paginate_data.per_page = this.per_page;
    }
    let current_page = parseInt(local_paginate_data.current_page);
    let last_page = 1;
    last_page = this.last_page = Math.ceil(local_paginate_data.total_records / local_paginate_data.per_page);
    let start = 1;
    let end = last_page;
    if (last_page > this.total_page_links) {
      var curInt = parseInt(current_page+"");
      curInt = curInt + 1;
      
      if (current_page < Math.ceil(this.total_page_links / 2)) {
        end = this.total_page_links;
      } else if (curInt < last_page) {
        end = this.total_page_links + current_page - Math.ceil(this.total_page_links / 2);
      }
    }
    if (current_page > Math.ceil(this.total_page_links / 2) && last_page >= this.total_page_links) {
      //start = (current_page - Math.floor(this.total_page_links / 2));
      start = current_page;
      if (start > (last_page - this.total_page_links)) {
        start = last_page - this.total_page_links + 1;
      }
    }
    for (let i = start; i <= end; i++)
      this.page_sequence.push(i);
    this.next = current_page + 1;
    if (last_page == current_page)
      this.next = current_page;
    this.previous = current_page - 1;
    if (current_page == 1)
      this.previous = current_page;
  }

  localPaginate(page: number) {
    if(page !=null && page.toString() != ""){
    this.paginate.next(page);
    }else{
      this.err=true;
    }
  }
  
  validate(boxNum: number,lastPageVal: number ) {
    if(boxNum>lastPageVal){
      this.err = true;      
      return false;
    }else{
      this.err = false;      
    }
    return true;
  }


}
