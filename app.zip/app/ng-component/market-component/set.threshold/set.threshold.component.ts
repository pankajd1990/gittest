declare var $: any;
import * as moment from 'moment';
import { Subscription } from 'rxjs/Subscription';
import { AutofillMonitor } from '@angular/cdk/text-field';
import { Component, OnInit, ViewChild, Renderer } from '@angular/core';
import { GridOptions, GridApi, RowNode, AutoWidthCalculator } from 'ag-grid';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import Util from '../../../ng-utility/util';
import { CONSTANT } from '../../../ng-utility/ng.constant';
import { GridColumnDefs } from '../../../ng-utility/grid.config';
import { MessageConstant } from '../../../ng-utility/ng.message.constant';

import { RestService, Command } from '../../../ng-service/rest.service';
import { DataShareService } from '../../../ng-service/data.share.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';

@Component({
    templateUrl: './set.threshold.component.html'
})

export class SetThresholdComponent implements OnInit {

    private alertName: any;
    private searchForm: FormGroup;
    private subscription: Subscription;
    private addSubscription: Subscription;
    private modSubscription: Subscription;

    private components;
    private gridApiThreshold: GridApi;
    private gridOptionsThreshold: GridOptions;
    private gridOptionsAlert: GridOptions;

    private requestData: any = {};
    private requestData2: any = {};

    private dataSize: number;
    private paginationData: any = {};

    private loginData: any;
    private businessDate: String;
    private showOptionGrid: Boolean;

    constructor(private restService: RestService, public genericComponent: GenericComponent, private dataShareService: DataShareService) {
        
        this.subscription = this.restService.commands.subscribe(c => this.handleCommand(c));
        this.modSubscription = this.genericComponent.modifyRecordCall$.subscribe(data => this.modifyButtonClickEvent());

        this.gridOptionsThreshold = {
            rowData: [],
            enableColResize: true,
            floatingFilter: true,
            columnDefs: GridColumnDefs.SetThreshold.PrimaryGrid
        };
        this.gridOptionsAlert = {
            rowData: [],
            enableColResize: true,
            floatingFilter: true,
            columnDefs: GridColumnDefs.SetThreshold.SecondaryGrid
        };
    }

    handleCommand = (command: Command) => {
        switch (command.name) {
          case 'Search': this.searchButtonClickEvent(this.searchForm); break;
          case 'Clear': this.clearButtonClickEvent(); break;
          case 'Modify': this.modifyButtonClickEvent(); break;
          case 'Submit': this.genericComponent.submitButtonClickEvent(this.gridOptionsAlert); break;
          case 'Close': this.closeButtonClickEvent(); break;
        }
      }

    ngOnInit() {
        this.showOptionGrid = true;
        this.genericComponent.initOpenForm();
        this.dataShareService.loginMessage.subscribe(message => this.loginData = message);
        this.businessDate = moment(this.loginData.sysDate).format("DD-MMM-YYYY");
        this.searchForm = new FormGroup({
            alertName: new FormControl()
        });
        this.restService.postRequest('getAllAlerts').subscribe(data => { this.getAllRulesCallBack(data) });
    }

    getAllRulesCallBack(data) {
        if (Util.checkResponse(data)) {
            this.alertName = JSON.parse(data.resultData);
        } else {
            this.genericComponent.showErrorMessage(data.responseMsg);
        }
    }

    searchButtonClickEvent(form: FormGroup) {
        this.genericComponent.resetTransactionForm();
        this.showOptionGrid = true;
        var alertArray = [];
        if (form.value.alertName != null) {
            form.value.alertName.forEach(element => {
                alertArray.push(element.value)
            });
        }
        this.requestData.alertName = alertArray != null ? alertArray : null
        this.gridOptionsThreshold.api.setRowData([]);
        this.restService.postRequestWithParamater('searchAlertCountData', this.requestData).subscribe(data => { this.searchAlertCountDataCallBack(data) });
    }

    searchAlertCountDataCallBack(data) {
        if (Util.checkResponse(data)) {
            this.dataSize = data.resultData;
            this.searchAlertData(1);
        } else {
            this.genericComponent.showErrorMessage(data.responseMsg);
        }
    }

    searchAlertData(pageNum: number) {
        this.requestData.pageSize = CONSTANT.GridPagination.RecordPerPage;
        this.requestData.from = pageNum == 1 ? 0 : ((pageNum - 1) * CONSTANT.GridPagination.RecordPerPage);
        this.paginationData = {};
        this.restService.postRequestWithParamater('searchAlertData', this.requestData).subscribe(data => { this.searchButtonCallBack(data, pageNum) });
    }


    searchButtonCallBack(data, pageNum: number) {
        if (Util.checkResponse(data)) {
            this.gridOptionsThreshold.api.setRowData(data.resultData);
            this.paginationData = this.genericComponent.setPagination({}, pageNum, this.dataSize);
        } else {
            this.genericComponent.showErrorMessage(data.responseMsg);
        }
    }

    clearButtonClickEvent() {
        this.searchForm.reset();
        this.genericComponent.resetTransactionForm();
        this.gridOptionsThreshold.api.setRowData([]);
        this.paginationData = {};
    }

    modifyButtonClickEvent() {
        this.genericComponent.clearMessages();
        if (this.genericComponent.checkModifyRecordSelection(this.gridApiThreshold)) {
            this.genericComponent.openModForm();
            var rowData = this.gridOptionsThreshold.api.getSelectedRows();
            this.requestData2.listAlertDetails = rowData
            this.restService.postRequestWithParamater('searchSelectedCountData', this.requestData2).subscribe(data => { this.searchSelectedCountDataCallBack(data) });
        }else{
            this.genericComponent.showWarningMessage(MessageConstant.MarketWatch.RowToModify);
        }
    }

    searchSelectedCountDataCallBack(data) {
        if (Util.checkResponse(data)) {
            this.dataSize = data.resultData;
            this.searchSelectedData(1);
        } else {
            this.genericComponent.showErrorMessage(data.responseMsg);
        }
    }

    searchSelectedData(pageNum: number) {
        this.requestData2.pageSize = CONSTANT.GridPagination.RecordPerPage;
        this.requestData2.from = pageNum == 1 ? 0 : ((pageNum - 1) * CONSTANT.GridPagination.RecordPerPage);
        this.paginationData = {};
        this.restService.postRequestWithParamater('searchSelectedData', this.requestData2).subscribe(data => { this.modifyButtonCallBack(data, pageNum) });
    }

    modifyButtonCallBack(data, pageNum: number) {
        if (Util.checkResponse(data)) {
            this.showOptionGrid = false;
            for (var i = 0; i < this.dataSize; i++) {
                data.resultData[i].thrshCurrentEffDateString = data.resultData[i].thrshEffDateString;
                data.resultData[i].thrshEffDateString = "";
                data.resultData[i].businessDate = this.businessDate;
            }
            this.gridOptionsAlert.api.setRowData(data.resultData);
            this.gridOptionsAlert.api.sizeColumnsToFit();
            this.paginationData = this.genericComponent.setPagination({}, pageNum, this.dataSize);
        } else {
            this.genericComponent.showErrorMessage(data.responseMsg);
        }
        this.gridApiThreshold.refreshView;
    }

    submitButtonClickEvent() {
        if (this.genericComponent.checkModifyRecordSelection(this.gridOptionsAlert.api)) {
            var rowData = this.gridOptionsAlert.api.getSelectedRows();
            var jsonData = {
                listUpdateDetails: rowData
            };
            if (jsonData.listUpdateDetails[0].thrshEffDateString == null || jsonData.listUpdateDetails[0].thrshEffDateString == "") {
                this.genericComponent.showErrorMessage(MessageConstant.SetThreshold.EffectiveDate);
            } else if (jsonData.listUpdateDetails[0].thrshNewValue == null || jsonData.listUpdateDetails[0].thrshNewValue == "") {
                this.genericComponent.showErrorMessage(MessageConstant.SetThreshold.NewValue);
            } else {
                this.restService.postRequestWithParamater('updateData', jsonData).subscribe(data => { this.submitButtonCallBack(data) });
            }
        }else{
            this.genericComponent.showWarningMessage(MessageConstant.SetThreshold.RowToSubmit);
          }
    }

    submitButtonCallBack(data) {
        if (Util.checkResponse(data)) {
            this.genericComponent.showSuccessMessage(data.responseMsg);
        } else {
            this.genericComponent.showErrorMessage(data.responseMsg);
        }
    }

    closeButtonClickEvent() {
        this.showOptionGrid = true;
        this.genericComponent.resetTransactionForm();
        this.genericComponent.clearMessages();
        this.gridOptionsAlert.api.setRowData([]);
    }

    onCheckboxClick(event) {
        if (this.showOptionGrid)
            if (this.gridOptionsThreshold.api.getSelectedRows().length > 0) {
                return true;
            }
        return false;
    }

    onGridReadyEvent(params) {
        params.api.sizeColumnsToFit();
        this.gridApiThreshold = params.api;
    }

    public ngOnDestroy() {
        this.modSubscription.unsubscribe();
      }

}
