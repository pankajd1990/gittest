import { Component, OnInit, ViewChild, Renderer } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { GridOptions, RowNode, GridApi } from 'ag-grid';
import Util from '../../../ng-utility/util';
import { RestService, Command } from '../../../ng-service/rest.service';
import { MessageService } from '../../../ng-service/message.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';
import { Subscription } from 'rxjs/Subscription';
import { survConst } from '../../../ng-utility/survConst';
import { GridColumnDefs } from '../../../ng-utility/grid.config';
import { NgbTimeStruct, NgbTimepickerConfig } from '@ng-bootstrap/ng-bootstrap';
import { IMyOptions, IMyDateModel } from 'mydatepicker';
import { DataShareService } from '../../../ng-service/data.share.service';
import * as moment from 'moment';
import { MessageConstant } from '../../../ng-utility/ng.message.constant';  

@Component({
  templateUrl: './what.if.component.html'
})
export class WhatIfComponent implements OnInit {

  public subscription: Subscription;
  private searchForm: FormGroup;
  private showAddForm: Boolean = false;
  private showModifyForm: Boolean = false;
  private showRemoveForm: Boolean = false;
  private showButton: Boolean = false;
  private AddButtonForm: Boolean = false;
  private runId: any;
  private actionLov: any;
  private requestData: any = {};
  private paginationData: any = {};
  private dataSize: number;
  public showPagination: Boolean = false;
  private gridOptionsOrdFilter: GridOptions;
  public gridApiOrdFilter: GridApi;
  public submitted = false;
  public searchSubmitted = false;
  private actnLbl: String;
  public SetOrderAdd: FormGroup;
  public SetOrderModify: FormGroup;
  public SetOrderRemove: FormGroup;
  public SetOrderAddButton: FormGroup;
  public bsLov: any
  public marketLov: any
  public orderTypeLov: any
  public orderValidityLov: any
  public proCliLov: any
  public priceAdjustLov: any
  public preopenLov: any
  public modFlag: Boolean;

  //What-If
  public whatifModFlag: Boolean;
  private whatIfSelRunId: any;
  public gridApiWhatIf: GridApi;
  public whatIfSearchForm: FormGroup;
  public whatIfActionForm: FormGroup;
  public gridOptions: GridOptions;
  public showWhatIfActionForm: Boolean;
  public whatIfActionFormTitle: string;
  runDate: Date;
  maxBussDate: any;
  public runDateOptions: IMyOptions;
  indexNames = [];
  public loginData: any;

  private symbolSeriesPaginationData: any = {};
  public searchLovData: any;

  public runIdConst: any;
  public symbolConst: any;
  public seriesConst: any;
  public filterTypeConst: any;
  public form: FormGroup;

  columnDefsRunId = [
    { headerName: 'Run Date', field: 'whscrRunDate', width: 150, filter: 'agTextColumnFilter', checkboxSelection: true },
    { headerName: 'Filter Type', field: 'whatifFilterType', width: 150, filter: 'agTextColumnFilter' },
    { headerName: 'Filter Number', field: 'whatifFilterNumber', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'Symbol', field: 'whscrSymbol', width: 150, filter: 'agTextColumnFilter' },
    { headerName: 'Series', field: 'whscrSeries', width: 150, filter: 'agTextColumnFilter' },
    { headerName: 'OrderNo', field: 'whatifOrderNumber', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'Order Seq No', field: 'whatifSeqNumber', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'Seq Run No', field: 'whatifRunSeqNumber', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'Price Adj Sign', field: 'whatifPriceadjSignName', width: 150, filter: 'agTextColumnFilter' },
    { headerName: 'Price Adj Value', field: 'whatifPriceadjVal', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'Broker', field: 'whatifTmCode', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'Dealer', field: 'whatifDealerId', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'Buy Sell', field: 'whatifBuysellName', width: 150, filter: 'agTextColumnFilter' },
    { headerName: 'OrderType', field: 'whatifOrdTypeName', width: 150, filter: 'agTextColumnFilter' },
    { headerName: 'Limit Price', field: 'whatifLimitPrice', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'Trigger Price', field: 'whatifTriggerPrice', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'OrderValidity', field: 'whatifOrdValidityName', width: 150, filter: 'agTextColumnFilter' },
    { headerName: 'Quantity', field: 'whatifOrdQty', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'DQ', field: 'whatifOrdDisclosedQty', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'Pro Client', field: 'whatifProcliTypeName', width: 150, filter: 'agTextColumnFilter' },
    { headerName: 'Acc Code', field: 'whatifAccountCode', width: 150, filter: 'agTextColumnFilter' },
    { headerName: 'PAN ID', field: 'whatifClientPanid', width: 150, filter: 'agTextColumnFilter' },
    { headerName: 'Market', field: 'whatifMktTypeName', width: 150, filter: 'agTextColumnFilter' },
    { headerName: 'Branch Id', field: 'whatifBranchId', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'NNF Id', field: 'whatifNnfId', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'Algo Id', field: 'whatifAlgoId', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'Algo Category', field: 'whatifAlgoCategory', width: 150, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': "right" } },
    { headerName: 'Pre Open Indicator', field: 'whatifPreopenIndName', width: 150, filter: 'agTextColumnFilter' }

  ]



  constructor(private restService: RestService, public genericComponent: GenericComponent, private renderer: Renderer,
    private messageService: MessageService, private config: NgbTimepickerConfig, private dataShareService: DataShareService) {
    this.showWhatIfActionForm = false;
    config.seconds = true;
    config.spinners = false;
    this.gridOptionsOrdFilter = {
      rowData: [],
      floatingFilter: true,
      columnDefs: this.columnDefsRunId
    };
    this.modFlag = false;

    // What-If tab - Start 
    this.gridOptions = {
      rowData: [],
      floatingFilter: true,
      // enableColResize: true,
      columnDefs: GridColumnDefs.WhatIf
    };

    this.whatIfSearchForm = new FormGroup({
      whscrRunId: new FormControl()
    });

    this.whatIfActionForm = new FormGroup({
      whscrRunDate: new FormControl(),
      whscrSymbol: new FormControl('', [Validators.required]),
      whscrSeries: new FormControl(),
      whscrFromTime: new FormControl('', [Validators.required]),
      whscrToTime: new FormControl('', [Validators.required]),
      whscrIndexName: new FormControl(),
      whatifMktcloseTime: new FormControl(),
      whatifLargeUnexecutedQty: new FormControl('', Validators.pattern('^[0-9]*$')),
      whatifLargeCxlQty: new FormControl('', Validators.pattern('^[0-9]*$')),
      whatifPectAwayLtp: new FormControl('', [Validators.max(100), Validators.min(0), Validators.pattern('^([0-9]{0,2})+(.[0-9]{0,2})?$')]),
      whatifSlPectAwayLtp: new FormControl('', [Validators.max(100), Validators.min(0), Validators.pattern('^([0-9]{0,2})+(.[0-9]{0,2})?$')]),

    });

    this.runDate = new Date();

  }

  ngOnInit() {

    this.dataShareService.loginMessage.subscribe(message => this.loginData = message);
    this.messageService.clearMessages();

    this.searchForm = new FormGroup({
      runId: new FormControl('', Validators.required)
    });
    this.SetOrderAdd = new FormGroup({
      whscrSymbol: new FormControl(),
      whscrSeries: new FormControl(),
      whatifBuysell: new FormControl(),
      whatifMktType: new FormControl('', Validators.required),
      whatifOrdType: new FormControl('', Validators.required),
      whatifOrdValidity: new FormControl('', Validators.required),
      whatifLimitPrice: new FormControl('', Validators.pattern('^[0-9]+(.[0-9]{0,2})?$')),
      whatifTriggerPrice: new FormControl('', Validators.pattern('^[0-9]+(.[0-9]{0,2})?$')),
      whatifOrdQty: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$')]),
      whatifOrdDisclosedQty: new FormControl('', Validators.pattern('^[0-9]*$')),
      whatifTmCode: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(5)]),
      whatifDealerId: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(5)]),
      whatifBranchId: new FormControl('', Validators.required),
      whatifProcliType: new FormControl('', Validators.required),
      whatifAccountCode: new FormControl('', Validators.pattern('^[a-zA-Z0-9]+$')),
      whatifClientPanid: new FormControl('', Validators.pattern('^([A-Z]{5})([0-9]{4})([A-Z]{1})+$')),
      whatifNnfId: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(15)]),
      whatifAlgoId: new FormControl('', Validators.pattern('^[0-9]*$')),
      whatifAlgoCategory: new FormControl('', Validators.pattern('^[0-9]*$')),
      whatifSeqNumber: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$')]),
      whatifPriceadjSign: new FormControl(),
      whatifPriceadjVal: new FormControl('', Validators.pattern('^[0-9]+(.[0-9]{0,2})?$')),
      whatifPreopenInd: new FormControl(),
      whatifRunSeqNumber: new FormControl()
    });

    this.SetOrderModify = new FormGroup({
      whscrSeries: new FormControl(),
      whscrSymbol: new FormControl(),
      whatifOrdType: new FormControl('', Validators.required),
      whatifOrdValidity: new FormControl('', Validators.required),
      whatifLimitPrice: new FormControl('', Validators.pattern('^[0-9]+(.[0-9]{0,2})?$')),
      whatifTriggerPrice: new FormControl('', Validators.pattern('^[0-9]+(.[0-9]{0,2})?$')),
      whatifOrdQty: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$')]),
      whatifOrdDisclosedQty: new FormControl('', Validators.pattern('^[0-9]*$')),
      whatifProcliType: new FormControl('', Validators.required),
      whatifAccountCode: new FormControl('', Validators.pattern('[A-Za-z0-9]+$')),
      whatifClientPanid: new FormControl('', Validators.pattern('^([A-Z]{5})([0-9]{4})([A-Z]{1})+$')),
      whatifNnfId: new FormControl('', [Validators.pattern('^[0-9]*$'), Validators.minLength(15)]),
      whatifAlgoId: new FormControl('', Validators.pattern('^[0-9]*$')),
      whatifAlgoCategory: new FormControl('', Validators.pattern('^[0-9]*$')),
      whatifSeqNumber: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$')]),
      whatifOrderNumber: new FormControl(),
      whatifPriceadjSign: new FormControl(),
      whatifPriceadjVal: new FormControl('', Validators.pattern('^[0-9]+(.[0-9]{0,2})?$'))
    });

    this.SetOrderRemove = new FormGroup({
      whscrSeries: new FormControl(),
      whscrSymbol: new FormControl(),
      whatifSeqNumber: new FormControl('', [Validators.required, Validators.pattern('^[0-9]*$')]),
      whatifPriceadjSign: new FormControl(),
      whatifPriceadjVal: new FormControl('', Validators.pattern('^[0-9]+(.[0-9]{0,2})?$')),
    });

    this.SetOrderAddButton = new FormGroup({
      action: new FormControl()
    });

    this.geWhatIfData();

    /* HotKeys Start*/
    this.renderer.listenGlobal('document', 'keydown', event => {
      if (event.altKey && event.shiftKey && event.keyCode === 83) {
        this.searchButtonClickEvent(this.searchForm);
      }
      else if (event.altKey && event.shiftKey && event.keyCode === 69) {
        this.clearButtonClickEvent();
      }
      else if (event.altKey && event.altKey && event.keyCode === 77) {
        this.modifyButtonClickEvent();
      }
      else if (event.altKey && event.shiftKey && event.keyCode == 65) {
        this.addButtonClickEvent();
      }
      else if (event.altKey && event.shiftKey && event.keyCode == 76) {
        this.closeButtonEvent();
      }
      else if (event.altKey && event.shiftKey && event.keyCode == 68) {
        this.deleteButtonClickEvent();
      }
    });
    /*HotKeys End*/

  }


  searchButtonClickEvent(form: FormGroup) {
    this.showAddForm = false;
    this.showModifyForm = false;
    this.showRemoveForm = false;
    this.AddButtonForm = false;
    if (this.searchForm.valid) {
      this.requestData = {};
      this.requestData.runId = form.value.runId != null ? form.value.runId.value : null
      this.restService.postRequestWithParamater('searchRunCount', this.requestData).subscribe(data => { this.searchButtonRunCountCallBack(data) });
    } else {
      this.genericComponent.showErrorMessage(MessageConstant.WhatIf.RunIdSelection);
    }
  }

  searchButtonRunCountCallBack(data) {
    if (Util.checkResponse(data)) {
      this.dataSize = data.resultData;
      if (data.resultData > 0)
        this.searchRunIdData(1);
    } else {
      this.genericComponent.showErrorMessage(survConst.errorMsg.noDataErr);
    }
  }

  searchRunIdData(pageNum: number) {
    try {
      this.requestData.pageSize = survConst.RECORDS_PER_PAGE;
      this.requestData.from = pageNum == 1 ? 0 : ((pageNum - 1) * survConst.RECORDS_PER_PAGE);
      this.paginationData = {};
      this.restService.postRequestWithParamater('searchRunIdData', this.requestData).subscribe(data => { this.searchButtonCallBack(data, pageNum) });
    }
    catch (err) {
     this.genericComponent.showErrorMessage(survConst.errorMsg.noDataErr);
    }
  }

  searchButtonCallBack(data, pageNum: number) {
    if (Util.checkResponse(data)) {
      this.showButton = true;
      let gridData = data.resultData;
      this.runIdConst = gridData[0].whscrRunId;
      this.symbolConst = gridData[0].whscrSymbol;
      this.seriesConst = gridData[0].whscrSeries;

      if (gridData[0].whatifFilterNumber !== null) {
        for (var i = 0; i < gridData.length; i++) {
          if (gridData[i].whatifFilterType == 'A')
            gridData[i].whatifFilterType = "NEW";
          else if (gridData[i].whatifFilterType == 'M')
            gridData[i].whatifFilterType = "MODIFY";
          else if (gridData[i].whatifFilterType == 'R')
            gridData[i].whatifFilterType = "REMOVE";
        }
        this.gridOptionsOrdFilter.api.setRowData(gridData);
        this.paginationData = this.genericComponent.setPagination({}, pageNum, this.dataSize);
        this.showPagination = true;
      }
    } else {
      this.messageService.putMessage(data);
    }
  }

  private getAllRunIdCallBack(data) {
    if (Util.checkResponse(data)) {
      this.runId = JSON.parse(data.resultData);
    } else {
      this.messageService.putMessage(data);
    }
  }

  okButtonClickEvent(form: FormGroup) {
    this.submitted = false;
    this.modFlag = false;
    var action1 = form.value.action != null ? form.value.action.value : null
    if (action1 == "NEW") {
      this.actnLbl = 'New Order';
      this.AddButtonForm = false;
      this.showAddForm = true;
      this.SetOrderAdd.reset();
      this.setSymbolSeries(this.SetOrderAdd, this.seriesConst, this.symbolConst);
      this.restService.postRequest('getAddLOV').subscribe(data => { this.getAddLOVCallBack(data) });
    } else if (action1 == "REMOVE") {
      this.actnLbl = 'Remove Order';
      this.AddButtonForm = false;
      this.showRemoveForm = true;
      this.SetOrderRemove.reset();
      this.setSymbolSeries(this.SetOrderRemove, this.seriesConst, this.symbolConst);
      this.restService.postRequest('getAddLOV').subscribe(data => { this.getRemoveLOVCallBack(data) });
    } else if (action1 == "MODIFY") {
      this.actnLbl = 'Modify Order';
      this.AddButtonForm = false;
      this.showModifyForm = true;
      this.SetOrderModify.reset();
      this.setSymbolSeries(this.SetOrderModify, this.seriesConst, this.symbolConst);
      this.restService.postRequest('getAddLOV').subscribe(data => { this.getModLOVCallBack(data) });
    } else {
      this.genericComponent.showErrorMessage(MessageConstant.WhatIf.ActionSelection);
    }
  }

  addButtonClickEvent() {
    this.showModifyForm = false;
    this.showRemoveForm = false;
    this.actnLbl = 'Action Form';
    this.showAddForm = false;
    this.AddButtonForm = true;
    this.restService.postRequest('getActionLOV').subscribe(data => { this.getActionLOVCallBack(data) });
  }

  private getActionLOVCallBack(data) {
    if (Util.checkResponse(data)) {
      this.actionLov = JSON.parse(data.resultData.action);
    } else {
      this.messageService.putMessage(data);
    }
  }

  modifyButtonClickEvent() {
    this.showAddForm = false;
    this.modFlag = true;
    this.AddButtonForm = false;
    this.messageService.clearMessages();
    if (this.gridApiOrdFilter.getSelectedRows().length > 0) {

      if (this.gridApiOrdFilter.getSelectedRows()[0].whatifFilterType == 'NEW') {
        this.showModifyForm = false;
        this.showRemoveForm = false;
        this.actnLbl = 'New Order';
        this.showAddForm = true;
        this.getAddLOV();
      }
      if (this.gridApiOrdFilter.getSelectedRows()[0].whatifFilterType == 'MODIFY') {
        this.showRemoveForm = false;
        this.showAddForm = false;
        this.actnLbl = 'Modify Order';
        this.showModifyForm = true;
        this.getModLOV();
      }
      if (this.gridApiOrdFilter.getSelectedRows()[0].whatifFilterType == 'REMOVE') {
        this.showAddForm = false;
        this.showModifyForm = false;
        this.actnLbl = 'Remove Order';
        this.showRemoveForm = true;
        this.getRemoveLOV();
      }
    } else {
      this.genericComponent.showErrorMessage(MessageConstant.TransactionForm.ModRowSelection);
    }
  }

  deleteButtonClickEvent() {
    if (this.gridApiOrdFilter.getSelectedRows().length > 0) {
      var jsonData = {
        whatifRunId: this.runIdConst,
        whatifFilterNumber: this.gridApiOrdFilter.getSelectedRows().length > 0 ? this.gridApiOrdFilter.getSelectedRows()[0].whatifFilterNumber : null,
      }
      this.restService.postRequestWithParamater('deleteOrderFilter', jsonData).subscribe(data => { this.submitButtonCallBack(data) });
    } else {
      this.genericComponent.showErrorMessage(MessageConstant.WhatIf.DelRowSelection);
    }
  }

  submitAddClickEvent(form: FormGroup) {
    this.submitted = true;
    this.filterTypeConst = 'A';
    if (this.SetOrderAdd.valid) {
      var jsonData = {
        whatifRunId: this.runIdConst,
        whatifFilterType: this.filterTypeConst,
        whatifFilterNumber: this.gridApiOrdFilter.getSelectedRows().length > 0 ? this.gridApiOrdFilter.getSelectedRows()[0].whatifFilterNumber : null,
        whatifBuysell: form.value.whatifBuysell != null ? form.value.whatifBuysell.key : null,
        whatifMktType: form.value.whatifMktType != null ? form.value.whatifMktType.key : null,
        whatifOrdType: form.value.whatifOrdType != null ? form.value.whatifOrdType.key : null,
        whatifOrdValidity: form.value.whatifOrdValidity != null ? form.value.whatifOrdValidity.key : null,
        whatifLimitPrice: form.value.whatifLimitPrice != null ? form.value.whatifLimitPrice : null,
        whatifTriggerPrice: form.value.whatifTriggerPrice != null ? form.value.whatifTriggerPrice : null,
        whatifOrdQty: form.value.whatifOrdQty != null ? form.value.whatifOrdQty : null,
        whatifOrdDisclosedQty: form.value.whatifOrdDisclosedQty != null ? form.value.whatifOrdDisclosedQty : null,
        whatifTmCode: form.value.whatifTmCode != null ? form.value.whatifTmCode : null,
        whatifDealerId: form.value.whatifDealerId != null ? form.value.whatifDealerId : null,
        whatifBranchId: form.value.whatifBranchId != null ? form.value.whatifBranchId : null,
        whatifProcliType: form.value.whatifProcliType != null ? form.value.whatifProcliType.key : null,
        whatifAccountCode: form.value.whatifAccountCode != null ? form.value.whatifAccountCode : null,
        whatifClientPanid: form.value.whatifClientPanid != null ? form.value.whatifClientPanid : null,
        whatifNnfId: form.value.whatifNnfId != null ? form.value.whatifNnfId : null,
        whatifAlgoId: form.value.whatifAlgoId != null ? form.value.whatifAlgoId : null,
        whatifAlgoCategory: form.value.whatifAlgoCategory != null ? form.value.whatifAlgoCategory : null,
        whatifSeqNumber: form.value.whatifSeqNumber != null ? form.value.whatifSeqNumber : null,
        whatifPriceadjSign: form.value.whatifPriceadjSign != null ? form.value.whatifPriceadjSign.key : null,
        whatifPriceadjVal: form.value.whatifPriceadjVal != null ? form.value.whatifPriceadjVal : null,
        whatifPreopenInd: form.value.whatifPreopenInd != null ? form.value.whatifPreopenInd.key : null,
        whatifRunSeqNumber: form.value.whatifRunSeqNumber != null ? form.value.whatifRunSeqNumber : null
      };
      if (!this.modFlag) {
        this.restService.postRequestWithParamater('addNewOrd', jsonData).subscribe(data => { this.submitButtonCallBack(data) });
      } else {
        this.restService.postRequestWithParamater('ModNewOrd', jsonData).subscribe(data => { this.submitButtonCallBack(data) });
      }
    }
  }

  submitModClickEvent(form: FormGroup) {
    this.submitted = true;
    this.filterTypeConst = 'M';
    if (this.SetOrderModify.valid) {
      var jsonData = {
        whatifRunId: this.runIdConst,
        whatifFilterType: this.filterTypeConst,
        whatifFilterNumber: this.gridApiOrdFilter.getSelectedRows().length > 0 ? this.gridApiOrdFilter.getSelectedRows()[0].whatifFilterNumber : null,
        whatifOrdType: form.value.whatifOrdType != null ? form.value.whatifOrdType.key : null,
        whatifOrdValidity: form.value.whatifOrdValidity != null ? form.value.whatifOrdValidity.key : null,
        whatifLimitPrice: form.value.whatifLimitPrice != null ? form.value.whatifLimitPrice : null,
        whatifTriggerPrice: form.value.whatifTriggerPrice != null ? form.value.whatifTriggerPrice : null,
        whatifOrdQty: form.value.whatifOrdQty != null ? form.value.whatifOrdQty : null,
        whatifOrdDisclosedQty: form.value.whatifOrdDisclosedQty != null ? form.value.whatifOrdDisclosedQty : null,
        whatifProcliType: form.value.whatifProcliType != null ? form.value.whatifProcliType.key : null,
        whatifAccountCode: form.value.whatifAccountCode != null ? form.value.whatifAccountCode : null,
        whatifClientPanid: form.value.whatifClientPanid != null ? form.value.whatifClientPanid : null,
        whatifNnfId: form.value.whatifNnfId != null ? form.value.whatifNnfId : null,
        whatifAlgoId: form.value.whatifAlgoId != null ? form.value.whatifAlgoId : null,
        whatifAlgoCategory: form.value.whatifAlgoCategory != null ? form.value.whatifAlgoCategory : null,
        whatifSeqNumber: form.value.whatifSeqNumber != null ? form.value.whatifSeqNumber : null,
        whatifOrderNumber: form.value.whatifOrderNumber != null ? form.value.whatifOrderNumber : null,
        whatifPriceadjSign: form.value.whatifPriceadjSign != null ? form.value.whatifPriceadjSign.key : null,
        whatifPriceadjVal: form.value.whatifPriceadjVal != null ? form.value.whatifPriceadjVal : null,
      };
      if (!this.modFlag) {
        this.restService.postRequestWithParamater('addModOrd', jsonData).subscribe(data => { this.submitButtonCallBack(data) });
      }
      else {
        this.restService.postRequestWithParamater('ModModOrd', jsonData).subscribe(data => { this.submitButtonCallBack(data) });
      }
    }
  }

  submitRemoveClickEvent(form: FormGroup) {
    this.submitted = true;
    this.filterTypeConst = 'R';
    if (this.SetOrderRemove.valid) {
      var jsonData = {
        whatifRunId: this.runIdConst,
        whatifFilterType: this.filterTypeConst,
        whatifFilterNumber: this.gridApiOrdFilter.getSelectedRows().length > 0 ? this.gridApiOrdFilter.getSelectedRows()[0].whatifFilterNumber : null,
        whatifSeqNumber: form.value.whatifSeqNumber != null ? form.value.whatifSeqNumber : null,
        whatifPriceadjSign: form.value.whatifPriceadjSign != null ? form.value.whatifPriceadjSign.key : null,
        whatifPriceadjVal: form.value.whatifPriceadjVal != null ? form.value.whatifPriceadjVal : null,
      };
      if (!this.modFlag) {
        this.restService.postRequestWithParamater('addRemoveOrd', jsonData).subscribe(data => { this.submitButtonCallBack(data) });
      } else {
        this.restService.postRequestWithParamater('ModRemoveOrd', jsonData).subscribe(data => { this.submitButtonCallBack(data) });
      }
    }
  }


  onGridReadyOrdFilter(params) {
    params.api.sizeColumnsToFit();
    this.gridApiOrdFilter = params.api;
  }


  setSymbolSeries(form: FormGroup, seriesConst: any, symbolConst: any) {
    form.controls['whscrSymbol'].setValue(symbolConst);
    form.controls['whscrSeries'].setValue(seriesConst);
  }

  getAddLOV() {
    this.restService.postRequest('getAddLOV').subscribe(data => { this.getAddLOVCallBack(data) });
  }


  getAddLOVCallBack(data) {
    if (Util.checkResponse(data)) {
      this.bsLov = JSON.parse(data.resultData.bs);
      this.marketLov = JSON.parse(data.resultData.market);
      this.orderTypeLov = JSON.parse(data.resultData.orderType);
      this.orderValidityLov = JSON.parse(data.resultData.orderValidity);
      this.proCliLov = JSON.parse(data.resultData.proCli);
      this.priceAdjustLov = JSON.parse(data.resultData.priceAdjust);
      this.preopenLov = JSON.parse(data.resultData.preopen);
      if (this.modFlag) {
        var rowData = this.gridApiOrdFilter.getSelectedRows()[0];
        this.fillModAddForm(rowData, this.SetOrderAdd);
      }
    } else {
      this.genericComponent.showErrorMessage(MessageConstant.ErrorMessage.NoDataFound);
    }
  }

  fillModAddForm(data, form: FormGroup) {
    if (data) {
      let textFieldArray: Array<string> = ['whscrSymbol', 'whscrSeries', 'whatifLimitPrice', 'whatifTriggerPrice', 'whatifOrdQty', 'whatifOrdDisclosedQty',
        'whatifTmCode', 'whatifDealerId', 'whatifAccountCode', 'whatifClientPanid', 'whatifSeqNumber', 'whatifPriceadjVal',
        'whatifBranchId', 'whatifNnfId', 'whatifAlgoId', 'whatifAlgoCategory', 'whatifRunSeqNumber'];
      Object.keys(form.value).forEach(name => {
        if (textFieldArray.includes(name)) {
          form.controls[name].setValue(data[name]);
        } else {
          switch (name) {
            case 'whatifBuysell':
              form.controls[name].setValue(this.bsLov.find(x => x.key == data[name]));
              break;
            case 'whatifMktType':
              form.controls[name].setValue(this.marketLov.find(x => x.key == data[name]));
              break;
            case 'whatifOrdType':
              form.controls[name].setValue(this.orderTypeLov.find(x => x.key == data[name]));
              break;
            case 'whatifOrdValidity':
              form.controls[name].setValue(this.orderValidityLov.find(x => x.key == data[name]));
              break;
            case 'whatifProcliType':
              form.controls[name].setValue(this.proCliLov.find(x => x.key == data[name]));
              break;
            case 'whatifPriceadjSign':
              form.controls[name].setValue(this.priceAdjustLov.find(x => x.key == data[name]));
              break;
            case 'whatifPreopenInd':
              form.controls[name].setValue(this.preopenLov.find(x => x.key == data[name]));
              break;
          }
        }
      });
    }
  }

  getModLOV() {
    this.restService.postRequest('getAddLOV').subscribe(data => { this.getModLOVCallBack(data) });
  }
  getModLOVCallBack(data) {
    if (Util.checkResponse(data)) {
      this.orderTypeLov = JSON.parse(data.resultData.orderType);
      this.orderValidityLov = JSON.parse(data.resultData.orderValidity);
      this.proCliLov = JSON.parse(data.resultData.proCli);
      this.priceAdjustLov = JSON.parse(data.resultData.priceAdjust);
      this.preopenLov = JSON.parse(data.resultData.preopen);
      if (this.modFlag) {
        var rowData = this.gridApiOrdFilter.getSelectedRows()[0];
        this.fillModModForm(rowData, this.SetOrderModify);
      }
    } else {
      this.genericComponent.showErrorMessage(MessageConstant.ErrorMessage.NoDataFound);
    }
  }

  fillModModForm(data, form: FormGroup) {
    if (data) {
      let textFieldArray: Array<string> = ['whscrSymbol', 'whscrSeries', 'whatifLimitPrice', 'whatifTriggerPrice', 'whatifOrdQty', 'whatifOrdDisclosedQty',
        'whatifAccountCode', 'whatifClientPanid', 'whatifSeqNumber', 'whatifOrderNumber', 'whatifPriceadjVal',
        'whatifNnfId', 'whatifAlgoId', 'whatifAlgoCategory'];
      Object.keys(form.value).forEach(name => {
        if (textFieldArray.includes(name)) {
          form.controls[name].setValue(data[name]);
        } else {
          switch (name) {
            case 'whatifOrdType':
              form.controls[name].setValue(this.orderTypeLov.find(x => x.key == data[name]));
              break;
            case 'whatifOrdValidity':
              form.controls[name].setValue(this.orderValidityLov.find(x => x.key == data[name]));
              break;
            case 'whatifProcliType':
              form.controls[name].setValue(this.proCliLov.find(x => x.key == data[name]));
              break;
            case 'whatifPriceadjSign':
              form.controls[name].setValue(this.priceAdjustLov.find(x => x.key == data[name]));
              break;
            case 'whatifPreopenInd':
              form.controls[name].setValue(this.preopenLov.find(x => x.key == data[name]));
              break;
          }
        }
      });
    }
  }

  getRemoveLOV() {
    this.restService.postRequest('getAddLOV').subscribe(data => { this.getRemoveLOVCallBack(data) });
  }
  getRemoveLOVCallBack(data) {
    if (Util.checkResponse(data)) {
      this.priceAdjustLov = JSON.parse(data.resultData.priceAdjust);
      if (this.modFlag) {
        var rowData = this.gridApiOrdFilter.getSelectedRows()[0];
        this.fillModRemoveForm(rowData, this.SetOrderRemove);
      }
    } else {
      this.genericComponent.showErrorMessage(MessageConstant.ErrorMessage.NoDataFound);
    }
  }

  fillModRemoveForm(data, form: FormGroup) {
    if (data) {
      let textFieldArray: Array<string> = ['whscrSymbol', 'whscrSeries',
        'whatifSeqNumber', 'whatifPriceadjVal'];
      Object.keys(form.value).forEach(name => {
        if (textFieldArray.includes(name)) {
          form.controls[name].setValue(data[name]);
        } else {
          switch (name) {
            case 'whatifPriceadjSign':
              form.controls[name].setValue(this.priceAdjustLov.find(x => x.key == data[name]));
              break;
          }
        }
      });
    }
  }

  clearButtonClickEvent() {
    this.submitted = false;
    this.showAddForm = false;
    this.showModifyForm = false;
    this.showRemoveForm = false;
    this.AddButtonForm = false;
    this.showButton = false;
    this.searchForm.reset();
    this.SetOrderAdd.reset();
    this.SetOrderModify.reset();
    this.SetOrderRemove.reset();
    this.SetOrderAddButton.reset();
    this.messageService.clearMessages();
    this.gridOptionsOrdFilter.api.setRowData([])
    this.paginationData = {};
    this.showPagination = false;
  }

  closeButtonEvent() {
    this.submitted = false;
    this.showAddForm = false;
    this.showModifyForm = false;
    this.showRemoveForm = false;
    this.AddButtonForm = false;
    this.SetOrderAdd.reset();
    this.SetOrderModify.reset();
    this.SetOrderRemove.reset();
    this.SetOrderAddButton.reset();
    this.messageService.clearMessages();
  }


  submitButtonCallBack(data) {
    if (Util.checkResponse(data)) {
      this.submitted = false;
      this.messageService.putMessage(data);
      this.showAddForm = false;
      this.showModifyForm = false;
      this.showRemoveForm = false;
      this.searchButtonClickEvent(this.searchForm);
    } else {
      this.messageService.putMessage(data);
    }
  }

  get f() {
    return this.SetOrderAdd.controls;
  }

  get fmod() {
    return this.SetOrderModify.controls;
  }

  get fremove() {
    return this.SetOrderRemove.controls;
  }

  onCheckboxClick(event) {
    if (this.gridApiOrdFilter.getSelectedRows().length > 0) {
      this.AddButtonForm = false;
      return true;
    }
    return false;
  }

  onTabChange(event) {
    if (event.index == 0) {
      this.whatIfClearButtonClickEvent();
      this.geWhatIfData();
    } else if (event.index == 1) {
      this.clearButtonClickEvent();
      this.restService.postRequest('getAllRunId').subscribe(data => { this.getAllRunIdCallBack(data) });
    }
  }



  //What-If Tab

  onWhatIfGridReady(params) {
    params.api.sizeColumnsToFit();
    this.gridApiWhatIf = params.api;
  }

  whatIfSearchButtonClickEvent(form: FormGroup) {

    this.requestData = {};
    this.requestData.runId = form.value.whscrRunId != null ? form.value.whscrRunId.key : form.value.whscrRunId;
    this.restService.postRequestWithParamater('getWhatIfGridCount', this.requestData).subscribe(data => { this.getWhatIfGridCountCallback(data) });
  }

  getWhatIfGridCountCallback(data) {
    if (Util.checkResponse(data)) {
      this.dataSize = data.resultData;
      if (data.resultData > 0)
        this.getWhatIfGridData(1);
    } else {
      this.genericComponent.showErrorMessage(survConst.errorMsg.noDataErr);
    }
  }

  getWhatIfGridData(pageNum: number) {
    try {
      // this.requestData = {};
      this.requestData.pageSize = survConst.RECORDS_PER_PAGE;
      this.requestData.from = pageNum == 1 ? 0 : ((pageNum - 1) * survConst.RECORDS_PER_PAGE);
      this.paginationData = {};

      this.restService.postRequestWithParamater('getWhatIfGridData', this.requestData).subscribe(data => { this.getWhatIfGridDataCallback(data, pageNum) });
    }
    catch (err) {
       this.genericComponent.showErrorMessage(survConst.errorMsg.noDataErr);
    }
  }


  getWhatIfGridDataCallback(data, pageNum: number) {

    if (Util.checkResponse(data)) {
      this.paginationData = this.genericComponent.setPagination({}, pageNum, this.dataSize);
      let gridData = data.resultData;
      for (var i = 0; i < gridData.length; i++) {
        if (gridData[i].whscrStatus == 'P')
          gridData[i].whscrStatus = "Pending";
        else if (gridData[i].whscrStatus == 'I')
          gridData[i].whscrStatus = "Initiated";
        else if (gridData[i].whscrStatus == 'C')
          gridData[i].whscrStatus = "Completed";

      }
      this.gridOptions.api.setRowData(gridData);
    }
  }

  whatIfAddButtonClickEvent() {
    this.whatifModFlag = false;
    this.whatIfActionForm.reset();
    this.showWhatIfActionForm = true;
    this.whatIfActionFormTitle = 'Add Record';
    this.runDateOptions = Object.assign({}, this.genericComponent.myDatePickerOptions);
    this.runDateOptions.componentDisabled = false;
    this.runDateOptions = this.genericComponent.setMaxDate(this.runDateOptions, this.runDate);
    this.whatIfActionForm.patchValue({
      whscrRunDate: {
        date: this.genericComponent.getDateObject(this.runDate), formatted: moment(this.runDate).format('DD-MMM-YYYY')
      }
    });
    // this.maxBussDate = this.genericComponent.getDateObject(this.runDate);
    this.getIndexLovdata(this.runDate, null);
  }

  whatIfModifyButtonClickEvent() {
    this.whatifModFlag = true;
    this.whatIfActionForm.reset();

    if (this.gridApiWhatIf.getSelectedRows().length > 0) {
      this.showWhatIfActionForm = true;
      if (this.loginData.userId !== this.gridApiWhatIf.getSelectedRows()[0].whscrCrtBy) {
        this.genericComponent.showErrorMessage(MessageConstant.MrCache.ModifyAuthorization);
        return;
      }
      if (this.gridApiWhatIf.getSelectedRows()[0].whscrStatus == "Pending") {
        this.whatIfActionFormTitle = 'Modify Record';

        var rowData = this.gridApiWhatIf.getSelectedRows()[0];
        this.runDateOptions = Object.assign({}, this.genericComponent.myDatePickerOptions);
        this.runDateOptions = this.genericComponent.setMaxDate(this.runDateOptions, this.runDate);
        this.getIndexLovdata(this.gridApiWhatIf.getSelectedRows()[0].whscrRunDate, null);
      } else {
        this.genericComponent.showErrorMessage(MessageConstant.WhatIf.AlreadyInitiated);
        this.showWhatIfActionForm = false;
      }

    } else {
      this.genericComponent.showErrorMessage(MessageConstant.TransactionForm.ModRowSelection);
    }
  }

  fillModForm(data, form: FormGroup) {
    Object.keys(form.value).forEach(name => {
      if (name == 'whscrIndexName') {
        form.controls[name].setValue(this.indexNames.find(x => x.key == data[name]));
      } else if (name == 'whscrFromTime') {
        form.controls[name].setValue(this.genericComponent.getTimeObject(data[name]));
      } else if (name == 'whscrToTime') {
        form.controls[name].setValue(this.genericComponent.getTimeObject(data[name]));
      } else if (name == 'whatifMktcloseTime') {
        form.controls[name].setValue(this.genericComponent.getTimeObject(data[name]));
      } else if (name == 'whscrRunDate') {
        form.patchValue({
          whscrRunDate: {
            date: this.genericComponent.getDateObject(data[name]), formatted: moment(data[name]).format('DD-MMM-YYYY')
          }
        });
      } else {
        form.controls[name].setValue(data[name]);
      }
    });
    this.whatifModFlag = false;
  }


  whatIfClearButtonClickEvent() {
    this.whatIfSearchForm.reset();
    this.showWhatIfActionForm = false;
    this.messageService.clearMessages();
    this.gridOptions.api.setRowData([]);
    this.paginationData = {};
  }

  geWhatIfData() {
    this.restService.postRequest('getWhatIfRunId').subscribe(data => { this.getWhatIfRunIdCallback(data) });
    this.restService.postRequest('getUadUserGroup').subscribe(data => { this.setMinRunDate(data) });
    this.whatIfSearchButtonClickEvent(this.whatIfSearchForm);
  }

  getWhatIfRunIdCallback(data) {
    if (Util.checkResponse(data)) {
      this.whatIfSelRunId = JSON.parse(data.resultData);
    } else {
      this.genericComponent.showErrorMessage(MessageConstant.ErrorMessage.NoDataFound);
    }
  }

  setMinRunDate(data) {
    if (Util.checkResponse(data)) {
      this.runDate.setDate(new Date(data.resultData.funcWorkingdate).getDate() - 1);
      var dt = new Date(data.resultData.funcWorkingdate);
      this.runDate = dt;
      this.whatIfActionForm.controls["whscrRunDate"].setValue(dt);
    }
  }

  getIndexLovDataCallback(data) {
    this.indexNames = [];
    this.whatIfActionForm.controls['whscrIndexName'].setValue(null);
    if (Util.checkResponse(data)) {
      this.indexNames = JSON.parse(data.resultData);
    }
    if (this.whatifModFlag) {
      var rowData = this.gridApiWhatIf.getSelectedRows()[0];
      this.fillModForm(rowData, this.whatIfActionForm);
    }
  }


  /*Symbol LOV*/
  popupdata = {
    header: 'Symbol',
    srchFields: [
      {
        name1: 'Symbol',
        value1: ''
      }, {
        name2: 'Series',
        value2: ''
      }
    ],

    columnDefs: [
      { headerName: 'Symbol', field: 'symbol', width: 450 },
      { headerName: 'Series', field: 'series', width: 450 }
    ]
  }

  getLovData(obj) {
    this.requestData = {};
    this.messageService.clearMessages();
    var jsonObject = {
      symbol: obj.searchCode != "" && obj.searchCode != null ? obj.searchCode : null,
      series: obj.searchName != "" && obj.searchName != null ? obj.searchName : null,
    };
    this.restService.postRequestWithParamater('getSymbolSeriesCount', jsonObject).subscribe(data => { this.getSymbolSeriesCountCallback(data, obj) });
  }

  getSymbolSeriesCountCallback(data, obj) {
    if (Util.checkResponse(data)) {
      this.dataSize = data.resultData;
      if (data.resultData > 0)
        this.getSymbolSeriesData(obj);
    } else {
      this.genericComponent.showErrorMessage(survConst.errorMsg.noDataErr);
    }
  }

  getSymbolSeriesData(obj) {
    try {
      this.requestData = {};
      this.requestData.symbol = obj.searchCode;
      this.requestData.series = obj.searchName;
      this.requestData.pageSize = survConst.RECORDS_PER_PAGE;
      this.requestData.from = obj.pageNum == 1 ? 0 : ((obj.pageNum - 1) * survConst.RECORDS_PER_PAGE);
      this.symbolSeriesPaginationData = {};
      this.restService.postRequestWithParamater('getSymbolSeriesData', this.requestData).subscribe(data => { this.getSymbolSeriesDataCallback(data, obj.pageNum) });
    }
    catch (err) {
      this.genericComponent.showErrorMessage(survConst.errorMsg.noDataErr);
    }
  }

  getSymbolSeriesDataCallback(data, pageNum: number) {
    if (Util.checkResponse(data)) {
      this.searchLovData = data.resultData;
      this.symbolSeriesPaginationData = this.genericComponent.setPagination({}, pageNum, this.dataSize);
    } else {
      this.genericComponent.showErrorMessage(survConst.errorMsg.noDataErr);
    }
  }


  populateLovData(obj) {
    this.whatIfActionForm.patchValue({ whscrSeries: obj.searchName });
    this.whatIfActionForm.patchValue({ whscrSymbol: obj.searchCode });
  }

  /*End*/

  whatIfSubmitData(form: FormGroup) {
    if (!(this.whatIfActionForm.controls.whscrFromTime.invalid || this.whatIfActionForm.controls.whscrToTime.invalid || this.whatIfActionForm.controls.whscrIndexName.invalid ||
      this.whatIfActionForm.controls.whatifMktcloseTime.invalid || this.whatIfActionForm.controls.whatifLargeUnexecutedQty.invalid || this.whatIfActionForm.controls.whatifLargeCxlQty.invalid
      || this.whatIfActionForm.controls.whatifPectAwayLtp.invalid || this.whatIfActionForm.controls.whatifSlPectAwayLtp.invalid || this.whatIfActionForm.controls.whscrRunDate.invalid)) {
      let tempObj = this.whatIfActionForm.getRawValue();
      var fromTime = tempObj.whscrFromTime.hour + ":" + tempObj.whscrFromTime.minute + ":" + tempObj.whscrFromTime.second;
      var toTime = tempObj.whscrToTime.hour + ":" + tempObj.whscrToTime.minute + ":" + tempObj.whscrToTime.second;
      var closeTime = tempObj.whatifMktcloseTime.hour + ":" + tempObj.whatifMktcloseTime.minute + ":" + tempObj.whatifMktcloseTime.second;
      var bussDate = tempObj.whscrRunDate.formatted ? new Date(moment(tempObj.whscrRunDate.formatted, 'DD-MMM-YYYY').format('YYYY-MM-DD')) : "";
      if (!this.genericComponent.compareTimes(fromTime, toTime)) {
        this.genericComponent.showErrorMessage(MessageConstant.ValidationMessage.TimeComparison);
        return false;
      }

      if (true) {
        tempObj.whscrIndexName = tempObj.whscrIndexName != null ? tempObj.whscrIndexName.key : null;
        tempObj.whscrRunDate = bussDate;
        tempObj.whscrFromTime = fromTime;
        tempObj.whscrToTime = toTime;
        tempObj.whatifMktcloseTime = closeTime;
        this.restService.postRequestWithParamater('addWhatIfData', tempObj).subscribe(data => { this.whatIfSubmitButtonCallBack(data) });
      }
      if(true) {
        let tempObj = this.whatIfActionForm.getRawValue();
        tempObj.whscrIndexName = tempObj.whscrIndexName != null ? tempObj.whscrIndexName.key : null;
        tempObj.whscrRunId = this.gridApiWhatIf.getSelectedRows()[0].whscrRunId;
        tempObj.whscrRunDate = bussDate;
        tempObj.whscrFromTime = fromTime;
        tempObj.whscrToTime = toTime;
        tempObj.whatifMktcloseTime = closeTime;
        this.restService.postRequestWithParamater('modifyWhatIfData', tempObj).subscribe(data => { this.whatIfSubmitButtonCallBack(data) });
      }
    }
  }

  whatIfSubmitButtonCallBack(data) {

    if (Util.checkResponse(data)) {
      this.showWhatIfActionForm = false;
      this.messageService.putMessage(data);
      this.geWhatIfData();
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  closeButtonClickEvent() {
    this.submitted = false;
    this.whatIfActionForm.reset();
    this.showWhatIfActionForm = false;
    this.messageService.clearMessages();
  }

  getIndexLovdata(rDate: any, event: IMyDateModel) {
    var condition;
    if (rDate != null) {
      condition = rDate;
    } else {
      condition = new Date(moment(event.formatted, 'DD-MMM-YYYY').format('YYYY-MM-DD'));
    }
    var jsonData = {
      runDate: condition
    }
    this.restService.postRequestWithParamater('getIndexLovdata', jsonData).subscribe(data => { this.getIndexLovDataCallback(data) });
  }



}
