declare var $: any;
import * as moment from 'moment';
import { SelectItem } from 'primeng/api';
import { Subscription } from 'rxjs/Subscription';
import { GridOptions, GridApi } from 'ag-grid';
import { IMyOptions, IMyDateModel } from 'mydatepicker';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbTimeStruct, NgbTimepickerConfig } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, ViewChild, Renderer, EventEmitter, Output } from '@angular/core';

import Util from '../../../ng-utility/util';
import { CONSTANT } from '../../../ng-utility/ng.constant';
import { GridColumnDefs } from '../../../ng-utility/grid.config';
import { MessageConstant } from '../../../ng-utility/ng.message.constant';

import { RestService, Command } from '../../../ng-service/rest.service';
import { DataShareService } from '../../../ng-service/data.share.service';
import { WebSocketService } from '../../../ng-service/web.socket.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';

@Component({
  templateUrl: './market.watch.component.html',
  styleUrls: ['./market.watch.component.css']
})

export class MarketWatchComponent implements OnInit {

  private subscription: Subscription;
  private loginSubscription: Subscription;

  private searchForm: FormGroup;
  private actionForm: FormGroup;

  private gridOptions: GridOptions;
  private gridApiMarketWatch: GridApi;

  private loginData: any;
  private runId: any = [];
  private runDate: Date;
  private maxBussDate: any;
  private runDateOptions: IMyOptions;
  private indexNames: any = [];
  private searchLovData: any;

  private dataSize: number;
  private requestData: any = {};
  private paginationData: any = {};
  private symbolSeriesPaginationData: any = {};

  private queryRunDateOptions: IMyOptions;
  private searchQueryForm: FormGroup;
  private gridQueryApi: GridApi;
  private queryGridOptions: GridOptions;

  constructor(private genericComponent: GenericComponent, private restService: RestService,
    private dataShareService: DataShareService, private router: Router, private ngbTimepickerConfig: NgbTimepickerConfig) {
    this.subscription = this.restService.commands.subscribe(c => this.handleCommand(c));
    this.loginSubscription = this.dataShareService.loginMessage.subscribe(message => this.loginData = message);

    this.runDate = new Date();
    ngbTimepickerConfig.seconds = true;
    ngbTimepickerConfig.spinners = false;

    this.gridOptions = {
      rowData: [],
      floatingFilter: true,
      columnDefs: GridColumnDefs.ViewMarketReplay.SetCriteria
    };
    this.queryGridOptions = {
      rowData: [],
      floatingFilter: true,
      columnDefs: GridColumnDefs.ViewMarketReplay.Query
    };

    this.searchForm = new FormGroup({
      mwscrRunId: new FormControl()
    });
    this.searchQueryForm = new FormGroup({
      mwscrBussDate: new FormControl('', [Validators.required])
    });
    this.actionForm = new FormGroup({
      mwscrRunId: new FormControl(),
      mwscrIndexName: new FormControl(),
      mwscrSymbol: new FormControl(),
      mwscrSeries: new FormControl(),
      mwscrFromTime: new FormControl('', [Validators.required]),
      mwscrBussDate: new FormControl(),
      mwscrToTime: new FormControl('', [Validators.required]),
      mwscrStatus: new FormControl(),
      mwscrPectAwayLtp: new FormControl('', [Validators.max(100), Validators.min(0), Validators.pattern('^([0-9]{0,2})+(.[0-9]{0,2})?$')]),
      mwscrSlPectAwayLtp: new FormControl('', [Validators.max(100), Validators.min(0), Validators.pattern('^([0-9]{0,2})+(.[0-9]{0,2})?$')]),
      mwscrLargeCxlQty: new FormControl('', Validators.pattern('^[0-9]*$')),
      mwscrLargeUnexecutedQty: new FormControl('', Validators.pattern('^[0-9]*$')),
    });
  }

  handleCommand = (command: Command) => {
    switch (command.name) {
      case 'Search': this.searchButtonClickEvent(this.searchForm); break;
      case 'Modify': this.modifyButtonClickEvent(); break;
      case 'Clear': this.clearButtonClickEvent(); break;
      case 'Add': this.addButtonClickEvent(); break;
      case 'Submit': this.submitButtonClickEvent(this.actionForm); break;
      case 'Close': this.closeButtonClickEvent(); break;
      case 'Initiate': this.initiateButtonClickEvent(); break;
      case 'Display': this.displayButtonClickEvent(); break;
      case 'Delete': this.deleteButtonClickEvent(); break;
    }
  }

  get f() {
    return this.actionForm.controls;
  }

  ngOnInit() {
    this.genericComponent.initOpenForm();
    this.initSetCriteriaTab();
  }

  public tabChangeEvent(event) {
    if (event.index == 0) {
      this.initSetCriteriaTab();
    } else if (event.index == 1) {
      this.initQueryTab();
    }
  }

  /**
   * Set Criteria
   */
  private initSetCriteriaTab() {
    this.actionForm.reset();
    this.genericComponent.resetTransactionForm();
    this.searchButtonClickEvent(this.actionForm);
    this.getMinRunDate();
  }

  searchButtonClickEvent(form: FormGroup) {
    this.genericComponent.resetTransactionForm();
    this.requestData = {};
    this.requestData.runId = form.value.mwscrRunId != null ? form.value.mwscrRunId.key : form.value.mwscrRunId;
    this.restService.postRequestWithParamater('getMarketWatchGridCount', this.requestData).subscribe(data => { this.getMarketWatchGridCountCallback(data) });
  }

  getMarketWatchGridCountCallback(data) {
    if (Util.checkResponse(data)) {
      this.dataSize = data.resultData;
      this.getMarketWatchGridData(1);
    } else {
      this.gridOptions.api.setRowData([]);
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  getMarketWatchGridData(pageNum: number) {
    this.requestData.pageSize = CONSTANT.GridPagination.RecordPerPage;
    this.requestData.from = pageNum == 1 ? 0 : ((pageNum - 1) * CONSTANT.GridPagination.RecordPerPage);
    this.paginationData = {};
    this.restService.postRequestWithParamater('getMarketWatchGridData', this.requestData).subscribe(data => { this.getMarketWatchGridDataCallback(data, pageNum) });
  }

  getMarketWatchGridDataCallback(data, pageNum: number) {
    if (Util.checkResponse(data)) {
      this.paginationData = this.genericComponent.setPagination({}, pageNum, this.dataSize);
      let gridData = data.resultData;
      for (var i = 0; i < gridData.length; i++) {
        gridData[i].mwscrPectAwayLtp = Number(gridData[i].mwscrPectAwayLtp).toFixed(2);
        gridData[i].mwscrSlPectAwayLtp = Number(gridData[i].mwscrSlPectAwayLtp).toFixed(2);
        if (gridData[i].mwscrStatus == CONSTANT.MarketConstant.MR_REQ_PENDING_STATUS)
          gridData[i].mwscrStatus = CONSTANT.MarketConstant.MR_REQ_PENDING_STATUS_DESC;
        else if (gridData[i].mwscrStatus == CONSTANT.MarketConstant.MR_REQ_INITIATED_STATUS)
          gridData[i].mwscrStatus = CONSTANT.MarketConstant.MR_REQ_INITIATED_STATUS_DESC;
        else if (gridData[i].mwscrStatus == CONSTANT.MarketConstant.MR_REQ_COMPLETED_STATUS)
          gridData[i].mwscrStatus = CONSTANT.MarketConstant.MR_REQ_COMPLETED_STATUS_DESC;
        else if (gridData[i].mwscrStatus == CONSTANT.MarketConstant.MR_REQ_DELETED_STATUS)
          gridData[i].mwscrStatus = CONSTANT.MarketConstant.MR_REQ_DELETED_STATUS_DESC;
        else if (gridData[i].mwscrStatus == CONSTANT.MarketConstant.MR_REQ_ERROR_STATUS)
          gridData[i].mwscrStatus = CONSTANT.MarketConstant.MR_REQ_ERROR_STATUS_DESC;
      }
      this.gridOptions.api.setRowData(gridData);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
    this.getRunIdLov();
  }

  private getMinRunDate() {
    this.restService.postRequest('getMinRunDate').subscribe(data => { this.getMinRunDateCallBack(data) });
  }

  private getMinRunDateCallBack(data) {
    if (Util.checkResponse(data)) {
      this.runDate.setDate(new Date(data.resultData.funcWorkingdate).getDate() - 1);
      let date = new Date(data.resultData.funcWorkingdate);
      this.runDate = date;
      this.actionForm.controls['mwscrBussDate'].setValue(date);
    }
  }

  getRunIdLov() {
    this.restService.postRequest('getRunId').subscribe(data => { this.getRunIdLovCallback(data) });
  }

  getRunIdLovCallback(data) {
    if (Util.checkResponse(data)) {
      this.runId = JSON.parse(data.resultData);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public clearButtonClickEvent() {
    this.searchForm.reset();
    this.genericComponent.resetTransactionForm();
    this.gridOptions.api.setRowData([]);
    this.paginationData = {};
  }

  /**
   * Start
   * Floating LOV 
   */
  popupdata = {
    header: 'Symbol',
    srchFields: [
      {
        name1: 'Symbol',
        value1: ''
      }, {
        name2: 'Series',
        value2: ''
      }
    ],
    columnDefs: [
      { headerName: 'Symbol', field: 'symbol', width: 450 },
      { headerName: 'Series', field: 'series', width: 450 }
    ]
  }

  getFloatingLovData(obj) {
    this.requestData = {};
    this.genericComponent.clearMessages();
    var jsonObject = {
      symbol: obj.searchCode != '' && obj.searchCode != null ? obj.searchCode : null,
      series: obj.searchName != '' && obj.searchName != null ? obj.searchName : null,
    };
    this.restService.postRequestWithParamater('getSymbolSeriesCount', jsonObject).subscribe(data => { this.getSymbolSeriesCountCallback(data, obj) });
  }

  getSymbolSeriesCountCallback(data, obj) {
    if (Util.checkResponse(data)) {
      this.dataSize = data.resultData;
      this.getSymbolSeriesData(obj);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  getSymbolSeriesData(obj) {
    this.requestData = {};
    this.requestData.symbol = obj.searchCode;
    this.requestData.series = obj.searchName;
    this.requestData.pageSize = CONSTANT.GridPagination.RecordPerPage;
    this.requestData.from = obj.pageNum == 1 ? 0 : ((obj.pageNum - 1) * CONSTANT.GridPagination.RecordPerPage);
    this.symbolSeriesPaginationData = {};
    this.restService.postRequestWithParamater('getSymbolSeriesData', this.requestData).subscribe(data => { this.getSymbolSeriesDataCallback(data, obj.pageNum) });
  }

  getSymbolSeriesDataCallback(data, pageNum: number) {
    if (Util.checkResponse(data)) {
      this.searchLovData = data.resultData;
      this.symbolSeriesPaginationData = this.genericComponent.setPagination({}, pageNum, this.dataSize);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  populateLovData(obj) {
    this.actionForm.patchValue({ mwscrSeries: obj.searchName });
    this.actionForm.patchValue({ mwscrSymbol: obj.searchCode });
  }

  /**
   * End
   * Floating LOV
   */

  public addButtonClickEvent() {
    this.actionForm.reset();
    this.genericComponent.openAddForm();
    this.runDateOptions = this.genericComponent.myDatePickerOptions;
    this.runDateOptions.componentDisabled = false;
    this.runDateOptions = Object.assign({}, this.genericComponent.myDatePickerOptions);
    this.runDateOptions = this.genericComponent.setMaxDate(this.runDateOptions, this.runDate);
    this.actionForm.patchValue({
      mwscrBussDate: {
        date: this.genericComponent.getDateObject(this.runDate), formatted: moment(this.runDate).format('DD-MMM-YYYY')
      }
    });
    this.maxBussDate = this.genericComponent.getDateObject(this.runDate);
    this.getIndexLovdata(this.runDate, null);
  }

  public modifyButtonClickEvent() {
    this.actionForm.reset();
    if (this.genericComponent.checkModifyRecordSelection(this.gridApiMarketWatch)) {
      if (this.loginData.userId !== this.gridApiMarketWatch.getSelectedRows()[0].mwscrCrtBy) {
        this.genericComponent.showErrorMessage(MessageConstant.MrCache.ModifyAuthorization);
        return;
      }
      if (this.gridApiMarketWatch.getSelectedRows()[0].mwscrStatus == CONSTANT.MarketConstant.MR_REQ_PENDING_STATUS_DESC) {
        this.genericComponent.openModForm();
        this.runDateOptions = Object.assign({}, this.genericComponent.myDatePickerOptions);
        this.runDateOptions = this.genericComponent.setMaxDate(this.runDateOptions, this.runDate);
        this.getIndexLovdata(this.gridApiMarketWatch.getSelectedRows()[0].mwscrBussDate, null);
      } else {
        this.genericComponent.resetTransactionForm();
        this.genericComponent.showErrorMessage(MessageConstant.MrCache.MrAlreadyInitiated);
      }
    }else{
      this.genericComponent.showWarningMessage(MessageConstant.MarketWatch.RowToModify);
    }
  }

  private getIndexLovdata(rDate: any, event: IMyDateModel) {
    var condition;
    if (rDate != null) {
      condition = rDate;
    } else {
      condition = new Date(moment(event.formatted, 'DD-MMM-YYYY').format('YYYY-MM-DD'));
    }
    var jsonData = {
      runDate: condition
    }
    this.restService.postRequestWithParamater('getIndexLovdata', jsonData).subscribe(data => { this.getIndexLovDataCallback(data) });
  }

  private getIndexLovDataCallback(data) {
    this.indexNames = [];
    this.actionForm.controls['mwscrIndexName'].setValue(null);
    if (Util.checkResponse(data)) {
      this.indexNames = JSON.parse(data.resultData);
    }
    if (!this.genericComponent.transactionFlag) {
      var rowData = this.gridApiMarketWatch.getSelectedRows()[0];
      this.fillForm(rowData, this.actionForm);
    }
  }

  private fillForm(data, form: FormGroup) {
    Object.keys(form.value).forEach(name => {
      if (name == 'mwscrIndexName') {
        form.controls[name].setValue(this.indexNames.find(x => x.key == data[name]));
      } else if (name == 'mwscrFromTime') {
        form.patchValue({
          mwscrFromTime: this.genericComponent.getTimeObject(data[name])
        });
      } else if (name == 'mwscrToTime') {
        form.patchValue({
          mwscrToTime: this.genericComponent.getTimeObject(data[name])
        });
      } else if (name == 'mwscrBussDate') {
        form.patchValue({
          mwscrBussDate: {
            date: this.genericComponent.getDateObject(data[name]), formatted: moment(data[name]).format('DD-MMM-YYYY')
          }
        });
      } else {
        form.controls[name].setValue(data[name]);
      }
    });
  }

  public submitButtonClickEvent(form) {
    if (this.genericComponent.transactionFlag == null) {
      return;
    }
    this.genericComponent.clearMessages();
    let control = form.controls;
    if (control.mwscrBussDate.invalid || control.mwscrIndexName.invalid || control.mwscrFromTime.invalid || control.mwscrToTime.invalid
      || control.mwscrPectAwayLtp.invalid || control.mwscrSlPectAwayLtp.invalid || control.mwscrLargeCxlQty.invalid || control.mwscrLargeUnexecutedQty.invalid) {
      this.genericComponent.showErrorMessage(MessageConstant.ErrorMessage.EnterValidValue);
      return;
    }
    if (this.genericComponent.transactionFlag) {
      this.addRecordEvent(form);
    } else {
      this.modifyRecordEvent(form)
    }
  }

  private addRecordEvent(form) {
    var data = form.getRawValue();
    this.setDataToObject(data);
    if (!this.genericComponent.compareTimes(data.mwscrFromTime, data.mwscrToTime)) {
      this.genericComponent.showErrorMessage(MessageConstant.ValidationMessage.TimeComparison);
      return;
    }
    this.restService.postRequestWithParamater('addReplayCriteria', data).subscribe(data => { this.submitButtonCallBack(data) });
  }

  private modifyRecordEvent(form) {
    var data = form.getRawValue();
    this.setDataToObject(data);
    if (!this.genericComponent.compareTimes(data.mwscrFromTime, data.mwscrToTime)) {
      this.genericComponent.showErrorMessage(MessageConstant.ValidationMessage.TimeComparison);
      return;
    }
    this.restService.postRequestWithParamater('modifyReplayCriteria', data).subscribe(data => { this.submitButtonCallBack(data) });
  }

  private setDataToObject(data) {
    data.mwscrIndexName = data.mwscrIndexName != null ? data.mwscrIndexName.key : null;
    data.mwscrToTime = data.mwscrToTime.hour + ':' + data.mwscrToTime.minute + ':' + data.mwscrToTime.second;
    data.mwscrFromTime = data.mwscrFromTime.hour + ':' + data.mwscrFromTime.minute + ':' + data.mwscrFromTime.second;
    data.mwscrBussDate = data.mwscrBussDate.formatted ? new Date(moment(data.mwscrBussDate.formatted, 'DD-MMM-YYYY').format('YYYY-MM-DD')) : '';
  }

  private submitButtonCallBack(data) {
    if (Util.checkResponse(data)) {
      this.genericComponent.showSuccessMessage(data.responseMsg);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public closeButtonClickEvent() {
    this.actionForm.reset();
    this.genericComponent.resetTransactionForm();
  }

  public initiateButtonClickEvent() {
    this.actionForm.reset();
    this.genericComponent.resetTransactionForm();
    if (this.genericComponent.checkModifyRecordSelection(this.gridApiMarketWatch)) {
      var data = this.gridApiMarketWatch.getSelectedRows()[0];
      if (data.mwscrStatus != undefined && data.mwscrStatus != null
        && data.mwscrStatus != '' && data.mwscrStatus == CONSTANT.MarketConstant.MR_REQ_PENDING_STATUS_DESC) {
        this.restService.postRequestWithParamater('pushMrRequestCache', data).subscribe(data => { this.initiateButtonClickCallBack(data) });
      } else {
        this.genericComponent.showErrorMessage(MessageConstant.MrCache.MrAlreadyInitiated);
      }
    }else{
      this.genericComponent.showWarningMessage(MessageConstant.MarketWatch.RowToInitiate);
    } 
  }

  private initiateButtonClickCallBack(data) {
    if (Util.checkResponse(data)) {
      this.searchButtonClickEvent(this.searchForm);
      this.genericComponent.showSuccessMessage(data.responseMsg);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public deleteButtonClickEvent() {
    this.actionForm.reset();
    this.genericComponent.resetTransactionForm();
    if (this.genericComponent.checkModifyRecordSelection(this.gridApiMarketWatch)) {
      var data = this.gridApiMarketWatch.getSelectedRows()[0];
      if (data.mwscrStatus != undefined && data.mwscrStatus != null
        && data.mwscrStatus != '' && data.mwscrStatus == CONSTANT.MarketConstant.MR_REQ_COMPLETED_STATUS_DESC) {
        this.restService.postRequestWithParamater('modifyDeleteStatus', data).subscribe(data => { this.deleteButtonClickCallBack(data) });
      } else {
        this.genericComponent.showErrorMessage(MessageConstant.MrCache.MrNotCompleted);
      }
    }else{
      this.genericComponent.showWarningMessage(MessageConstant.MarketWatch.RowToDelete);
    }
  }

  private deleteButtonClickCallBack(data) {
    if (Util.checkResponse(data)) {
      this.searchButtonClickEvent(this.searchForm);
      this.genericComponent.showSuccessMessage(data.responseMsg);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  public displayButtonClickEvent() {
    this.actionForm.reset();
    this.genericComponent.resetTransactionForm();
    if (this.genericComponent.checkModifyRecordSelection(this.gridApiMarketWatch)) {
      var data = this.gridApiMarketWatch.getSelectedRows()[0];
      var jsonObject = {
        mwscrRunId: data.mwscrRunId
      };
      if (data.mwscrStatus != undefined && data.mwscrStatus != null
        && data.mwscrStatus != '' && data.mwscrStatus != CONSTANT.MarketConstant.MR_REQ_PENDING_STATUS_DESC) {
        this.restService.postRequestWithParamater('getStatusCache', jsonObject).subscribe(data => { this.displayButtonClickCallBack(data) });
      } else {
        this.genericComponent.showErrorMessage(MessageConstant.MrCache.MrNotCompleted);
      }
    }else{
      this.genericComponent.showWarningMessage(MessageConstant.MarketWatch.RowToDisplay);
    }
  }

  private displayButtonClickCallBack(data) {
    if (Util.checkResponse(data)) {
      if (data.resultData.mrReqStatus == CONSTANT.MarketConstant.MR_REQ_COMPLETED_STATUS) {
        this.router.navigateByUrl('/marketReplay', { skipLocationChange: true });
        this.dataShareService.setMwscrHeaderData(data.resultData);
      } else {
        this.genericComponent.showErrorMessage(MessageConstant.MrCache.CacheConstruction);
      }
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  onMarketWatchGridReady(params) {
    this.gridApiMarketWatch = params.api;
  }

  /**
    * Query
    */
  private initQueryTab() {
    this.genericComponent.clearMessages();
    this.paginationData = {};
    this.queryGridOptions.api.setRowData([]);
    this.queryRunDateOptions = this.genericComponent.myDatePickerOptions;
  }

  private getQueryMinRunDate() {
    this.restService.postRequest('getMinRunDate').subscribe(data => { this.getQueryMinRunDateCallBack(data) });
  }

  private getQueryMinRunDateCallBack(data) {
    if (Util.checkResponse(data)) {
      var dt = new Date(data.resultData.funcWorkingdate);
      this.queryRunDateOptions = Object.assign({}, this.genericComponent.myDatePickerOptions);
      this.queryRunDateOptions = this.genericComponent.setMaxDate(this.queryRunDateOptions, dt);
      this.searchQueryForm.patchValue({
        mwscrBussDate: {
          date: this.genericComponent.getDateObject(dt), formatted: moment(dt).format('DD-MMM-YYYY')
        }
      });
    }
  }

  searchButtonQueryClickEvent(form: FormGroup) {
    this.genericComponent.clearMessages();
    if (!form.valid) {
      return;
    }
    let requestDate = form.value.mwscrBussDate.formatted ? new Date(moment(form.value.mwscrBussDate.formatted, 'DD-MMM-YYYY').format('YYYY-MM-DD')) : '';
    var jsonData = {
      mwscrBussDate: requestDate
    }
    this.restService.postRequestWithParamater('getQueryGridCount', jsonData).subscribe(data => { this.getQueryGridCountCallback(data) });
  }

  getQueryGridCountCallback(data) {
    if (Util.checkResponse(data)) {
      this.dataSize = data.resultData;
      this.getQueryGridData(1);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  getQueryGridData(pageNum: number) {
    this.requestData.mwscrBussDate = this.searchQueryForm.value.mwscrBussDate.formatted ? new Date(moment(this.searchQueryForm.value.mwscrBussDate.formatted, 'DD-MMM-YYYY').format('YYYY-MM-DD')) : '';;
    this.requestData.pageSize = CONSTANT.GridPagination.RecordPerPage;
    this.requestData.from = pageNum == 1 ? 0 : ((pageNum - 1) * CONSTANT.GridPagination.RecordPerPage);
    this.paginationData = {};
    this.restService.postRequestWithParamater('getQueryGridData', this.requestData).subscribe(data => { this.getQueryGridDataCallback(data, pageNum) });
  }

  getQueryGridDataCallback(data, pageNum: number) {
    if (Util.checkResponse(data)) {
      this.paginationData = this.genericComponent.setPagination({}, pageNum, this.dataSize);
      let gridData = data.resultData;
      for (var i = 0; i < gridData.length; i++) {
        gridData[i].mwscrPectAwayLtp = Number(gridData[i].mwscrPectAwayLtp).toFixed(2);
        gridData[i].mwscrSlPectAwayLtp = Number(gridData[i].mwscrSlPectAwayLtp).toFixed(2);
        if (gridData[i].mwscrStatus == CONSTANT.MarketConstant.MR_REQ_PENDING_STATUS)
          gridData[i].mwscrStatus = CONSTANT.MarketConstant.MR_REQ_PENDING_STATUS_DESC;
        else if (gridData[i].mwscrStatus == CONSTANT.MarketConstant.MR_REQ_INITIATED_STATUS)
          gridData[i].mwscrStatus = CONSTANT.MarketConstant.MR_REQ_INITIATED_STATUS_DESC;
        else if (gridData[i].mwscrStatus == CONSTANT.MarketConstant.MR_REQ_COMPLETED_STATUS)
          gridData[i].mwscrStatus = CONSTANT.MarketConstant.MR_REQ_COMPLETED_STATUS_DESC;
        else if (gridData[i].mwscrStatus == CONSTANT.MarketConstant.MR_REQ_DELETED_STATUS)
          gridData[i].mwscrStatus = CONSTANT.MarketConstant.MR_REQ_DELETED_STATUS_DESC;
        else if (gridData[i].mwscrStatus == CONSTANT.MarketConstant.MR_REQ_ERROR_STATUS)
          gridData[i].mwscrStatus = CONSTANT.MarketConstant.MR_REQ_ERROR_STATUS_DESC;
      }
      this.queryGridOptions.api.setRowData(gridData);
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  queryClearButtonClickEvent() {
    this.searchQueryForm.reset();
    this.genericComponent.clearMessages();
    this.queryGridOptions.api.setRowData([]);
    this.paginationData = {};
  }

  onQueryGridReady(params) {
    this.gridQueryApi = params.api;
  }

}