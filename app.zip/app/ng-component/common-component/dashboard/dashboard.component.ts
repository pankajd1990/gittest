import { MenuItem } from 'primeng/api';
import { Router } from '@angular/router';
import { Component, OnInit, Renderer } from '@angular/core';

import { RestService } from '../../../ng-service/rest.service';
import { MessageConstant } from '../../../ng-utility/ng.message.constant';
import { DataShareService } from '../../../ng-service/data.share.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';

@Component({
    templateUrl: './dashboard.component.html'
})

export class DashboardComponent implements OnInit {

    public items: MenuItem[];
    public sucessData: any = null;

    constructor(private router: Router, private renderer: Renderer,
        private dataShareService: DataShareService, public genericComponent: GenericComponent, private restService: RestService) { }

    ngOnInit() {
        this.dataShareService.applicationMessage.subscribe(message => this.sucessData = JSON.parse(message));

        this.items = this.sucessData.Menu;
        this.genericComponent.showFormTitle = false;

        this.renderer.listenGlobal('document', 'keydown', event => {
            if (event.keyCode === 27) {
                var currentPage = this.router.url;
                currentPage = currentPage.trim();
                if (currentPage.startsWith('/')) {
                    currentPage = currentPage.substring(1);
                }
                if (currentPage.indexOf('/') > 0) {
                    this.genericComponent.showConfirmDialogEvent(MessageConstant.ConfirmDialog.confirmation, MessageConstant.ConfirmDialog.closeMessage);
                }
            };
        });
    }

}