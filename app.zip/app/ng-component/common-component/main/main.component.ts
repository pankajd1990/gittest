import { Router } from '@angular/router';
import { Component } from '@angular/core';
import { MessageService } from '../../../ng-service/message.service';
import { LoaderService } from '../../../ng-service/loader.service';
import {Idle, DEFAULT_INTERRUPTSOURCES} from '@ng-idle/core';
import {Keepalive} from '@ng-idle/keepalive';
import {survConst} from '../../../ng-utility/survConst';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';
import { count } from 'rxjs/operators';
@Component({
  selector: 'ngcs-root',
  templateUrl: './main.component.html'
})

export class MainComponent {

  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;

  
  constructor(private router: Router, private messageService: MessageService,private idle: Idle, private keepalive: Keepalive,private genericComponent:GenericComponent) {


   }

  ngOnInit() {
    this.messageService.subscribeToMessages();
    this.idle.setIdle(survConst.IDLE_TIME);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(survConst.IDLE_WARNING_TIME);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => this.idleState = 'No longer idle.');
    this.idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.timedOut = true;
    });
    this.idle.onIdleStart.subscribe(() => this.idleState = '');
    this.idle.onTimeoutWarning.subscribe((countdown) => {
      this.genericComponent.showConfirmDialog=true;
      if(countdown==1){
        this.genericComponent.showConfirmDialog=false;
      }
      this.genericComponent.confirmDialogBody='Your session will expire in '+countdown;
      console.log('Your session will expire in '+countdown);
    });

    this.reset();
  
  } 


  reset() {
    this.idle.watch();
    this.idleState = '';
    this.timedOut = false;
   this.router.navigateByUrl('/login', { skipLocationChange: true });
  }




}