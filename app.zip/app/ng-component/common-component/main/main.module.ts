/**
 * Do not Change - START
 */
import * as Rx from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';

import { HttpModule } from '@angular/http';
import { TreeviewModule } from 'ngx-treeview';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxEchartsModule } from 'ngx-echarts';
import { AgGridModule } from 'ag-grid-angular';
import { MatMenuModule } from '@angular/material';
import { CookieService } from 'ngx-cookie-service';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgBootstrapFormValidationModule,CUSTOM_ERROR_MESSAGES } from 'ng-bootstrap-form-validation';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { DialogModule } from 'primeng/dialog';
import { CUSTOM_ERRORS } from '../../../ng-service/customErrorMessages';

/**
 * ng-module - START
 */
import { RouteModule } from '../../../ng-module/route.module';
import { PrimeModule } from '../../../ng-module/prime.module';
/**
 * ng-service - START
 */
import { RestService } from '../../../ng-service/rest.service';
import { LoaderService } from '../../../ng-service/loader.service';
import { MessageService } from '../../../ng-service/message.service';
import { WebSocketService } from '../../../ng-service/web.socket.service';
import { DataShareService } from '../../../ng-service/data.share.service';
/**
 * ng-directive - START
 */
import { ButtonTextDirective } from '../../../ng-directive/button.text.directive';
import { UpperCaseDirective } from '../../../ng-directive/upper.case.directive';

/**
 * ng-generic-component - START
 */
import { GenericComponent } from '../../generic-component/misc-component/generic.component';
import { CommonHeaderComponent } from '../../generic-component/common-header/common.header.component';
import { CommonDialogComponent } from '../../generic-component/common-dialog/common.dialog.component';
import { MarketHeaderComponent } from '../../generic-component/common-header/market.header.component';
import { ConfirmDialogComponent } from '../../generic-component/confirm.dialog/confirm.dialog.component';
import { CommonFloatingLovComponent } from '../../generic-component/common-floating-lov/common.floating.lov.component';
import { NgPaginationComponent } from '../../generic-component/ng-pagination/ng.pagination.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MyDatePickerModule } from 'mydatepicker';

/**
 * ng-common-component - START
 */
import { MainComponent } from './main.component';
import { LoginComponent } from '../login/login.component';
import { ApplicationComponent } from '../application/application.component';
import { DashboardComponent } from '../dashboard/dashboard.component';

/**
 * ng-administrator - START
 */
import { MapRoleMenuComponent } from '../../admin-component/map.role.menu/map.role.menu.component';
import { MapUserRoleComponent } from '../../admin-component/map.user.role/map.user.role.component';
import { MaintainRoleComponent } from '../../admin-component/maintain.role/maintain.role.component';
import { MaintainUserComponent } from '../../admin-component/maintain.user/maintain.user.component';
import { MaintainGroupComponent } from '../../admin-component/maintain.group/maintain.group.component';
import { MapRoleMenuFunctionComponent } from '../../admin-component/map.role.menu.function/map.role.menu.function.component';
import { RefreshCacheComponent } from '../../admin-component/refresh.cache/refresh.cache.component';
import { BusinessParametersComponent } from '../../admin-component/business.parameters/business.parameters.component';
import { ChangePasswordComponent } from '../../admin-component/change.password/change.password.component';

/**
 * ng-market-replay-component - START
 */
import { SetThresholdComponent } from '../../market-component/set.threshold/set.threshold.component';
import { MarketReplayComponent } from '../../market-component/market.replay/market.replay.component';
import { MarketWatchComponent } from '../../market-component/market.watch/market.watch.component';
import { WhatIfComponent } from '../../market-component/what.if/what.if.component'
import { GraphService } from '../../../ng-service/graph.service';
/**
 * Hot-keys
 */
import { HotkeyModule } from 'angular2-hotkeys';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
@NgModule({
  declarations: [
    MainComponent,
    ButtonTextDirective,
    UpperCaseDirective,
    CommonHeaderComponent,
    MarketHeaderComponent,
    CommonDialogComponent,
    LoginComponent,
    ApplicationComponent,
    DashboardComponent,
    MarketReplayComponent,
    MapRoleMenuComponent,
    MapUserRoleComponent,
    MaintainRoleComponent,
    MaintainUserComponent,
    MaintainGroupComponent,
    MapRoleMenuFunctionComponent,
    BusinessParametersComponent,
    RefreshCacheComponent,
    ChangePasswordComponent,
    SetThresholdComponent,
    WhatIfComponent,
    ConfirmDialogComponent,
    CommonFloatingLovComponent,
    MarketWatchComponent,
    NgPaginationComponent
  ],
  imports: [
    HttpModule,
    HttpClientModule,
    RouteModule,
    FormsModule,
    BrowserModule,
    MatMenuModule,
    PrimeModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    AgGridModule.withComponents([]),
    TreeviewModule.forRoot(),
    ProgressSpinnerModule,
    NgxSpinnerModule,
    NgxEchartsModule,
    NgBootstrapFormValidationModule.forRoot(),
    NgBootstrapFormValidationModule,
    HotkeyModule.forRoot(),
    AutoCompleteModule,
    NgbModule,
    DialogModule,
    MyDatePickerModule, NgIdleKeepaliveModule.forRoot()
  ],
  providers: [
    RestService,
    CookieService,
    WebSocketService,
    DataShareService,
    GenericComponent,
    MessageService,
    LoaderService, [{
      provide: CUSTOM_ERROR_MESSAGES,
      useValue: CUSTOM_ERRORS,
      multi: true
    }],
    GraphService
  ],
  schemas: [
    NO_ERRORS_SCHEMA
  ],
  // [{
  //   provide: CUSTOM_ERROR_MESSAGES,
  //   useValue: CUSTOM_ERRORS,
  //   multi: true
  // }],
  bootstrap: [MainComponent]
})

export class MainModule { }