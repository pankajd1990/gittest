import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import Util from '../../../ng-utility/util';
import { RestService } from '../../../ng-service/rest.service';
import { DataShareService } from '../../../ng-service/data.share.service';
import {EncrDecrService} from '../../../ng-service/encr-decr.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';

@Component({
  templateUrl: './login.component.html',
})

export class LoginComponent implements OnInit {

  public myForm: FormGroup;
  public resetPasswordForm: FormGroup;
  public errorMsg: String = null;
  displayResetPassword: boolean = false;
  displayPasswordPolicy: boolean = false;

  constructor(private router: Router, private restService: RestService,
    private dataShareService: DataShareService, public genericComponent: GenericComponent, private EncrDecr: EncrDecrService) { }

  ngOnInit() {
    this.errorMsg = null;
    this.myForm = new FormGroup({
      username: new FormControl(),
      password: new FormControl(),
    });
  }

  public onSubmit(form: FormGroup) {
    this.genericComponent.clearMessages();
    var jSonData = {
      uadUserId: form.value.username,
      uadUserPsswrd: btoa(form.value.password)
    };
    this.restService.postRequestWithParamater('loginUser', jSonData).subscribe(data => { this.loginCallBack(data) });
  };

  private loginCallBack(data) {
    if (Util.checkResponse(data)) {
      if (data.resultData.resetPwd === 'YES') {
        this.genericComponent.showWarningMessage(data.responseMsg);
        this.genericComponent.psswrdUserId = data.resultData.userId;
        this.genericComponent.showChangePasswordDialog();
      } else {
        this.genericComponent.setBusinessDate(new Date(data.resultData.sysDate));
        this.dataShareService.sendLoginMessage(data.resultData);
        this.router.navigateByUrl('/application', { skipLocationChange: true });
      }
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  resetButtonClickEvent() {
    this.myForm.reset();
  }

}