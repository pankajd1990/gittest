import { Router } from '@angular/router';
import { Component } from '@angular/core';

import Util from '../../../ng-utility/util';
import { RestService } from '../../../ng-service/rest.service';
import { DataShareService } from '../../../ng-service/data.share.service';
import { WebSocketService } from '../../../ng-service/web.socket.service';
import { GenericComponent } from '../../generic-component/misc-component/generic.component';

@Component({
  templateUrl: './application.component.html'
})

export class ApplicationComponent {

  public sucessData: any = null;
  public isMarketReplayVisible: Boolean = false;
  public isSurveillanceVisible: Boolean = false;

  constructor(private router: Router, private restService: RestService,
    private genericComponent: GenericComponent, private dataShareService: DataShareService, private webSocketService: WebSocketService) {
    this.webSocketService.connect();
  }

  ngOnInit() {
    this.dataShareService.loginMessage.subscribe(message => this.sucessData = message);
    if (this.sucessData.isApplication) {
      for (var i = 0, keys = Object.keys(this.sucessData.applications), ii = keys.length; i < ii; i++) {
        if (this.sucessData.applications[keys[i]] == 'Market Replay') {
          this.isMarketReplayVisible = true;
        }
        if (this.sucessData.applications[keys[i]] == 'Surveillance') {
          this.isSurveillanceVisible = true;
        }
      }
    }
  }

  openMarketReplayApplication() {
    this.restService.postRequest('marketReplayLogin').subscribe(data => { this.applicationLoginCallBack(data) });
  }

  private applicationLoginCallBack(data) {
    if (Util.checkResponse(data)) {
      this.dataShareService.sendApplicationMessage(data.resultData);
      this.router.navigateByUrl('/dashboard', { skipLocationChange: true });
    } else {
      this.genericComponent.showErrorMessage(data.responseMsg);
    }
  }

  openSurveillanceApplication() {

  }

}