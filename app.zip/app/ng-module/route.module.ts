import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from '../ng-component/common-component/login/login.component';
import { ApplicationComponent } from '../ng-component/common-component/application/application.component';

import { DashboardComponent } from '../ng-component/common-component/dashboard/dashboard.component';
import { MarketReplayComponent } from '../ng-component/market-component/market.replay/market.replay.component';

import { MapRoleMenuComponent } from '../ng-component/admin-component/map.role.menu/map.role.menu.component';
import { MapUserRoleComponent } from '../ng-component/admin-component/map.user.role/map.user.role.component';
import { MaintainRoleComponent } from '../ng-component/admin-component/maintain.role/maintain.role.component';
import { MaintainUserComponent } from '../ng-component/admin-component/maintain.user/maintain.user.component';
import { MaintainGroupComponent } from '../ng-component/admin-component/maintain.group/maintain.group.component';
import { MapRoleMenuFunctionComponent } from '../ng-component/admin-component/map.role.menu.function/map.role.menu.function.component';

import { MarketWatchComponent } from '../ng-component/market-component/market.watch/market.watch.component';
import { BusinessParametersComponent } from '../ng-component/admin-component/business.parameters/business.parameters.component';
import { RefreshCacheComponent } from '../ng-component/admin-component/refresh.cache/refresh.cache.component';
import { SetThresholdComponent } from '../ng-component/market-component/set.threshold/set.threshold.component';
import {WhatIfComponent} from '../ng-component/market-component/what.if/what.if.component';
const routes: Routes = [
    { path: '', redirectTo: '', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    { path: 'application', component: ApplicationComponent },
    { path: 'marketReplay', component: MarketReplayComponent },
    {
        path: 'dashboard', component: DashboardComponent,
        children: [
            { path: 'mapRoleMenu', component: MapRoleMenuComponent },
            { path: 'mapUserRole', component: MapUserRoleComponent },
            { path: 'maintainRole', component: MaintainRoleComponent },
            { path: 'maintainUser', component: MaintainUserComponent },
            { path: 'maintainGroup', component: MaintainGroupComponent },
            { path: 'mapRoleMenuFunction', component: MapRoleMenuFunctionComponent },
            { path: 'businessParameters', component: BusinessParametersComponent },
            { path: 'refreshCache', component: RefreshCacheComponent },
            { path: 'setThreshold', component: SetThresholdComponent },
            { path: 'replayCriteria', component: MarketWatchComponent },
            { path: 'whatIf', component: WhatIfComponent }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true })],
    exports: [RouterModule]
})

export class RouteModule { }