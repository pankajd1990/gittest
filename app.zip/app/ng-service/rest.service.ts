import Fingerprint2 from 'fingerprintjs2sync';

import { Subject } from 'rxjs/Subject';
import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Observable';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Params } from '@angular/router';
import { HotkeysService, Hotkey } from 'angular2-hotkeys';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { forkJoin } from 'rxjs';

import { CONSTANT } from '../ng-utility/ng.constant';
import { LoaderService } from '../ng-service/loader.service';

class HotkeyConfig {
    [key: string]: string[];
}
class ConfigModel {
    hotkeys: HotkeyConfig;
}
export class Command {
    name: string;
    combo: string;
    ev: KeyboardEvent;
}

@Injectable()
export class RestService {

    private fprint : String;
    private subject: Subject<Command>;
    public commands: Observable<Command>;

    constructor(private http: Http, private router: Router, private spinner: NgxSpinnerService, private hotkeysService: HotkeysService) {
        this.fprint = (new Fingerprint2()).getSync().fprint;
        this.subject = new Subject<Command>();
        this.commands = this.subject.asObservable();
        this.http.get('assets/hotkey.json').toPromise()
            .then(r => r.json() as ConfigModel)
            .then(c => {
                for (const key in c.hotkeys) {
                    const commands = c.hotkeys[key];
                    hotkeysService.add(new Hotkey(key, (ev, combo) => this.hotkey(ev, combo, commands)));
                }
            });
    }

    postRequest(url: String) {
        this.spinner.show();
        return this.http.post(this.getRestApiUrl(url), {}, this.getRestApiHeader())
            .map(this.successData).catch(this.handleError).finally(() => this.spinner.hide());
    }

    postRequestWithParamater(url: String, jSonParameter) {
        this.spinner.show();
        return this.http.post(this.getRestApiUrl(url), jSonParameter, this.getRestApiHeader())
            .map(this.successData).catch(this.handleError).finally(() => this.spinner.hide());
    }

     postRequestWithParamaterForWebSocket(url: String, jSonParameter) {
        return this.http.post(this.getRestApiUrl(url), jSonParameter, this.getRestApiHeader())
            .map(this.successData).catch(this.handleError);
    }

    userModulePostRequestWithParamater(url: String, jSonParameter) {
        this.spinner.show();
        var finalUrl = '';
        var applicationURL = window.location.href;
        var applnUrlArray = applicationURL.split('/');
        for (var i = 0; i < 4; i++) {
            finalUrl = finalUrl + applnUrlArray[i] + '/';
        }
        applicationURL = finalUrl + url;
        return this.http.post(applicationURL, jSonParameter, this.getRestApiHeader())
            .map(this.successData).catch(this.handleError).finally(() => this.spinner.hide());
    }

    private getRestApiUrl(url: String) {
        var currentURL = url;
        var currentPage = this.router.url;
        if (currentURL == undefined || currentURL == null || currentURL == ''
            && currentPage == undefined || currentPage == null || currentPage == '') {
            return CONSTANT.APPLICATION.ERROR;
        }

        currentURL = currentURL.trim();
        currentURL = currentURL.startsWith("/") ? currentURL.substring(1) : currentURL;
        currentURL = currentURL.endsWith("/") ? currentURL.substring(0, currentURL.length - 1) : currentURL;

        var applicationURL = window.location.href;
        var finalUrl = '';
        var applnUrlArray = applicationURL.split('/');
        for (var i = 0; i < 4; i++) {
            finalUrl = finalUrl + applnUrlArray[i] + '/';
        }
        applicationURL = finalUrl + currentURL;
        return applicationURL;
    }

    private getRestApiHeader() {
        let headers = new Headers({
            'finger-print': this.fprint,
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        });
        let options = new RequestOptions({ headers: headers });
        return options;
    }

    private successData(response: Response) {
        return response.json();
    }

    private handleError(response: Response) {
        return response.json();
    }

    hotkey(ev: KeyboardEvent, combo: string, commands: string[]): boolean {
        commands.forEach(c => {
            const command = {
                name: c,
                ev: ev,
                combo: combo
            } as Command;
            this.subject.next(command);
        });
        return true;
    }
}