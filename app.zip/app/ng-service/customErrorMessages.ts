import {ErrorMessage} from "ng-bootstrap-form-validation";
 
export const CUSTOM_ERRORS: ErrorMessage[] = [
    {
      error: "required",
      format: requiredFormat
    }, {
      error: "max",
      format: maxFormat
    }
    ,{
      error: "min",
      format: minFormat
    }, {
    //   error: "decimal",
    //   format: decimalFormat
    // }, {
      error: "pattern",
      format: patternFormat
    }
  ];
   
  export function requiredFormat(label: string, error: any): string {
    return `${label} is required.`;
  }
   
  export function maxFormat(label: string, error: any): string {
    return `Maximum ${label} is 100.`;
  }

  export function minFormat(label: string, error: any): string {
    return `Minimum ${label} is 0.`;
  }

  // export function decimalFormat(label: string, error: any): string {
  //   return `${label} should take values upto 2 decimal points !`;
  // }

  export function patternFormat(label: string, error: any): string {
    return `Format is not correct.`;
  }
