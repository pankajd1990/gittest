import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Message } from 'primeng/primeng';
import { Subscription } from 'rxjs/Subscription';

type Severities = 'success' | 'info' | 'warn' | 'error';

@Injectable()
export class MessageService {

  public lifeTime: number = 5000;
  public isSticky: Boolean = false;

  public message: Message[] = [];
  public subscription: Subscription;
  public messageChange: Subject<Object> = new Subject<Object>();

  subscribeToMessages() {
    this.subscription = this.messageChange.subscribe(message => {
      this.message = [];
      this.message.push(message);
    });
  }

  notify(severity: Severities, summary: string, detail: string) {
    this.messageChange.next({ severity, summary, detail });
  }

  putMessage(data: any) {
    this.isSticky = false;
    switch (data.responseCode) {
      case 0:
        this.notify('success', 'SUCCESS', data.responseMsg);
        this.isSticky = false;
        break;
      case 1:
        this.notify('error', 'ERROR', data.responseMsg);
        this.isSticky = true;
        break;
      case -1:
        this.notify('warn', 'WARNING', data.responseMsg);
        this.isSticky = false;
        break;
      default:
        this.notify('info', 'INFO', data.responseMsg);
        this.isSticky = false;
        break;
    }
  }

  putErrorMessage(message: string) {
    this.isSticky = true;
    this.notify('error', 'ERROR', message);
  }

  putSuccessMessage(message: string) {
    this.isSticky = false;
    this.notify('success', 'SUCCESS', message);
  }

  putWarningMessage(message: string) {
    this.isSticky = false;
    this.notify('warn', 'Warning', message);
  }

  clearMessages() {
    this.message = [];
  }

}