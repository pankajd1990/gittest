import { Injectable } from '@angular/core';
import { CONSTANT } from '../ng-utility/ng.constant';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class DataShareService {

  public loginMessageSource = new BehaviorSubject(CONSTANT.BLANK);
  public loginMessage = this.loginMessageSource.asObservable();

  public applicationMessageSource = new BehaviorSubject(CONSTANT.BLANK);
  public applicationMessage = this.applicationMessageSource.asObservable();

  public mwscrHeaderData: any;

  constructor() { }

  sendLoginMessage(message: string) {
    this.loginMessageSource.next(message)
  }

  sendApplicationMessage(message: string) {
    this.applicationMessageSource.next(message)
  }

  setMwscrHeaderData(message: any) {
    this.mwscrHeaderData = message;
  }

  getMwscrHeaderData() {
    return this.mwscrHeaderData;
  }

}