export default class Util {
    static checkResponse(jsonData: any) {
        if ((jsonData != null) && (jsonData.responseCode === 0)) {
            return true;
        }
        return false;
    }
    static difference(arrayOne, arrayTwo) {
        return arrayOne.filter(function (a) {
            return arrayTwo.indexOf(a) == -1;
        });
    }
}