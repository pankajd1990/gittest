declare var $: any;
import * as moment from 'moment';

export const GridColumnDefs = {

    ViewMarketReplay: {
        SetCriteria: [
            { headerName: 'Run ID', field: 'mwscrRunId', width: 100, filter: 'agTextColumnFilter', checkboxSelection: true },
            {
                headerName: 'Run Date', field: 'mwscrBussDate', width: 110, filter: 'agTextColumnFilter', cellRenderer: (data) => {
                    return data.value !== '' && data.value != undefined ? moment(data.value).format('DD-MMM-YYYY') : null;
                }
            },
            { headerName: 'Symbol', field: 'mwscrSymbol', width: 110, filter: 'agTextColumnFilter' },
            { headerName: 'Series', field: 'mwscrSeries', width: 100, filter: 'agTextColumnFilter' },
            { headerName: 'From Time', field: 'mwscrFromTime', width: 130, filter: 'agTextColumnFilter' },
            { headerName: 'To Time', field: 'mwscrToTime', width: 130, filter: 'agTextColumnFilter' },
            { headerName: 'Index', field: 'mwscrIndexName', width: 130, filter: 'agTextColumnFilter' },
            { headerName: 'Status', field: 'mwscrStatus', width: 100, filter: 'agTextColumnFilter' },
            { headerName: '% away from LTP', field: 'mwscrPectAwayLtp', width: 160, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
            { headerName: '% away from LTP for SL', field: 'mwscrSlPectAwayLtp', width: 200, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
            { headerName: 'Large Cancel Qty', field: 'mwscrLargeCxlQty', width: 160, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
            { headerName: 'Large Unexecuted Qty', field: 'mwscrLargeUnexecutedQty', width: 180, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
            {
                headerName: 'RequestDate', field: 'mwscrRequestDate', width: 130, filter: 'agTextColumnFilter', cellRenderer: (data) => {
                    return data.value !== '' && data.value != undefined ? moment(data.value).format('DD-MMM-YYYY') : null;
                }
            },
            { headerName: 'Error Code', field: 'mwscrErrorCode', width: 100, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
            { headerName: 'Error Desc', field: 'mwscrErrorDesc', width: 160, filter: 'agTextColumnFilter' },
            { headerName: 'UserId', field: 'mwscrUpdtBy', width: 110, filter: 'agTextColumnFilter' }
        ],
        Query: [
            { headerName: 'Run ID', field: 'mwscrRunId', width: 100, filter: 'agTextColumnFilter' },
            {
                headerName: 'Run Date', field: 'mwscrBussDate', width: 110, filter: 'agTextColumnFilter', cellRenderer: (data) => {
                    return data.value !== '' && data.value != undefined ? moment(data.value).format('DD-MMM-YYYY') : null;
                }
            },
            { headerName: 'Symbol', field: 'mwscrSymbol', width: 110, filter: 'agTextColumnFilter' },
            { headerName: 'Series', field: 'mwscrSeries', width: 100, filter: 'agTextColumnFilter' },
            { headerName: 'From Time', field: 'mwscrFromTime', width: 130, filter: 'agTextColumnFilter' },
            { headerName: 'To Time', field: 'mwscrToTime', width: 130, filter: 'agTextColumnFilter' },
            { headerName: 'Index', field: 'mwscrIndexName', width: 130, filter: 'agTextColumnFilter' },
            { headerName: 'Status', field: 'mwscrStatus', width: 100, filter: 'agTextColumnFilter' },
            { headerName: '% away from LTP', field: 'mwscrPectAwayLtp', width: 160, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
            { headerName: '% away from LTP for SL', field: 'mwscrSlPectAwayLtp', width: 200, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
            { headerName: 'Large Cancel Qty', field: 'mwscrLargeCxlQty', width: 160, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
            { headerName: 'Large Unexecuted Qty', field: 'mwscrLargeUnexecutedQty', width: 180, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
            {
                headerName: 'RequestDate', field: 'mwscrRequestDate', width: 130, filter: 'agTextColumnFilter', cellRenderer: (data) => {
                    return data.value !== '' && data.value != undefined ? moment(data.value).format('DD-MMM-YYYY') : null;
                }
            },
            { headerName: 'Error Code', field: 'mwscrErrorCode', width: 100, filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
            { headerName: 'Error Desc', field: 'mwscrErrorDesc', width: 160, filter: 'agTextColumnFilter' },
            { headerName: 'UserId', field: 'mwscrUpdtBy', width: 110, filter: 'agTextColumnFilter' }
        ]
    },
    WhatIf: [
        { headerName: 'What-If ID', field: 'whscrRunId', filter: 'agTextColumnFilter', checkboxSelection: true },
        {
            headerName: 'Run Date', field: 'whscrRunDate', filter: 'agTextColumnFilter', cellRenderer: (data) => {
                return data.value !== '' && data.value != undefined ? moment(data.value).format('DD-MMM-YYYY') : null;
            }
        },
        { headerName: 'Symbol', field: 'whscrSymbol', filter: 'agTextColumnFilter' },
        { headerName: 'Series', field: 'whscrSeries', filter: 'agTextColumnFilter' },
        { headerName: 'From Time', field: 'whscrFromTime', filter: 'agTextColumnFilter' },
        { headerName: 'To Time', field: 'whscrToTime', filter: 'agTextColumnFilter' },
        { headerName: 'Index', field: 'whscrIndexName', filter: 'agTextColumnFilter' },
        { headerName: 'Status', field: 'whscrStatus', filter: 'agTextColumnFilter' },
        { headerName: '% away from LTP', field: 'whatifPectAwayLtp', filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
        { headerName: '% away from LTP for SL', field: 'whatifSlPectAwayLtp', filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
        { headerName: 'Large Cancel Qty', field: 'whatifLargeCxlQty', filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
        { headerName: 'Large Unexecuted Qty', field: 'whatifLargeUnexecutedQty', filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
        {
            headerName: 'RequestDate', field: 'whscrRequestDate', filter: 'agTextColumnFilter', cellRenderer: (data) => {
                return data.value !== '' && data.value != undefined ? moment(data.value).format('DD-MMM-YYYY') : null;
            }
        },
        { headerName: 'Error Code', field: 'whscrErrorCode', filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
        { headerName: 'Error Desc', field: 'whscrErrorDesc', filter: 'agTextColumnFilter' },
        { headerName: 'UserId', field: 'whscrCrtBy', filter: 'agTextColumnFilter' }
    ],
    SetThreshold: {
        PrimaryGrid: [
            { headerName: 'Rule Name', field: 'ruleName', filter: 'agTextColumnFilter', width: 120, checkboxSelection: true },
            { headerName: 'Rule Number', field: 'ruleNum', filter: 'agNumberColumnFilter', width: 40, cellStyle: { 'text-align': 'right' } },
            { headerName: 'Derived', field: 'ruleAlertType', filter: 'agTextColumnFilter', width: 40 },
            { headerName: 'Rule Type', field: 'ruleType', filter: 'agTextColumnFilter', width: 40 },
            { headerName: 'Parent Rule Number', field: 'ruleParentRuleNum', filter: 'agNumberColumnFilter', width: 40, cellStyle: { 'text-align': 'right' } },
            { headerName: 'Rule Description', field: 'ruleUserString', filter: 'agTextColumnFilter', width: 120 }
        ],
        SecondaryGrid: [
            { headerName: 'Rule Name', field: 'ruleName', filter: 'agTextColumnFilter', width: 185, checkboxSelection: true },
            { headerName: 'Rule Number', field: 'thrshRuleNo', filter: 'agNumberColumnFilter', width: 130, cellStyle: { 'text-align': 'right' } },
            { headerName: 'Derived', field: 'ruleAlertType', filter: 'agTextColumnFilter', width: 100 },
            { headerName: 'Parent Rule Number', field: 'ruleParentRuleNum', filter: 'agNumberColumnFilter', width: 150, cellStyle: { 'text-align': 'right' } },
            { headerName: 'Rule Type', field: 'ruleType', filter: 'agTextColumnFilter', width: 100 },
            { headerName: 'Threshold Number', field: 'thrshThresholdNum', filter: 'agTextColumnFilter', width: 150 },
            { headerName: 'Description', field: 'thrshThresholdDesc', filter: 'agTextColumnFilter', width: 150 },
            { headerName: 'Original Value', field: 'thrshCurrentValue', filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' }, width: 130 },
            { headerName: 'Effective Date', field: 'thrshCurrentEffDateString', filter: 'agTextColumnFilter', width: 130 },
            {
                headerName: 'New Value', field: 'thrshNewValue', filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' }, width: 120, editable: (event) => {
                    if (event.node.isSelected()) {
                        return true;
                    }
                    return false;
                }
            },
            {
                headerName: 'New Effective Date', field: 'thrshEffDateString', filter: 'agTextColumnFilter', width: 125, cellRenderer: (params) => {
                    let tempParam = [];
                    var inputelement = document.createElement('input');
                    $(inputelement).datepicker({
                        dateFormat: 'dd-M-yy',
                        changeMonth: true,
                        changeYear: true,
                        minDate: params.data.businessDate,
                        onSelect: function (dateText, inst) {
                            var date = $(this).val();
                            params.data[params.colDef.field] = date;
                            tempParam.push(params.node);
                            params.api.redrawRows(tempParam);
                        }
                    });
                    $(inputelement).prop('placeholder', 'dd-mon-yyyy');
                    if (params.data.thrshEffDateString != '') {
                        $(inputelement).datepicker('setDate', params.data.thrshEffDateString);
                    }
                    return inputelement;
                }
            },
            { headerName: 'Changed By', field: 'thrshThreshUpdtBy', filter: 'agTextColumnFilter', width: 120 },
            {
                headerName: 'Changed On', field: 'threshUpdtDate', filter: 'agTextColumnFilter', width: 125, cellRenderer: (data) => {
                    return data.value !== '' && data.value != undefined ? moment(data.value).format('DD-MMM-YYYY hh:mm:ss a') : null;
                }
            },
            { headerName: 'businessDate', field: 'businessDate', filter: 'agTextColumnFilter', width: 0, hide: true },
        ]
    },

    /**
     * Administration - Grid Column Definition
     */
    MaintainGroup: [
        { headerName: 'Group Name', field: 'uadUserGroupName', filter: 'agTextColumnFilter', width: 100, checkboxSelection: true },
        { headerName: 'Parent Group Name', field: 'userParentGroupName', filter: 'agTextColumnFilter', width: 100 },
        { headerName: 'Not Allowed Working Days', field: 'uadQueryNotallwdWrkngDays', filter: 'agNumberColumnFilter', width: 100, cellStyle: { 'text-align': 'right' } }
    ],
    MaintainRole: [
        { headerName: 'Role ID', field: 'uadRoleName', width: 670, filter: 'agTextColumnFilter', checkboxSelection: true },
        { headerName: 'Role Name', field: 'uadRoleDesc', width: 670, filter: 'agTextColumnFilter' }
    ],
    MapRoleMenuFunction: [
        { headerName: 'Submenu 1', field: 'subMenu1', width: 100 },
        { headerName: 'Submenu 2', field: 'subMenu2', width: 100 },
        { headerName: 'Submenu 3', field: 'subMenu3', width: 100 },
        { headerName: 'Submenu 4', field: 'subMenu4', width: 100 },
        {
            headerName: 'Transaction', colId: 'transaction', field: 'transaction', width: 50, cellStyle: { 'text-align': 'center' }, cellRenderer: (params) => {
                var chechBoxElement = document.createElement('input');
                chechBoxElement.type = 'checkbox';
                chechBoxElement.checked = params.data.transaction;
                chechBoxElement.addEventListener('change', function (obj) {
                    params.data[params.colDef.field] = obj.target['checked'];
                    let transactionState = obj.target['checked'];
                    if (params.data.inquiry == true) {
                        params.data['inquiry'] = !transactionState;
                    }
                    let tempParam = [];
                    tempParam.push(params.node);
                    params.api.refreshRows(tempParam);
                    tempParam = [];
                });
                if (params.data.function === 1) {
                    return chechBoxElement;
                } else {
                    return '';
                }
            }
        }
    ],
    MaintainUser: [
        { headerName: 'User Id', field: 'uadUserId', filter: 'agTextColumnFilter', width: 150, checkboxSelection: true },
        { headerName: 'First Name', field: 'uadUserFirstName', filter: 'agTextColumnFilter', width: 150 },
        { headerName: 'Last Name', field: 'uadUserLastName', filter: 'agTextColumnFilter', width: 150 },
        { headerName: 'E-Mail', field: 'uadUserEmail', filter: 'agTextColumnFilter', width: 175 },
        { headerName: 'User Status', field: 'userStatusName', filter: 'agTextColumnFilter', width: 150 },
        { headerName: 'Reset', field: 'userResetFlagName', filter: 'agTextColumnFilter', width: 150 },
        { headerName: 'Account Locked', field: 'userLockStatusName', filter: 'agTextColumnFilter', width: 175 },
        { headerName: 'Auth Type', field: 'userAuthTypeName', filter: 'agTextColumnFilter', width: 150 },
        { headerName: 'UnSuccessful Login Attempts', field: 'uadUserUnsucessfulAttempts', filter: 'agNumberColumnFilter', cellStyle: { 'text-align': 'right' } },
        { headerName: 'User Type', field: 'userTypeName', filter: 'agTextColumnFilter', width: 150 },
        { headerName: 'User Group', field: 'userGroupName', filter: 'agTextColumnFilter', width: 150 },
        {
            headerName: 'Last Password Change', field: 'uadUserLastPsswrdChngDate', filter: 'agTextColumnFilter', width: 225, cellRenderer: (data) => {
                return data.value !== '' && data.value != undefined ? moment(data.value).format('DD-MMM-YYYY hh:mm:ss a') : null;
            }
        },
        {
            headerName: 'Last Logon', field: 'uadUserLastLogonDate', filter: 'agTextColumnFilter', width: 175, cellRenderer: (data) => {
                return data.value !== '' && data.value != undefined ? moment(data.value).format('DD-MMM-YYYY hh:mm:ss a') : null;
            }
        }
    ],
    MaintainUserRole: [
        { headerName: 'Role Id', field: 'uadRoleName', filter: 'agTextColumnFilter', width: 100, checkboxSelection: true },
        { headerName: 'Role Description', field: 'uadRoleDesc', filter: 'agTextColumnFilter', width: 100 }
    ],

}