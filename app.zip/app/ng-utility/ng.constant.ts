export const CONSTANT = {

    USER_MODULE: [
        'LOGIN', 'APPLICATION', 'DASHBOARD',
        'MAPROLEMENU', 'MAPUSERROLE', 'MAINTAINROLE',
        'MAINTAINUSER', 'MAINTAINGROUP', 'REFRESHCACHE',
        'MAPROLEMENUFUNCTION', 'BUSINESSPARAMETERS'
    ],
    BLANK: '',
    APPLICATION: {
        ERROR: undefined,
        USER_MODULE: 'user-module',
        MARKET_MODULE: 'market-replay-module'
    },
    URL: {
        AUTH_SERVER: 'http://localhost:8252/eureka-module',
        WEB_SOCKET_SERVER: 'charts-websocket'
    },
    TOPIC: {
        START_ACTIVITY: '/app/start',
        PAUSE_ACTIVITY: '/app/pause',
        SUBSCRIBE_ACTIVITY: '/subscribeactivity',
    },
    GRID_SIZE: 25,
    GRAPH_REFRESH: 50,
    GridPagination: {
        RecordPerPage: 100
    },
    MarketConstant: {
        MR_REQ_COMPLETED_STATUS: 'C',
        MR_REQ_INITIATED_STATUS: 'I',
        MR_REQ_PENDING_STATUS: 'P',
        MR_REQ_DELETED_STATUS: 'D',
        MR_REQ_ERROR_STATUS: 'E',
        MR_BUY_SELL_FLAG_TRADE: 'T',
        MR_BUY_SELL_FLAG_BUY: 'B',
        MR_BUY_SELL_FLAG_SELL: 'S',
        MR_BUY_SELL_FLAG_HIGHLIGHT: 'H',
        MR_BUY_SELL_ATO: 'A',
        MR_BUY_SELL_MARKET: 'M',
        MR_SEQ_NMBR: 'mrSeqNmbr',
        MR_REQ_DELETED_STATUS_DESC: 'Deleted',
        MR_REQ_COMPLETED_STATUS_DESC: 'Completed',
        MR_REQ_INITIATED_STATUS_DESC: 'Initiated',
        MR_REQ_PENDING_STATUS_DESC: 'Pending',
        MR_REQ_ERROR_STATUS_DESC: 'Error'
    }

}