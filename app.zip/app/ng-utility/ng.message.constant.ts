export const MessageConstant = {

    ChangePassword: {
        NewOldSame: 'New password cannot be same as old password.',
        NewConfirmNotSame: 'New Password should be same as Confirm New Password.'
    },
    ConfirmDialog: {
        confirmation: 'Confirmation',
        closeMessage: 'Are you sure that you want to close ?',
        proceedMessage: 'Are you sure that you want to proceed?'
    },
    TransactionForm: {
        AddRecord: 'Add Record',
        ModRecord: 'Modify Record',
        ModRowSelection: 'Please select a row to update.',
    },
    ErrorMessage: {
        NoDataFound: 'No Data found',
        NoChangeToSave: 'No changes to save',
        EnterValidValue: 'Please enter valid value'
    },
    ValidationMessage: {
        BrokerId: 'Broker ID should contain 5 characters',
        DealerId: 'Dealer ID should contain 5 numbers',
        AccountId: 'Account No should contain at most 10 characters',
        PAN: 'PAN format is not correct',
        NnfId: 'NNF ID should contain 15 characters',
        OrderNo: 'Order No should contain at most 20 numbers',
        TimeComparison: 'From time cannot be greater than or equal to To time',
    },
    MarketReplay: {
        ColSelection: 'Please select at least one column',
        GoToBlankClick: 'Please Provide at Least One Input',
        goToInvalid: 'Please Provide Valid Input',
        invalidGoto: 'Invalid Goto Input',
    },
    MrCache: {
        CacheConstruction: 'Market Replay Construction in progress. Please wait',
        ModifyAuthorization: 'Only records created by logged in user can be modified',
        MrAlreadyInitiated: 'Market Replay already has been initiated',
        MrAlreadyDeleted: 'Market Replay is already in deleted status',
        MrNotCompleted: 'Market Replay is not in completed status',
        MrNotInitiated: 'Market Replay has not been initiated',
    },
    SetThreshold: {
        EffectiveDate: 'Please enter the value of new effective date',
        NewValue: 'Please enter the new value',
        RowToSubmit: 'Please select a row to submit'
    },
    WhatIf: {
        RunIdSelection: 'Please select a Run Id',
        ActionSelection: 'Please select an action',
        DelRowSelection: 'Please select a row to delete',
        AlreadyInitiated: 'What If cannot be changed as it is already initiated',
    },
    MarketWatch: {
        RowToInitiate: 'Please select a row to initiate',
        RowToDisplay: 'Please select a row to display',
        RowToModify: 'Please select a row to modify',
        RowToDelete: 'Please select a row to delete'
    }

}