export const survConst = {
    single: 'single',
    multiple: 'multiple',
    errorMsg: {
        noDataErr: 'No Data found'
    },
    RECORDS_PER_PAGE: 100,
    TOTAL_PAGE_LINKS: 2,
    ENABLE_GO: true,
    ENABLE_FIRST_LAST: true,
    IDLE_TIME:10,
    IDLE_WARNING_TIME:3
}