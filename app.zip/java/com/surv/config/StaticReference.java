package com.surv.config;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import com.surv.constant.StaticConstants;

@Service("staticReference")
public class StaticReference {

	public Map<String, Map<String,String>> initStaticReference() {

		Map<String, Map<String,String>> map = new ConcurrentHashMap<>();

		Map<String,String> userStatusMap = new ConcurrentHashMap<>();
		userStatusMap.put(StaticConstants.STRING_N, StaticConstants.STRING_N);
		userStatusMap.put(StaticConstants.STRING_Y, StaticConstants.STRING_Y);
		map.put("LOV_YES_NO", userStatusMap);
		
		Map<String,String> buySellMap = new ConcurrentHashMap<>();
		buySellMap.put(StaticConstants.STRING_B, StaticConstants.BUY);
		buySellMap.put(StaticConstants.STRING_S, StaticConstants.SELL);
		map.put("LOV_BUY_SELL", buySellMap);
		
		Map<String,String> marketMap = new LinkedHashMap<>();
		marketMap.put(StaticConstants.STRING_N, StaticConstants.NORMAL);
		marketMap.put(StaticConstants.STRING_O, StaticConstants.ODDLOT);
		marketMap.put(StaticConstants.STRING_S, StaticConstants.SPOT);
		marketMap.put(StaticConstants.STRING_A, StaticConstants.AUCTION);
		marketMap.put(StaticConstants.STRING_C, StaticConstants.CA1);
		marketMap.put(StaticConstants.STRING_G, StaticConstants.CA2);
		map.put("LOV_MARKET", marketMap);
		
		Map<String,String> orderTypeMap = new LinkedHashMap<>();
		orderTypeMap.put(StaticConstants.STRING_L, StaticConstants.LIMIT);
		orderTypeMap.put(StaticConstants.STRING_M, StaticConstants.MARKET);
		orderTypeMap.put(StaticConstants.STRING_SM, StaticConstants.SL_MARKET);
		orderTypeMap.put(StaticConstants.STRING_SL, StaticConstants.SL_LIMIT);
		map.put("LOV_ORDER_TYPE", orderTypeMap);
		
		Map<String,String> orderValidityMap = new ConcurrentHashMap<>();
		orderValidityMap.put(StaticConstants.STRING_D, StaticConstants.DAY);
		orderValidityMap.put(StaticConstants.STRING_I, StaticConstants.IOC);
		map.put("LOV_ORDER_VALIDITY", orderValidityMap);
		
		Map<String,String> proCliMap = new ConcurrentHashMap<>();
		proCliMap.put(StaticConstants.NUMBER_ZERO, StaticConstants.PRO);
		proCliMap.put(StaticConstants.NUMBER_ONE, StaticConstants.CLI);
		map.put("LOV_PRO_CLI", proCliMap);
		
		Map<String,String> priceAdjustMap = new ConcurrentHashMap<>();
		priceAdjustMap.put(StaticConstants.STRING_PLUS, StaticConstants.STRING_PLUS);
		priceAdjustMap.put(StaticConstants.STRING_MINUS, StaticConstants.STRING_MINUS);
		map.put("LOV_PRICE_ADJUST", priceAdjustMap);
		
		Map<String, String> preopenMap = new ConcurrentHashMap<>();
		preopenMap.put(StaticConstants.NUMBER_ZERO, StaticConstants.STRING_NO);
		preopenMap.put(StaticConstants.NUMBER_ONE, StaticConstants.STRING_YES);
		map.put("LOV_PREOPEN", preopenMap);
		
		Map<String, String> actionMap = new ConcurrentHashMap<>();
		actionMap.put(StaticConstants.STRING_A, StaticConstants.NEW);
		actionMap.put(StaticConstants.STRING_M, StaticConstants.MODIFY);
		actionMap.put(StaticConstants.STRING_R, StaticConstants.REMOVE);
		map.put("LOV_ACTION", actionMap);

		return map;

	}

}
