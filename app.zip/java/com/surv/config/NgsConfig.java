package com.surv.config;

import java.util.concurrent.ConcurrentHashMap;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "ngs")
public class NgsConfig {

	private ConcurrentHashMap<String, String> oauth;

	public ConcurrentHashMap<String, String> getOauth() {
		return oauth;
	}
	public void setOauth(ConcurrentHashMap<String, String> oauth) {
		this.oauth = oauth;
	}
	
}