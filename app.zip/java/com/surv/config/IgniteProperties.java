package com.surv.config;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component("igniteProperties")
@ConfigurationProperties(prefix = "ignite")
public class IgniteProperties {

	private List<String> ips;
	private ConcurrentHashMap<String, String> config;
	private ConcurrentHashMap<String, String> ignite;

	public List<String> getIps() {
		return ips;
	}
	public void setIps(List<String> ips) {
		this.ips = ips;
	}
	public ConcurrentHashMap<String, String> getConfig() {
		return config;
	}
	public void setConfig(ConcurrentHashMap<String, String> config) {
		this.config = config;
	}
	public ConcurrentHashMap<String, String> getIgnite() {
		return ignite;
	}
	public void setIgnite(ConcurrentHashMap<String, String> ignite) {
		this.ignite = ignite;
	}
	
	
}