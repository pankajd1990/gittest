package com.surv.config;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.surv.exception.ConfigurationException;
import com.surv.exception.InvalidInputException;
import com.surv.exception.LogFileNotFoundException;
import com.surv.exception.SessionExpiredException;

@ControllerAdvice
public class RestExceptionHandler {

	@ExceptionHandler(SessionExpiredException.class)
	@ResponseStatus(value = HttpStatus.UNAUTHORIZED)
	public void handleSessionExpired() {
		System.out.println("\tSession has expired.");
	}
	
	@ExceptionHandler(ConfigurationException.class)
	@ResponseStatus(value = HttpStatus.METHOD_NOT_ALLOWED)
	public void handleConfigurationException() {
	}
	
	@ExceptionHandler(LogFileNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public void handleLogFileNotFoundException() {
	}
	
	@ExceptionHandler(InvalidInputException.class)
	@ResponseStatus(value = HttpStatus.NOT_ACCEPTABLE)
	public void handleInvalidInputException() {
	}
}
