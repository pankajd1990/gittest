package com.surv.config;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.surv.cache.CacheManager;

@Component
public class SqlConfig {

	private Map<String, String> getQuery() {
		return CacheManager.sqlQueryMap;
	}
	
	private Map<String, String> getCacheQuery() {
		return CacheManager.cacheQueryMap;
	}

	public String getQuery(String queryName) {
		queryName = queryName.toUpperCase();
		return this.getQuery().get(queryName) != null && !this.getQuery().get(queryName).isEmpty() ? this.getQuery().get(queryName) : null;
	}
	
	public String getCacheQuery(String queryName) {
		return this.getCacheQuery().get(queryName) != null && !this.getCacheQuery().get(queryName).isEmpty() ? this.getCacheQuery().get(queryName) : null;
	}

}