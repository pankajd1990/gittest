package com.surv.json;

public class ResponseSetter {

	public static void getResponseString(ResponseVO responseBean, int responseCode, String errMsg) {
		initResponseBean(responseBean);
		responseBean.setResponseCode(responseCode);
		responseBean.setResponseMsg(errMsg);
	}

	public static void getResponseString(ResponseVO responseBean, int responseCode, String responseMsg, String data) {
		initResponseBean(responseBean);
		responseBean.setResponseCode(responseCode);
		responseBean.setResponseMsg(responseMsg);
		responseBean.setResultData(data);
	}

	public static void getResponseString(ResponseVO responseBean, int responseCode, String responseMsg, Object data) {
		initResponseBean(responseBean);
		responseBean.setResponseCode(responseCode);
		responseBean.setResponseMsg(responseMsg);
		responseBean.setResultData(data);
	}

	private static void initResponseBean(ResponseVO responseBean) {
		responseBean.setResponseCode(0);
		responseBean.setResponseMsg(null);
		responseBean.setResultData(null);
	}

}