package com.surv.json;

import org.springframework.boot.jackson.JsonComponent;
import org.springframework.scheduling.annotation.Async;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Async
@JsonComponent
@JsonIgnoreProperties
@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class ResponseVO {

	private Integer responseCode;
	private String responseMsg;
	private Object resultData;

	public ResponseVO() {
		super();
	}

	public ResponseVO(Integer responseCode, String responseMsg, Object resultData) {
		super();
		this.responseCode = responseCode;
		this.responseMsg = responseMsg;
		this.resultData = resultData;
	}

	public Integer getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(Integer responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMsg() {
		return responseMsg;
	}
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}
	public Object getResultData() {
		return resultData;
	}
	public void setResultData(Object resultData) {
		this.resultData = resultData;
	}

	@Override
	public String toString() {
		return "ResponseVO [responseCode=" + responseCode + ", responseMsg=" + responseMsg + ", resultData=" + resultData + "]";
	}

}