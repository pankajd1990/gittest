package com.surv.json;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class ResponseVOSerializer extends JsonSerializer<ResponseVO>{

	@Override
	public void serialize(ResponseVO responseVO, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException, JsonProcessingException {
		jsonGenerator.writeStartObject();
		jsonGenerator.writeNumberField("responseCode", responseVO.getResponseCode());
		jsonGenerator.writeStringField("responseMsg", responseVO.getResponseMsg());
		jsonGenerator.writeObjectField("resultData", responseVO.getResultData());
		jsonGenerator.writeEndObject();	
	}

}