package com.surv.rest.common;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.surv.exception.ConversionException;
import com.surv.utility.Logger;

public class GenericRestController {

	@Autowired
	private ObjectMapper objectMapper;

	private String jsonRequest;

	public void configureJsonRequest(String jsonRequest) {
		this.jsonRequest = jsonRequest;
	}

	public <T> T getObjectValue(String key, Class<T> objCls) throws ConversionException{
		try {
			JsonNode node = objectMapper.readTree(getJsonRequest());
			return  objectMapper.convertValue(node.get(key), objCls);
		} catch (IOException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ConversionException(e.getMessage(),e);
		} 
	}

	public <T> T getObjectValue(String key, TypeReference<T> objCls) throws ConversionException{
		try {
			JsonNode node = objectMapper.readTree(getJsonRequest());
			return  objectMapper.convertValue(node.get(key), objCls);
		} catch (IOException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ConversionException(e.getMessage(),e);
		} 
	}

	public String getStringValue(String key) throws ConversionException{
		try {
			JsonNode node = objectMapper.readTree(getJsonRequest());
			return  objectMapper.convertValue(node.get(key), String.class);
		} catch (IOException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ConversionException(e.getMessage(),e);
		} 
	}

	private String getJsonRequest() {
		return jsonRequest;
	}

	public ObjectMapper getObjectMapper() {
		return objectMapper;
	}

}
