package com.surv.rest;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.surv.controller.MarketReplayController;
import com.surv.entity.marketreplay.AlertRuleThresholdDetailVO;
import com.surv.entity.marketreplay.AlertRuleVO;
import com.surv.entity.marketreplay.MktwtchHighlightVO;
import com.surv.entity.marketreplay.MktwtchSelectCriteriaVO;
import com.surv.entity.marketreplay.SCmSecurityMasterVO;
import com.surv.entity.marketreplay.WhatifOrderFilterVO;
import com.surv.entity.marketreplay.WhatifSelectCriteria;
import com.surv.exception.ConversionException;
import com.surv.json.ResponseVO;
import com.surv.rest.common.GenericRestController;
import com.surv.service.marketreplay.MarketReplayService;

@RestController
@RequestMapping("marketReplayRestController")
public class MarketReplayRestController extends GenericRestController {

	@Autowired(required = true)
	@Qualifier(value = "marketReplayController")
	private MarketReplayController marketReplayController;

	@Autowired
	@Qualifier(value = "marketReplayService")
	private MarketReplayService marketReplayService;

	/**
	 * START
	 * Refresh Cache
	 * @author tcs_djain
	 */
	@RequestMapping(value = "refreshSystemCache" , method = RequestMethod.POST)
	public ResponseVO refreshSystemCache() throws ConversionException {
		return this.marketReplayController.refreshSystemCache();
	}

	/**
	 * START
	 * Market Replay
	 * @author Jayul Godhani
	 */
	@RequestMapping(value = "playMarketReplay", method = RequestMethod.POST)
	public ResponseVO playMarketReplay(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		Long runId = this.getObjectValue("mrRunId", Long.class);
		Integer mrSeqNmbr = this.getObjectValue("mrSeqNmbr", Integer.class);
		return marketReplayController.playMarketReplay(runId,mrSeqNmbr);
	}

	@RequestMapping(value = "marketReplayPopupGridDataCount", method = RequestMethod.POST)
	public ResponseVO marketReplayPopupGridDataCount(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		String flag = this.getStringValue("flag");
		Long runId = this.getObjectValue("runId", Long.class);
		Integer mrSeqNmbr = this.getObjectValue("mrSeqNmbr", Integer.class);
		Double limitPrice = this.getObjectValue("limitPrice", Double.class);
		Integer thresholdQty = this.getObjectValue("thresholdQty", Integer.class);
		Integer thresholdCxlQty = this.getObjectValue("thresholdCxlQty", Integer.class);
		Integer mrStartSeqNmbr = this.getObjectValue("mrStartSeqNmbr", Integer.class);
		return marketReplayController.marketReplayPopupGridDataCount(flag, runId, mrSeqNmbr,limitPrice,thresholdQty,thresholdCxlQty ,mrStartSeqNmbr);
	}

	@RequestMapping(value = "marketReplayPopupGridData", method = RequestMethod.POST)
	public ResponseVO marketReplayPopupGridData(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		String flag = this.getStringValue("flag");
		Long runId = this.getObjectValue("runId", Long.class);
		Integer mrSeqNmbr = this.getObjectValue("mrSeqNmbr", Integer.class);
		Double limitPrice = this.getObjectValue("limitPrice", Double.class);
		Integer thresholdQty = this.getObjectValue("thresholdQty", Integer.class);
		Integer thresholdCxlQty = this.getObjectValue("thresholdCxlQty", Integer.class);
		Integer mrStartSeqNmbr = this.getObjectValue("mrStartSeqNmbr", Integer.class);
		Integer pageSize = this.getObjectValue("pageSize", Integer.class);
		Integer from = this.getObjectValue("from", Integer.class);
		return marketReplayController.marketReplayPopupGridData(flag, runId, mrSeqNmbr,limitPrice,thresholdQty,thresholdCxlQty ,mrStartSeqNmbr,pageSize,from);
	}

	@RequestMapping(value = "pushMrRequestCache" , method = RequestMethod.POST)
	public ResponseVO pushMrRequestCache(@RequestBody String jsonRequest) throws ConversionException, JsonParseException, JsonMappingException, IOException {
		MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO = this.getObjectMapper().readValue(jsonRequest, MktwtchSelectCriteriaVO.class);
		return this.marketReplayController.pushMrRequestCache(mktwtchSelectCriteriaVO);
	}

	@RequestMapping(value = "getStatusCache" , method = RequestMethod.POST)
	public ResponseVO getStatusCache(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		Integer mwscrRunId = this.getObjectValue("mwscrRunId",Integer.class);
		return this.marketReplayController.getStatusCache(mwscrRunId);
	}

	@RequestMapping(value="getHighlightCondition",method=RequestMethod.POST)
	public ResponseVO getHighlightCondition(@RequestBody String jsonRequest) throws ConversionException, JsonParseException, JsonMappingException, IOException{
		MktwtchHighlightVO mktwtchHighlightVO = this.getObjectMapper().readValue(jsonRequest, MktwtchHighlightVO.class);
		return marketReplayController.getHighlightCondition(mktwtchHighlightVO);
	}

	@RequestMapping(value = "submitHighlightCondition", method = RequestMethod.POST)
	public ResponseVO submitHighlightCondition(@RequestBody String jsonRequest) throws ConversionException, JsonParseException, JsonMappingException, IOException {
		MktwtchHighlightVO mktwtchHighlightVO = this.getObjectMapper().readValue(jsonRequest, MktwtchHighlightVO.class);
		return marketReplayController.submitHighlightCondition(mktwtchHighlightVO);
	}

	/**
	 * START
	 * Replay Criteria
	 * @author Kalpana
	 */

	@RequestMapping(value = "getIndexLovdata",method = RequestMethod.POST)
	public ResponseVO getIndexLovdata(@RequestBody String jsonRequest) throws ConversionException{
		this.configureJsonRequest(jsonRequest);
		Date runDate = this.getObjectValue("runDate",Date.class);	
		return this.marketReplayController.getIndexLovdata(runDate);
	}

	@RequestMapping(value = "getRunId",method = RequestMethod.POST)
	public ResponseVO getRunId() throws ConversionException{
		return this.marketReplayController.getRunId();
	}

	@RequestMapping(value = "getMarketWatchGridCount", method = RequestMethod.POST)
	public ResponseVO 	getMarketWatchGridCount(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		String runId = this.getStringValue("runId");
		return this.marketReplayController.getMarketWatchGridCount(runId);
	}

	@RequestMapping(value = "getMarketWatchGridData",method = RequestMethod.POST)
	public ResponseVO getMarketWatchGridData(@RequestBody String jsonRequest) throws ConversionException{
		this.configureJsonRequest(jsonRequest);
		String runId = this.getStringValue("runId");
		Integer pageSize = this.getObjectValue("pageSize", Integer.class);
		Integer from = this.getObjectValue("from", Integer.class);
		return this.marketReplayController.getMarketWatchGridData(runId, from, pageSize);
	}

	@RequestMapping(value = "getReplyCriteria",method = RequestMethod.POST)
	public ResponseVO getReplyCriteria() throws ConversionException{
		return this.marketReplayController.getReplyCriteria();
	}

	@RequestMapping(value = "getSymbolSeriesCount", method = RequestMethod.POST)
	public ResponseVO 	getSymbolSeriesCount(@RequestBody String jsonRequest) throws ConversionException, JsonParseException, JsonMappingException, IOException {
		SCmSecurityMasterVO sCmSecurityMasterVO = this.getObjectMapper().readValue(jsonRequest, SCmSecurityMasterVO.class);
		return this.marketReplayController.getSymbolSeriesCount(sCmSecurityMasterVO);
	}

	@RequestMapping(value = "getSymbolSeriesData", method = RequestMethod.POST)
	public ResponseVO getSymbolSeriesData(@RequestBody String jsonRequest) throws ConversionException, JsonParseException, JsonMappingException, IOException {
		SCmSecurityMasterVO sCmSecurityMasterVO = this.getObjectMapper().readValue(jsonRequest, SCmSecurityMasterVO.class);
		return this.marketReplayController.getSymbolSeriesData(sCmSecurityMasterVO);
	}

	@RequestMapping(value = "addReplayCriteria" , method = RequestMethod.POST)
	public ResponseVO addReplayCriteria(@RequestBody String jsonRequest) throws ConversionException, JsonParseException, JsonMappingException, IOException {
		MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO = this.getObjectMapper().readValue(jsonRequest, MktwtchSelectCriteriaVO.class);
		return this.marketReplayController.addReplayCriteria(mktwtchSelectCriteriaVO);
	}

	@RequestMapping(value = "modifyReplayCriteria" , method = RequestMethod.POST)
	public ResponseVO modifyReplayCriteria(@RequestBody String jsonRequest) throws ConversionException, JsonParseException, JsonMappingException, IOException {
		MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO = this.getObjectMapper().readValue(jsonRequest, MktwtchSelectCriteriaVO.class);
		return this.marketReplayController.modifyReplayCriteria(mktwtchSelectCriteriaVO);	
	}

	@RequestMapping(value = "getMinRunDate" , method = RequestMethod.POST)
	public ResponseVO getMinRunDate() {
		return this.marketReplayController.getMinRunDate();
	}

	@RequestMapping(value = "getQueryGridCount", method = RequestMethod.POST)
	public ResponseVO 	getQueryGridCount(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		Date mwscrBussDate = this.getObjectValue("mwscrBussDate",Date.class);
		return this.marketReplayController.getQueryGridCount(mwscrBussDate);
	}

	@RequestMapping(value = "getQueryGridData",method = RequestMethod.POST)
	public ResponseVO getQueryGridData(@RequestBody String jsonRequest) throws ConversionException{
		this.configureJsonRequest(jsonRequest);
		Date mwscrBussDate = this.getObjectValue("mwscrBussDate",Date.class);
		Integer pageSize = this.getObjectValue("pageSize", Integer.class);
		Integer from = this.getObjectValue("from", Integer.class);
		return this.marketReplayController.getQueryGridData(mwscrBussDate, from, pageSize);
	}
	/**
	 * end
	 */

	/**
	 * START
	 * Set Threshold
	 * @author Shivangi/Swati
	 */
	@RequestMapping(value = "getAllAlerts",method = RequestMethod.POST)
	public ResponseVO getAllRules() throws ConversionException{
		return this.marketReplayController.getAllAlerts();
	}

	@RequestMapping(value = "searchAlertCountData", method = RequestMethod.POST)
	public ResponseVO searchAlertCountData(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		List<String> ruleName = this.getObjectValue("ruleName", new TypeReference<List<String>>() {});
		return this.marketReplayController.searchAlertCountData(ruleName);
	}

	@RequestMapping(value = "searchAlertData", method = RequestMethod.POST)
	public ResponseVO searchAlertData(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		List<String> ruleName = this.getObjectValue("ruleName", new TypeReference<List<String>>() {});
		Integer pageSize = this.getObjectValue("pageSize", Integer.class);
		Integer from = this.getObjectValue("from", Integer.class);
		return this.marketReplayController.searchAlertData(ruleName, from, pageSize);
	}	

	@RequestMapping(value = "searchSelectedCountData", method = RequestMethod.POST)
	public ResponseVO 	searchSelectedCountData(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		List<AlertRuleVO> listAlertDetails = this.getObjectValue("listAlertDetails", new TypeReference<List<AlertRuleVO>>() {});
		return this.marketReplayController.searchSelectedCountData(listAlertDetails);
	}

	@RequestMapping(value = "searchSelectedData", method = RequestMethod.POST)
	public ResponseVO searchSelectedData(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		List<AlertRuleVO> listAlertDetails = this.getObjectValue("listAlertDetails", new TypeReference<List<AlertRuleVO>>() {});
		Integer pageSize = this.getObjectValue("pageSize", Integer.class);
		Integer from = this.getObjectValue("from", Integer.class);
		return this.marketReplayController.searchSelectedData(listAlertDetails, from, pageSize);
	}


	@RequestMapping(value = "updateData", method = RequestMethod.POST)
	public ResponseVO updateData(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		List<AlertRuleThresholdDetailVO> listUpdateDetails = this.getObjectValue("listUpdateDetails", new TypeReference<List<AlertRuleThresholdDetailVO>>() {});
		return this.marketReplayController.updateData(listUpdateDetails);
	}

	/**
	 * END
	 * Alert Rule
	 * @author Shivangi and Swati
	 */

	/**
	 * START
	 * What-If
	 * @author Swati
	 */
	@RequestMapping(value = "getAllRunId",method = RequestMethod.POST)
	public ResponseVO getAllRunId() throws ConversionException{
		return this.marketReplayController.getAllRunId();
	}

	@RequestMapping(value = "searchRunCount", method = RequestMethod.POST)
	public ResponseVO searchRunCount(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		String runId = this.getStringValue("runId");
		return this.marketReplayController.searchRunCount(runId);
	}

	@RequestMapping(value = "searchRunIdData", method = RequestMethod.POST)
	public ResponseVO searchRunIdData(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		String runId = this.getStringValue("runId");
		Integer pageSize = this.getObjectValue("pageSize", Integer.class);
		Integer from = this.getObjectValue("from", Integer.class);
		return this.marketReplayController.searchRunIdData(runId, from, pageSize);
	}

	@RequestMapping(value = "getActionLOV", method = RequestMethod.POST)
	public ResponseVO getActionLOV() throws ConversionException {
		return this.marketReplayController.getActionLOV();
	}

	@RequestMapping(value = "getAddLOV", method = RequestMethod.POST)
	public ResponseVO getAddLOV() throws ConversionException {
		return this.marketReplayController.getAddLOV();
	}

	@RequestMapping(value = "addNewOrd", method = RequestMethod.POST)
	public ResponseVO addNewOrd(@RequestBody String jsonRequest) throws JsonParseException, JsonMappingException, IOException {
		WhatifOrderFilterVO whatifOrderFilterVO = this.getObjectMapper().readValue(jsonRequest, WhatifOrderFilterVO.class);
		return this.marketReplayController.addNewOrd(whatifOrderFilterVO);
	}

	@RequestMapping(value = "addModOrd", method = RequestMethod.POST)
	public ResponseVO addModOrd(@RequestBody String jsonRequest) throws JsonParseException, JsonMappingException, IOException {
		WhatifOrderFilterVO whatifOrderFilterVO = this.getObjectMapper().readValue(jsonRequest, WhatifOrderFilterVO.class);
		return this.marketReplayController.addModOrd(whatifOrderFilterVO);
	}

	@RequestMapping(value = "addRemoveOrd", method = RequestMethod.POST)
	public ResponseVO addRemoveOrd(@RequestBody String jsonRequest) throws JsonParseException, JsonMappingException, IOException {
		WhatifOrderFilterVO whatifOrderFilterVO = this.getObjectMapper().readValue(jsonRequest, WhatifOrderFilterVO.class);
		return this.marketReplayController.addRemoveOrd(whatifOrderFilterVO);
	}

	@RequestMapping(value = "ModNewOrd", method = RequestMethod.POST)
	public ResponseVO ModNewOrd(@RequestBody String jsonRequest) throws JsonParseException, JsonMappingException, IOException {
		WhatifOrderFilterVO whatifOrderFilterVO = this.getObjectMapper().readValue(jsonRequest, WhatifOrderFilterVO.class);
		return this.marketReplayController.ModNewOrd(whatifOrderFilterVO);
	}

	@RequestMapping(value = "ModModOrd", method = RequestMethod.POST)
	public ResponseVO ModModOrd(@RequestBody String jsonRequest) throws JsonParseException, JsonMappingException, IOException {
		WhatifOrderFilterVO whatifOrderFilterVO = this.getObjectMapper().readValue(jsonRequest, WhatifOrderFilterVO.class);
		return this.marketReplayController.ModModOrd(whatifOrderFilterVO);
	}

	@RequestMapping(value = "ModRemoveOrd", method = RequestMethod.POST)
	public ResponseVO ModRemoveOrd(@RequestBody String jsonRequest) throws JsonParseException, JsonMappingException, IOException {
		WhatifOrderFilterVO whatifOrderFilterVO = this.getObjectMapper().readValue(jsonRequest, WhatifOrderFilterVO.class);
		return this.marketReplayController.ModRemoveOrd(whatifOrderFilterVO);
	}

	@RequestMapping(value = "deleteOrderFilter", method = RequestMethod.POST)
	public ResponseVO deleteOrderFilter(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		Integer whatifFilterNumber = this.getObjectValue("whatifFilterNumber", Integer.class);
		Integer whatifRunId = this.getObjectValue("whatifRunId", Integer.class);
		return this.marketReplayController.deleteOrderFilter(whatifFilterNumber, whatifRunId);
	}
	/**
	 * END
	 * What-If 
	 * @author Swati
	 */

	/**
	 * START
	 * What-If: What-If Tab
	 * @author Bansari
	 */

	@RequestMapping(value = "getWhatIfRunId",method = RequestMethod.POST)
	public ResponseVO getWhatIfRunId() throws ConversionException{
		return this.marketReplayController.getWhatIfRunId();
	}

	@RequestMapping(value = "getWhatIfGridCount", method = RequestMethod.POST)
	public ResponseVO 	getWhatIfGridCount(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		String runId = this.getStringValue("runId");
		return this.marketReplayController.getWhatIfGridCount(runId);
	}

	@RequestMapping(value = "getWhatIfGridData",method = RequestMethod.POST)
	public ResponseVO getWhatIfGridData(@RequestBody String jsonRequest) throws ConversionException{
		this.configureJsonRequest(jsonRequest);
		String runId = this.getStringValue("runId");
		Integer pageSize = this.getObjectValue("pageSize", Integer.class);
		Integer from = this.getObjectValue("from", Integer.class);
		return this.marketReplayController.getWhatIfGridData(runId, from, pageSize);
	}

	@RequestMapping(value = "addWhatIfData" , method = RequestMethod.POST)
	public ResponseVO addWhatIfData(@RequestBody String jsonRequest) throws ConversionException, JsonParseException, JsonMappingException, IOException {
		WhatifSelectCriteria whatifSelectCriteria = this.getObjectMapper().readValue(jsonRequest, WhatifSelectCriteria.class);
		return this.marketReplayController.addWhatIfData(whatifSelectCriteria);
	}

	@RequestMapping(value = "modifyWhatIfData" , method = RequestMethod.POST)
	public ResponseVO modifyWhatIfData(@RequestBody String jsonRequest) throws ConversionException, JsonParseException, JsonMappingException, IOException {
		WhatifSelectCriteria whatifSelectCriteria = this.getObjectMapper().readValue(jsonRequest, WhatifSelectCriteria.class);
		return this.marketReplayController.modifyWhatIfData(whatifSelectCriteria);
	}

	/**
	 * END
	 * What-If: What-If Tab
	 * @author Bansari
	 */

	/**
	 * START
	 * Market Replay
	 * @author Shailesh Khandare
	 */
	@RequestMapping(value = "playMarketReplaySocket" , method = RequestMethod.POST)
	public ResponseVO playMarketReplaySocket(@RequestBody String jsonRequest) throws Exception {
		this.configureJsonRequest(jsonRequest);
		Integer runId = this.getObjectValue("mrRunId", Integer.class);
		Integer mrSeqNmbr = this.getObjectValue("mrSeqNmbr", Integer.class);
		Integer lastSeqNmbr = this.getObjectValue("lastSeqNmbr", Integer.class);
		Integer gotoStartSeqNmbr = this.getObjectValue("gotoStartSeqNmbr", Integer.class);
		Integer prevForwardFlag = this.getObjectValue("prevForwardFlag", Integer.class);
		return this.marketReplayController.playMarketReplaySocket(runId, mrSeqNmbr, lastSeqNmbr, prevForwardFlag,gotoStartSeqNmbr);
	}

	@RequestMapping(value = "goToMarketReplay", method = RequestMethod.POST)
	public ResponseVO goToMarketReplay(@RequestBody String jsonRequest) throws ConversionException {
		this.configureJsonRequest(jsonRequest);
		Integer mrSeqNmbr = this.getObjectValue("mrSeqNmbr", Integer.class);
		String mrRecordTimeString = this.getStringValue("mrRecordTimeString");
		String mrPan = this.getStringValue("mrPan");
		Long mrOrderNmbr = this.getObjectValue("mrOrderNmbr", Long.class);
		Long mrFillNmbr = this.getObjectValue("mrFillNmbr", Long.class);
		Integer mrRunId = this.getObjectValue("mrRunId", Integer.class);
		return this.marketReplayController.goToMarketReplay(mrSeqNmbr,mrRecordTimeString,mrPan,mrOrderNmbr,mrFillNmbr,mrRunId);
	}
	/**
	 * END
	 * Market Replay
	 * @author Shailesh Khandare
	 */

}