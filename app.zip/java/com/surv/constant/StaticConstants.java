package com.surv.constant;

public interface StaticConstants {
	
	public static final String MR_MAPPING_FILE_NAME = "marketreplay.properties";
	
	/**
	 * Don't Change : Menu ID
	 */
	public static final Long MENU_MR = 0l;
	public static final Long MENU_SUR = 1l;

	public static final String BLANK = "";

	public static final int SUCCESS_CODE = 0;
	public static final int FAILURE_CODE = 1;
	public static final int WARNING_CODE = -1;

	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";

	public static final int NUMBER_0 = 0;
	public static final int NUMBER_1 = 1;
	public static final int NUMBER_2 = 2;
	public static final int NUMBER_3 = 3;
	public static final int NUMBER_4 = 4;
	public static final int NUMBER_5 = 5;
	public static final int NUMBER_6 = 6;
	public static final int NUMBER_7 = 7;
	public static final int NUMBER_8 = 8;
	public static final int NUMBER_9 = 9;
	public static final int NUMBER_10 = 10;

	public static final String STRING_A = "A";
	public static final String STRING_B = "B";
	public static final String STRING_C = "C";
	public static final String STRING_D = "D";
	public static final String STRING_E = "E";
	public static final String STRING_F = "F";
	public static final String STRING_G = "G";
	public static final String STRING_H = "H";
	public static final String STRING_I = "I";
	public static final String STRING_J = "J";
	public static final String STRING_K = "K";
	public static final String STRING_L = "L";
	public static final String STRING_M = "M";
	public static final String STRING_N = "N";
	public static final String STRING_O = "O";
	public static final String STRING_P = "P";
	public static final String STRING_Q = "Q";
	public static final String STRING_R = "R";
	public static final String STRING_S = "S";
	public static final String STRING_T = "T";
	public static final String STRING_U = "U";
	public static final String STRING_V = "V";
	public static final String STRING_W = "W";
	public static final String STRING_X = "X";
	public static final String STRING_Y = "Y";
	public static final String STRING_Z = "Z";
	
	
	
	/**
	 *What-IF
	 */
	
	public static final String STRING_SL = "SL";
	public static final String STRING_SM = "SM";
	public static final String STRING_PLUS= "+";
	public static final String STRING_MINUS= "-";
	public static final String NUMBER_ZERO = "0";
	public static final String NUMBER_ONE = "1";
	
	public static final String BUY = "BUY";
	public static final String SELL = "SELL";
	public static final String NORMAL = "NORMAL";
	public static final String ODDLOT = "ODDLOT";
	public static final String SPOT = "SPOT";
	public static final String AUCTION = "AUCTION";
	public static final String CA1 = "CA1";
	public static final String CA2 = "CA2";
	public static final String LIMIT = "LIMIT";
	public static final String MARKET = "MARKET";
	public static final String SL_MARKET= "SL MARKET";
	public static final String SL_LIMIT= "SL LIMIT";
	public static final String DAY= "DAY";
	public static final String IOC= "IOC";
	public static final String PRO= "PRO";
	public static final String CLI= "CLI";
	public static final String PREOPEN= "PREOPEN";
	public static final String NOT_PREOPEN= "NOT PREOPEN";
	public static final String NEW	= "NEW";
	public static final String MODIFY= "MODIFY";
	public static final String REMOVE= "REMOVE";
	public static final String STRING_YES= "YES";
	public static final String STRING_NO= "NO";
	
	public static final String IOP = "IOP";
	public static final String PCP = "PCP";
	public static final String TTQ = "TTQ";
	public static final String TTO = "TTO";
	public static final String DO = "DO";
	public static final String DH = "DH";
	public static final String DL = "DL";
	public static final String LTP = "LTP";
	public static final String TP = "TP";
	public static final String LTT = "LTT";
	public static final String LLTP = "LTP to LLTP";
	public static final String BPQ = "BPQ";
	public static final String SPQ = "SPQ";
	public static final String IV = "INDEX";
	public static final String TRADE_SEPARATE = ": ";
	public static final String COMMA = ", ";
	
	/**
	 * LOGGER
	 */
	public static final String STARTUP_LOG = "startupLogger";
	public static final String EXCEPTION_LOG = "exceptionLogger";
	public static final String REQRES_LOG = "reqresLogger";
	public static final String MASTER_LOG = "masterLogger";

	public static final int MARKET_REPLY_LIMIT = 30;
	public static final String MW_SCR_SEG_IND = "C";
	
	public static final String PRCNTG = "%";
	
	
}
