package com.surv.constant;

public interface StaticMsgConstants {


	public static final String ERR_DATA_ACCESS = "Data access error. Please Try Again";
	public static final String ERR_NO_DATA_FOUND = "No data found";
	public static final String ERR_SYSTEM_ERROR = "Server Error in Processing the Request. Please Try Again";
	public static final String ERR_DATA_INTEGRITY = "Record Already Exists.";
	public static final String ERR_DATA_CONFG = "Error in Configuration, contact system administrator";
	public static final String ERR_TECHNICAL = "Technical Error, contact system administrator";
	public static final String ERR_ALREADY_MOD = "Record Modified Already.";
	public static final String ERR_INPUT = "Invalid Input.";
	public static final String ERR_PRIVILEGES = "You don't have enough privileges to perform this function.";

	public static final String NO_CHANGE_TO_SAVE = "No changes to save.";

	public static final String RECORD_ADD_SUCCESS = "Record added successfully.";
	public static final String RECORD_MOD_SUCCESS = "Record updated successfully.";
	public static final String STATUS_MOD_SUCCESS = "Status updated successfully.";
	public static final String RECORD_DEL_SUCCESS = "Record deleted successfully.";
	public static final String ERR_CACHE_NOT_AVAILABLE = "MR cache not available, Please contact admin";
	public static final String ERR_CACHE_DATA_NOT_AVAILABLE = "Data is not available in MR cache for this run id";
	

	public static final String OLD_RECORD_NOT_FOUND = "Modification not allowed. Current Record not found in Database.";

	public static final String INVALID_TIME = "Invalid Time Format.";
	public static final String VALIDATE_HOLIDAY = "Select non holiday.";
	public static final String CHECK_LIMIT = "Exceeded max limit, as "+StaticConstants.MARKET_REPLY_LIMIT+" Market Replay has already been processed";
	public static final String ERR_BOTH_MANDATORY = "Both New value and Effective fields can't be left empty";
	public static final String NUMERIC_FIELD = "New value can be numeric or decimal only";

	public static final String VALIDATE_SERIES_SYMBOL = "Invalid Series/Symbol.";
	public static final String VALIDATE_TIME_FORMAT = "Invalid Time Format.";

	public static final String CHECK_DATA = "Both New value and Effective fields cannot be left empty";


	public static final String SET_MR_UNEXECUTED = "Please set the value of Large Unexecuted Order in Market Replay attribute";
	public static final String SET_MR_CANCELLED = "Please set the value of Large Cancelled Order in Market Replay attribute";
	public static final String SET_MR_PER_AWAY = "Please set the value of percentage Away Order in Market Replay attribute";
	public static final String SET_MR_PER_SL_AWAY = "Please set the value of percentage Away SL Order in Market Replay attribute";
	public static final String LIMIT_PRICE_MANDATORY = "Limit price is mandatory for Limit & Market orders";
	public static final String TRIGGER_PRICE_MANDATORY = "Trigger price is mandatory for stop loss orders";
	public static final String ACC_CODE_MANDATORY = "Account code is mandatory for client orders";
	public static final String MARKET_ORD_TYPE_VALIDATION_MSG = "Both Limit price & Trigger price should be empty for Market order type";
	public static final String LIMIT_ORD_TYPE_VALIDATION_MSG = "Limit price is mandatory & Trigger price should not be there for Limit order type";
	public static final String SL_MARKET_ORD_TYPE_VALIDATION_MSG = "Trigger price is mandatory & Limit price should not be there for SL Market order type";
	public static final String SL_LIMIT_ORD_TYPE_VALIDATION_MSG = "Both Limit price & Trigger price is mandatory for SL Limit order type";
	public static final String PRICE_ADJ_SIGN_VALIDATION_MSG = "Price adjustment sign and value has to be filled together";

	public static final String ERROR_INVALID_MWHGH_NNF_ID = "NNF ID should only contain 15 alphanumerics";
	public static final String ERROR_INVALID_MWHGH_USER_ID = "Dealer ID should contain only 5 integers";    
	public static final String ERROR_INVALID_MWHGH_CLNT_CODE = "Account No should contain at most 10 alphanumerics";
	public static final String ERROR_INVALID_MWHGH_PAN = "PAN format is not correct";
	public static final String ERROR_INVALID_MWHGH_TM_CODE = "Broker ID should contain only 5 alphanumerics";
	public static final String ERROR_MWHGH_TM_CODE_NOT_EMPTY = "Broker ID cannot be empty if Account No is entered";
	
	public static final String ERROR_IGNITE_CACHE_NULL = "Connection Aborted by Cache Manager.";
	public static final String ERR_NOT_ALLOWED_WORKING_DAYS= "Invalid Run Date";
}