package com.surv.constant;

public interface ValidationMessage {

	public static final String ERROR_INVALID_ROLE_ID = "Role Id should only contains alphabets";
	public static final String ERROR_INVALID_ROLE_DESC = "Role Name can be alphanumeric only";
	public static final String ERROR_ROLE_ID_MAX = "Max length should be 30";
	public static final String ERROR_ROLE_DESC_MAX = "Max length should be 100";
	public static final String ERROR_ROLE_ID_NOT_EMPTY = "Role Id cannot be empty";
	public static final String ERROR_ROLE_DESC_NOT_EMPTY = "Role Description cannot be empty";
	
	public static final String ERROR_USER_ID_MAX="User Id is More than 30 characters";
	public static final String ERROR_USER_ID_NOT_EMPTY="User Id cannot be empty";
	public static final String ERROR_INVALID_USER_ID="Invalid User Id";
	
	public static final String ERROR_UAD_USER_FIRST_NAME_MAX="User first name More than 50 characters";
	public static final String ERROR_USER_FIRST_NAME_NOT_EMPTY="User first name cannot be empty";
	public static final String ERROR_INVALID_USER_FIRST_NAME="Invalid User first name";
	
	public static final String ERROR_UAD_USER_LAST_NAME_MAX="User first name More than 50 characters";
	public static final String ERROR_USER_LAST_NAME_NOT_EMPTY="User last name cannot be empty";
	public static final String ERROR_INVALID_USER_LAST_NAME="Invalid user last name";
	
	public static final String ERROR_UAD_USER_EMAIL_MAX="User email more than 100 characters";
	public static final String ERROR_UAD_USER_EMAIL_NOT_EMPTY="User email cannot be empty";
	public static final String ERROR_INVALID_UAD_USER_EMAIL ="Invalid user";
	
	public static final String ERROR_UAD_USER_AUTHTYPE_NOT_EMPTY ="User authType Id cannot be empty";
	
	public static final String ERROR_UAD_USER_PASSWORD_MAX= "User password MoreThan 100 characters";
	public static final String ERROR_INVALID_UAD_USER_PASSWORD="Invalid password";
	public static final String ERROR_UAD_USER_GROUPNUM_NOT_EMPTY = "User group number cannot be empty";
	public static final String ERROR_UAD_USER_STATUS_NOT_EMPTY = "User status cannot be empty";
	public static final String ERROR_UAD_USER_TYPE_NOT_EMPTY = "User type cannot be empty";
	
	
	public static final String ERROR_UAD_USER_GROUP_NAME_NOT_EMPTY = "User group name cannot be empty";
	public static final String ERROR_UAD_USER_GROUP_NAME_MAX = "User group name MoreThan 100 characters";
	public static final String ERROR_INVALID_UAD_USER_GROUP_NAME = "Invalid user group name";
	
    public static final String ERROR_INVALID_UAD_USER_PARENT_GROUP_NUM = "User group parent cannot be empty";

    public static final String ERROR_INVALID_NEW_VALUE = "Invalid new value";
       
    public static final String ERROR_INVALID_MWHGH_TM_CODE="Broker ID should only contain alphanumerics";
    
    public static final String ERROR_INVALID_MWSCR_LCANCELLED_QTY="Large Cancelled should contain only INTEGER values";
    public static final String ERROR_MWSCR_LCANCELLED_QTY_MIN="Minimum quantity of large cancelled is 0";
    public static final String ERROR_MWSCR_LCANCELLED_QTY_MAX="Maximum quantity of large cancelled is 2147483647";
    
    public static final String ERROR_INVALID_MWSCR_LUNEXEC_QTY="Large Cancelled should contain only INTEGER values";
    public static final String ERROR_MWSCR_LUNEXEC_QTY_MIN="Minimum quantity of large unexecuted is 0";
    public static final String ERROR_MWSCR_LUNEXEC_QTY_MAX="Maximum quantity of large unexecuted is 2147483647";
    
    public static final String ERROR_INVALID_MWSCR_PRCNTGAWAY_LTPSL="% away from LTPSL should take values upto 2 decimal points";
    public static final String ERROR_MWSCR_PRCNTGAWAY_LTPSL_MIN="Minimum % away from LTPSL is 0";
    public static final String ERROR_MWSCR_PRCNTGAWAY_LTPSL_MAX="Maximum % away from LTPSL is 100";
    
    public static final String ERROR_INVALID_MWSCR_PRCNTGAWAY_LTP="% away from LTP should take values upto 2 decimal points";
    public static final String ERROR_MWSCR_PRCNTGAWAY_LTP_MIN="Minimum % away from LTP is 0";
    public static final String ERROR_MWSCR_PRCNTGAWAY_LTP_MAX="Maximum % away from LTP is 100";
    
    public static final String ERROR_TM_CODE_LENGHT ="Broker Id should have 5 lenght";
    public static final String ERROR_TM_CODE_NOT_EMPTY="Broker Id cannot Be left Empty";
    public static final String ERROR_TM_CODE_INVALID = "Invalid Broker Id";

    public static final String ERROR_DEALER_ID_LENGHT ="Broker Id should have 5 lenght";
    public static final String ERROR_DEALER_ID_NOT_EMPTY="Broker Id cannot Be left Empty";
    public static final String ERROR_DEALER_ID_INVALID = "Invalid Broker Id";
    
    public static final String ERROR_MKT_TYPE_NOT_EMPTY="Market Type cannot Be left Empty";
    public static final String ERROR_ORD_TYPE_NOT_EMPTY="Order Type cannot Be left Empty";
    public static final String ERROR_ORD_VALIDITY_NOT_EMPTY="Order Validity cannot Be left Empty";
    public static final String ERROR_ACC_CODE_INVALID = "Invalid Account Code";
    public static final String ERROR_LIMIT_PRICE_INVALID = "Invalid Limit price";
    public static final String ERROR_TRIGGER_PRICE_INVALID = "Invalid Trigger price";
    public static final String ERROR_PAN_ID_INVALID = "Invalid PAN Id";
    public static final String ERROR_ORDER_QTY_INVALID = "Invalid Order quantity";
    public static final String ERROR_ORDER_DQ_INVALID = "Invalid DQ";
    public static final String ERROR_NNF_ID_INVALID = "Invalid NNF Id";
    public static final String ERROR_ALGO_ID_INVALID = "Invalid Algo Id";
    public static final String ERROR_ALGO_CATEGORY_INVALID = "Invalid Algo category";
    public static final String ERROR_SEQUENCE_NO_INVALID = "Invalid Sequence Number";
    public static final String ERROR_PER_AWAY_LTP_INVALID = "Invalid Percentage away from LTP";
    public static final String ERROR_PER_AWAY_SL_LTP_INVALID = "Invalid SL Percentage away from LTP";
    public static final String ERROR_LARGE_UNEXC_INVALID = "Invalid Large unexecuted quantity";
    public static final String ERROR_LARGE_CANC_INVALID = "Invalid Large cancelled quantity";
    
    public static final String ERROR_INDEX_NAME_NOT_EMPTY="Index name cannot Be left Empty";
    public static final String ERROR_SYMBOL_NOT_EMPTY="Symbol cannot Be left Empty";
    public static final String ERROR_FROM_TIME_NOT_EMPTY="From time cannot Be left Empty";
    public static final String ERROR_TO_TIME_EMPTY="To time cannot Be left Empty";
    
}