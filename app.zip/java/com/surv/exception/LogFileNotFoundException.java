package com.surv.exception;

public class LogFileNotFoundException extends RuntimeException{
	
	private static final long serialVersionUID = 719008133811511129L;

	public LogFileNotFoundException() {
	}
	public LogFileNotFoundException(String message) {

		super(message);

	}

	public LogFileNotFoundException(String message, Throwable cause) {

		super(message, cause);

	}
}
