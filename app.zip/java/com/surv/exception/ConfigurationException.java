package com.surv.exception;

public class ConfigurationException extends RuntimeException{
	
	private static final long serialVersionUID = 719008133811511129L;

	public ConfigurationException() {
	}
	public ConfigurationException(String message) {

		super(message);

	}

	public ConfigurationException(String message, Throwable cause) {

		super(message, cause);

	}
}
