package com.surv.aspect;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.surv.json.ResponseVO;
import com.surv.utility.Logger;

@Component
@Aspect
public class ReqResInterceptor {
	
	@Autowired
	@Qualifier(value = "responseVO")
	public ResponseVO responseVO;
	
	@AfterThrowing(pointcut = "execution(* com.surv.rest.*.*(..))" , throwing = "ex")
	public void logRestError(JoinPoint joinpoint, Throwable ex)  throws Throwable {
		Logger.EXCEPTION.info("Error Occurred  in parsing input request "
				+ joinpoint.getSignature().getName() + "\tError details: ", ex);
	}
	@AfterThrowing(pointcut = "execution(* com.surv.controller..*.*(..))" , throwing = "ex")
	public void logControllerError(JoinPoint joinpoint, Throwable ex)  throws Throwable {
		Logger.EXCEPTION.info("Error Occurred  in parsing input request "
				+ joinpoint.getSignature().getName() + "\tError details: ", ex);
	}
	@AfterThrowing(pointcut = "execution(* com.surv.service..*.*(..))" , throwing = "ex")
	public void logServiceError(JoinPoint joinpoint, Throwable ex)  throws Throwable {
		Logger.EXCEPTION.info("Error Occurred  in parsing input request "
				+ joinpoint.getSignature().getName() + "\tError details: ", ex);
	}
	@AfterThrowing(pointcut = "execution(* com.surv.dao..*.*(..))" , throwing = "ex")
	public void logDaoError(JoinPoint joinpoint, Throwable ex)  throws Throwable {
		Logger.EXCEPTION.info("Error Occurred  in parsing input request "
				+ joinpoint.getSignature().getName() + "\tError details: ", ex);
	}
	@AfterThrowing(pointcut = "execution(* com.surv.utility..*.*(..))" , throwing = "ex")
	public void logUtilError(JoinPoint joinpoint, Throwable ex)  throws Throwable {
		Logger.EXCEPTION.info("Error Occurred  in parsing input request "
				+ joinpoint.getSignature().getName() + "\tError details: ", ex);
	}
    

    @Before("execution(* com.surv.rest..*.add*(..)) ||"
			+ " execution(* com.surv.rest..*.mod*(..)) ||"
			+ " execution(* com.surv.rest..*.upd*(..)) ||"
			+ " execution(* com.surv.rest..*.sub*(..)) ||"
			+ " execution(* com.surv.rest..*.push*(..)) ||"
			+ " execution(* com.surv.rest..*.play*(..))")
    public void logRequest(JoinPoint joinpoint) throws Throwable {
    	Object args[] = joinpoint.getArgs();
    	Logger.REQ_RES.info("Request : "  + joinpoint.getSignature() + " : " + Arrays.asList(args));
    }
    @Before("execution(* com.surv.controller..*.*(..))")
    public void logControllerRequest(JoinPoint joinpoint) throws Throwable {
    	Object args[] = joinpoint.getArgs();
    	Logger.MASTER.info("Request : "  + joinpoint.getSignature() + " : " + Arrays.asList(args));
    }
    @AfterReturning(pointcut = "execution(* com.surv.rest..*.add*(..)) ||"
			+ " execution(* com.surv.rest..*.mod*(..)) ||"
			+ " execution(* com.surv.rest..*.upd*(..)) ||"
			+ " execution(* com.surv.rest..*.sub*(..)) ||"
			+ " execution(* com.surv.rest..*.play*(..)) ||"
			+ " execution(* com.surv.rest..*.push*(..))") 
    public void logResponse(JoinPoint joinpoint) throws Throwable {
    	Object args[] = joinpoint.getArgs();
    	Logger.REQ_RES.info("Response : "  + joinpoint.getSignature() + " : " + Arrays.asList(args));
    }
    
    
}
