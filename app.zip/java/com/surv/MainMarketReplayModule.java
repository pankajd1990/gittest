package com.surv;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.surv.cache.CacheManagerService;
import com.surv.utility.Logger;

@EnableEurekaClient
@SpringBootApplication
@EnableAspectJAutoProxy(proxyTargetClass=true)
public class MainMarketReplayModule implements CommandLineRunner{
	
	@Autowired
	@Qualifier(value = "cacheManagerService")
	private CacheManagerService cacheManagerService;

	public static void main(String[] args) {
		SpringApplication.run(MainMarketReplayModule.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		Logger.STARTUP.info("initCacheManager");
		
		cacheManagerService.initCacheManager(true);
		
		System.out.println("\n");
		System.out.println("###############################################");
		System.out.println("Market Replay Module Started Successfully...!!!");
		System.out.println("###############################################");
		System.out.println("\n");
	}

}