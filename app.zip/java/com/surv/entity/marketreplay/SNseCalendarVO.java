package com.surv.entity.marketreplay;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@Entity
@Table(name="s_nse_calendar")
public class SNseCalendarVO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@Temporal(TemporalType.DATE)
	private Date day;

	@Id
	@Column(name="hol_day")
	private String holDay;

	@Id
	@Column(name="hol_desc")
	private String holDesc;

	@Id
	@Column(name="hol_revoke_flag")
	private String holRevokeFlag;

	@Id
	@Column(name="last_mod_date_time")
	private Date lastModDateTime;

	private String status;

	public SNseCalendarVO() {
	}

	public Date getDay() {
		return this.day;
	}

	public void setDay(Date day) {
		this.day = day;
	}

	public String getHolDay() {
		return this.holDay;
	}

	public void setHolDay(String holDay) {
		this.holDay = holDay;
	}

	public String getHolDesc() {
		return this.holDesc;
	}

	public void setHolDesc(String holDesc) {
		this.holDesc = holDesc;
	}

	public String getHolRevokeFlag() {
		return this.holRevokeFlag;
	}

	public void setHolRevokeFlag(String holRevokeFlag) {
		this.holRevokeFlag = holRevokeFlag;
	}

	public Date getLastModDateTime() {
		return this.lastModDateTime;
	}

	public void setLastModDateTime(Date lastModDateTime) {
		this.lastModDateTime = lastModDateTime;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
