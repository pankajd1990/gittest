package com.surv.entity.marketreplay;

import java.io.Serializable;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.surv.constraints.annotations.CheckHolidayValidation;
import com.surv.constraints.annotations.CheckMarketWatchSymbolSeriesValidation;
import com.surv.constraints.annotations.CheckRecordLimitValidation;
import com.surv.constraints.annotations.ValidateMaxRunDateValidation;
import com.surv.constraints.annotations.ValidateTimeformat;
import com.surv.constraints.group.initiateMktwtchSelectCriteriaVO;
import com.surv.utility.Util;


@CheckMarketWatchSymbolSeriesValidation
@ValidateTimeformat
@CheckHolidayValidation
@ValidateMaxRunDateValidation
@CheckRecordLimitValidation(groups=initiateMktwtchSelectCriteriaVO.class)
@Entity
@Table(name="MKTWTCH_SELECT_CRITERIA")
public class MktwtchSelectCriteriaVO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="mwscr_run_id")
	private Integer mwscrRunId;

	@Column(name="mwscr_crt_by")
	private String mwscrCrtBy;

	@Column(name="mwscr_crt_date")
	private Timestamp mwscrCrtDate;

	@Column(name="mwscr_from_time")
	private Time mwscrFromTime;

	@Column(name="mwscr_index_name")
	private String mwscrIndexName;

	/*@Column(name="mwscr_prcntgaway_ltp")
	private Integer mwscrPrcntgawayLtp;*/

	@Column(name="mwscr_request_date")
	private Date mwscrRequestDate;

	@Column(name="mwscr_run_date")
	private Date mwscrBussDate;

	@Column(name="mwscr_seg_ind")
	private String mwscrSegInd;

	@Column(name="mwscr_series")
	private String mwscrSeries;

	@Column(name="mwscr_status")
	private String mwscrStatus;
	
	@Column(name="mwscr_curr_day_flag")
	private String mwscrCurrDayFlag;

	@Column(name="mwscr_symbol")
	private String mwscrSymbol;

	@Column(name="mwscr_to_time")
	private Time mwscrToTime;

	@Column(name="mwscr_updt_by")
	private String mwscrUpdtBy;

	@Column(name="mwscr_updt_date")
	private Timestamp mwscrUpdtDate;

	@Column(name="mwscr_user_num")
	private Integer mwscrUserNum;
	
	@Column(name="mwscr_error_code")
	private Integer mwscrErrorCode;

	@Column(name="mwscr_error_desc")
	private String mwscrErrorDesc;
	
	@Column(name="mwscr_pect_away_ltp")
	private Double mwscrPectAwayLtp;
	
	@Column(name="mwscr_sl_pect_away_ltp")
	private Double mwscrSlPectAwayLtp;
	
	@Column(name="mwscr_large_cxl_qty")
	private Integer mwscrLargeCxlQty;
	
	@Column(name="mwscr_large_unexecuted_qty")
	private Integer mwscrLargeUnexecutedQty;
	
	@Column(name="mwscr_start_seq_number")
	private Integer mwscrStartSeqNumber;

	private String mwscrBussDateStringCache;
	
	private String mwscrFromTimeStringCache;
	
	private String mwscrToTimeStringCache;
	
	public MktwtchSelectCriteriaVO() {
	}

	public Integer getMwscrRunId() {
		return this.mwscrRunId;
	}

	public void setMwscrRunId(Integer mwscrRunId) {
		this.mwscrRunId = mwscrRunId;
	}

	public String getMwscrCrtBy() {
		return this.mwscrCrtBy;
	}

	public void setMwscrCrtBy(String mwscrCrtBy) {
		this.mwscrCrtBy = mwscrCrtBy;
	}

	public Timestamp getMwscrCrtDate() {
		return this.mwscrCrtDate;
	}

	public void setMwscrCrtDate(Timestamp mwscrCrtDate) {
		this.mwscrCrtDate = mwscrCrtDate;
	}

	public Time getMwscrFromTime() {
		return this.mwscrFromTime;
	}

	public void setMwscrFromTime(Time mwscrFromTime) {
		this.mwscrFromTime = mwscrFromTime;
	}

	public String getMwscrIndexName() {
		return this.mwscrIndexName;
	}

	public void setMwscrIndexName(String mwscrIndexName) {
		this.mwscrIndexName = mwscrIndexName;
	}

	public Date getMwscrRequestDate() {
		return this.mwscrRequestDate;
	}

	public void setMwscrRequestDate(Date mwscrRequestDate) {
		this.mwscrRequestDate = mwscrRequestDate;
	}

	public Date getMwscrBussDate() {
		return this.mwscrBussDate;
	}

	public void setMwscrBussDate(Date mwscrBussDate) {
		this.mwscrBussDate = mwscrBussDate;
	}

	public String getMwscrSegInd() {
		return this.mwscrSegInd;
	}

	public void setMwscrSegInd(String mwscrSegInd) {
		this.mwscrSegInd = mwscrSegInd;
	}

	public String getMwscrSeries() {
		return this.mwscrSeries;
	}

	public void setMwscrSeries(String mwscrSeries) {
		this.mwscrSeries = mwscrSeries;
	}

	public String getMwscrStatus() {
		return this.mwscrStatus;
	}

	public void setMwscrStatus(String mwscrStatus) {
		this.mwscrStatus = mwscrStatus;
	}

	public String getMwscrCurrDayFlag() {
		return mwscrCurrDayFlag;
	}

	public void setMwscrCurrDayFlag(String mwscrCurrDayFlag) {
		this.mwscrCurrDayFlag = mwscrCurrDayFlag;
	}
	
	public String getMwscrSymbol() {
		return this.mwscrSymbol;
	}

	public void setMwscrSymbol(String mwscrSymbol) {
		this.mwscrSymbol = mwscrSymbol;
	}

	public Time getMwscrToTime() {
		return this.mwscrToTime;
	}

	public void setMwscrToTime(Time mwscrToTime) {
		this.mwscrToTime = mwscrToTime;
	}

	public String getMwscrUpdtBy() {
		return this.mwscrUpdtBy;
	}

	public void setMwscrUpdtBy(String mwscrUpdtBy) {
		this.mwscrUpdtBy = mwscrUpdtBy;
	}

	public Timestamp getMwscrUpdtDate() {
		return this.mwscrUpdtDate;
	}

	public void setMwscrUpdtDate(Timestamp mwscrUpdtDate) {
		this.mwscrUpdtDate = mwscrUpdtDate;
	}

	public Integer getMwscrUserNum() {
		return this.mwscrUserNum;
	}

	public void setMwscrUserNum(Integer mwscrUserNum) {
		this.mwscrUserNum = mwscrUserNum;
	}	
	
	public String getMwscrBussDateString() {
		return Util.getDateString(this.mwscrBussDate);
	}
	
	public String getMwscrFromTimeString() {
		return Util.getTimeString(this.mwscrFromTime);
	}
	
	public String getMwscrToTimeString() {
		return Util.getTimeString(this.mwscrToTime);
	}
	
	public Integer getMwscrErrorCode() {
		return this.mwscrErrorCode;
	}

	public void setMwscrErrorCode(Integer mwscrErrorCode) {
		this.mwscrErrorCode = mwscrErrorCode;
	}

	public String getMwscrErrorDesc() {
		return this.mwscrErrorDesc;
	}

	public void setMwscrErrorDesc(String mwscrErrorDesc) {
		this.mwscrErrorDesc = mwscrErrorDesc;
	}
	
	public String getMwscrBussDateStringCache() {
		return mwscrBussDateStringCache;
	}

	public void setMwscrBussDateStringCache(String mwscrBussDateStringCache) {
		this.mwscrBussDateStringCache = mwscrBussDateStringCache;
	}

	public String getMwscrFromTimeStringCache() {
		return mwscrFromTimeStringCache;
	}

	public void setMwscrFromTimeStringCache(String mwscrFromTimeStringCache) {
		this.mwscrFromTimeStringCache = mwscrFromTimeStringCache;
	}

	public String getMwscrToTimeStringCache() {
		return mwscrToTimeStringCache;
	}

	public void setMwscrToTimeStringCache(String mwscrToTimeStringCache) {
		this.mwscrToTimeStringCache = mwscrToTimeStringCache;
	}
	
	public Double getMwscrPectAwayLtp() {
		return Util.getRoundTwoDecimal(mwscrPectAwayLtp);
	}

	public void setMwscrPectAwayLtp(Double mwscrPectAwayLtp) {
		this.mwscrPectAwayLtp = mwscrPectAwayLtp;
	}
	
	public Double getMwscrSlPectAwayLtp(){
		return Util.getRoundTwoDecimal(mwscrSlPectAwayLtp);
	}

	public void setMwscrSlPectAwayLtp(Double mwscrSlPectAwayLtp) {
		this.mwscrSlPectAwayLtp = mwscrSlPectAwayLtp;
	}
	
	public Integer getMwscrLargeCxlQty() {
		return mwscrLargeCxlQty;
	}

	public void setMwscrLargeCxlQty(Integer mwscrLargeCxlQty) {
		this.mwscrLargeCxlQty = mwscrLargeCxlQty;
	}

	public Integer getMwscrLargeUnexecutedQty() {
		return mwscrLargeUnexecutedQty;
	}

	public void setMwscrLargeUnexecutedQty(Integer mwscrLargeUnexecutedQty) {
		this.mwscrLargeUnexecutedQty = mwscrLargeUnexecutedQty;
	}

	public Integer getMwscrStartSeqNumber() {
		return mwscrStartSeqNumber;
	}

	public void setMwscrStartSeqNumber(Integer mwscrStartSeqNumber) {
		this.mwscrStartSeqNumber = mwscrStartSeqNumber;
	}

	@Override
	public String toString() {
		return "MktwtchSelectCriteriaVO [mwscrRunId=" + mwscrRunId + ", mwscrCrtBy=" + mwscrCrtBy + ", mwscrCrtDate="
				+ mwscrCrtDate + ", mwscrFromTime=" + mwscrFromTime + ", mwscrIndexName=" + mwscrIndexName
				+ ", mwscrRequestDate=" + mwscrRequestDate + ", mwscrBussDate=" + mwscrBussDate + ", mwscrSegInd="
				+ mwscrSegInd + ", mwscrSeries=" + mwscrSeries + ", mwscrStatus=" + mwscrStatus + ", mwscrCurrDayFlag="
				+ mwscrCurrDayFlag + ", mwscrSymbol=" + mwscrSymbol + ", mwscrToTime=" + mwscrToTime + ", mwscrUpdtBy="
				+ mwscrUpdtBy + ", mwscrUpdtDate=" + mwscrUpdtDate + ", mwscrUserNum=" + mwscrUserNum
				+ ", mwscrErrorCode=" + mwscrErrorCode + ", mwscrErrorDesc=" + mwscrErrorDesc + ", mwscrPectAwayLtp="
				+ mwscrPectAwayLtp + ", mwscrSlPectAwayLtp=" + mwscrSlPectAwayLtp + ", mwscrLargeCxlQty="
				+ mwscrLargeCxlQty + ", mwscrLargeUnexecutedQty=" + mwscrLargeUnexecutedQty
				+ ", mwscrBussDateStringCache=" + mwscrBussDateStringCache + ", mwscrFromTimeStringCache="
				+ mwscrFromTimeStringCache + ", mwscrToTimeStringCache=" + mwscrToTimeStringCache + "]";
	}
	
}