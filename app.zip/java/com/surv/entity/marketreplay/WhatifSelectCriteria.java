package com.surv.entity.marketreplay;

import java.io.Serializable;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.surv.utility.Util;


/**
 * The persistent class for the whatif_select_criteria database table.
 * 
 */
/**
 * @author tcs_bvora
 *
 */
@Entity
@Table(name="whatif_select_criteria")
public class WhatifSelectCriteria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="WHSCR_RUN_ID")
	private Integer whscrRunId;

	@Column(name="WHATIF_LARGE_CXL_QTY")
	private Double whatifLargeCxlQty;

	@Column(name="WHATIF_LARGE_UNEXECUTED_QTY")
	private Double whatifLargeUnexecutedQty;

	@Column(name="WHATIF_MKTCLOSE_TIME")
	private Time whatifMktcloseTime;

	@Column(name="WHATIF_PECT_AWAY_LTP")
	private Double whatifPectAwayLtp;

	@Column(name="WHATIF_SL_PECT_AWAY_LTP")
	private Double whatifSlPectAwayLtp;

	@Column(name="WHSCR_CRT_BY")
	private String whscrCrtBy;

	@Column(name="WHSCR_CRT_DATE")
	private Timestamp whscrCrtDate;

	@Column(name="WHSCR_ERROR_CODE")
	private Integer whscrErrorCode;

	@Column(name="WHSCR_ERROR_DESC")
	private String whscrErrorDesc;

	@Column(name="WHSCR_FROM_TIME")
	private Time whscrFromTime;

	@Column(name="WHSCR_INDEX_NAME")
	private String whscrIndexName;

	@Column(name="WHSCR_REQUEST_DATE")
	private Date whscrRequestDate;

	@Column(name="WHSCR_RUN_DATE")
	private Date whscrRunDate;

	@Column(name="WHSCR_SEG_IND")
	private String whscrSegInd;

	@Column(name="WHSCR_SERIES")
	private String whscrSeries;

	@Column(name="WHSCR_STATUS")
	private String whscrStatus;

	@Column(name="WHSCR_SYMBOL")
	private String whscrSymbol;

	@Column(name="WHSCR_TO_TIME")
	private Time whscrToTime;

	@Column(name="WHSCR_UPDT_BY")
	private String whscrUpdtBy;

	@Column(name="WHSCR_UPDT_DATE")
	private Timestamp whscrUpdtDate;

	@Column(name="WHSCR_USER_NUM")
	private Integer whscrUserNum;

	public WhatifSelectCriteria() {
	}
	
	public WhatifSelectCriteria(Date whscrRunDate,String whscrSymbol,String whscrSeries,String whscrFromTime,String whscrToTime,
			String whscrIndexName,String whatifMktcloseTime,Double whatifLargeUnexecutedQty,Double whatifLargeCxlQty,
			Double whatifPectAwayLtp,Double whatifSlPectAwayLtp) {
		super();
		this.whscrRunDate = whscrRunDate;
		this.whscrSymbol = whscrSymbol;
		this.whscrSeries = whscrSeries;
		this.whscrFromTime = new Time(Util.getStringTime(whscrFromTime).getTime());
		this.whscrToTime = new Time(Util.getStringTime(whscrToTime).getTime());
		this.whscrIndexName = whscrIndexName;
		this.whatifMktcloseTime = new Time(Util.getStringTime(whatifMktcloseTime).getTime());
		this.whatifLargeUnexecutedQty = whatifLargeUnexecutedQty;
		this.whatifLargeCxlQty = whatifLargeCxlQty;
		this.whatifPectAwayLtp = whatifPectAwayLtp;
		this.whatifSlPectAwayLtp = whatifSlPectAwayLtp;
				
	}

	public Integer getWhscrRunId() {
		return this.whscrRunId;
	}

	public void setWhscrRunId(Integer whscrRunId) {
		this.whscrRunId = whscrRunId;
	}

	public Double getWhatifLargeCxlQty() {
		return this.whatifLargeCxlQty;
	}

	public void setWhatifLargeCxlQty(Double whatifLargeCxlQty) {
		this.whatifLargeCxlQty = whatifLargeCxlQty;
	}

	public Double getWhatifLargeUnexecutedQty() {
		return this.whatifLargeUnexecutedQty;
	}

	public void setWhatifLargeUnexecutedQty(Double whatifLargeUnexecutedQty) {
		this.whatifLargeUnexecutedQty = whatifLargeUnexecutedQty;
	}

	public Time getWhatifMktcloseTime() {
		return this.whatifMktcloseTime;
	}

	public void setWhatifMktcloseTime(Time whatifMktcloseTime) {
		this.whatifMktcloseTime = whatifMktcloseTime;
	}

	public Double getWhatifPectAwayLtp() {
		return this.whatifPectAwayLtp;
	}

	public void setWhatifPectAwayLtp(Double whatifPectAwayLtp) {
		this.whatifPectAwayLtp = whatifPectAwayLtp;
	}

	public Double getWhatifSlPectAwayLtp() {
		return this.whatifSlPectAwayLtp;
	}

	public void setWhatifSlPectAwayLtp(Double whatifSlPectAwayLtp) {
		this.whatifSlPectAwayLtp = whatifSlPectAwayLtp;
	}

	public String getWhscrCrtBy() {
		return this.whscrCrtBy;
	}

	public void setWhscrCrtBy(String whscrCrtBy) {
		this.whscrCrtBy = whscrCrtBy;
	}

	public Timestamp getWhscrCrtDate() {
		return this.whscrCrtDate;
	}

	public void setWhscrCrtDate(Timestamp whscrCrtDate) {
		this.whscrCrtDate = whscrCrtDate;
	}

	public Integer getWhscrErrorCode() {
		return this.whscrErrorCode;
	}

	public void setWhscrErrorCode(Integer whscrErrorCode) {
		this.whscrErrorCode = whscrErrorCode;
	}

	public String getWhscrErrorDesc() {
		return this.whscrErrorDesc;
	}

	public void setWhscrErrorDesc(String whscrErrorDesc) {
		this.whscrErrorDesc = whscrErrorDesc;
	}

	public Time getWhscrFromTime() {
		return this.whscrFromTime;
	}

	public void setWhscrFromTime(Time whscrFromTime) {
		this.whscrFromTime = whscrFromTime;
	}

	public String getWhscrIndexName() {
		return this.whscrIndexName;
	}

	public void setWhscrIndexName(String whscrIndexName) {
		this.whscrIndexName = whscrIndexName;
	}

	public Date getWhscrRequestDate() {
		return this.whscrRequestDate;
	}

	public void setWhscrRequestDate(Date whscrRequestDate) {
		this.whscrRequestDate = whscrRequestDate;
	}

	public Date getWhscrRunDate() {
		return this.whscrRunDate;
	}

	public void setWhscrRunDate(Date whscrRunDate) {
		this.whscrRunDate = whscrRunDate;
	}

	public String getWhscrSegInd() {
		return this.whscrSegInd;
	}

	public void setWhscrSegInd(String whscrSegInd) {
		this.whscrSegInd = whscrSegInd;
	}

	public String getWhscrSeries() {
		return this.whscrSeries;
	}

	public void setWhscrSeries(String whscrSeries) {
		this.whscrSeries = whscrSeries;
	}

	public String getWhscrStatus() {
		return this.whscrStatus;
	}

	public void setWhscrStatus(String whscrStatus) {
		this.whscrStatus = whscrStatus;
	}

	public String getWhscrSymbol() {
		return this.whscrSymbol;
	}

	public void setWhscrSymbol(String whscrSymbol) {
		this.whscrSymbol = whscrSymbol;
	}

	public Time getWhscrToTime() {
		return this.whscrToTime;
	}

	public void setWhscrToTime(Time whscrToTime) {
		this.whscrToTime = whscrToTime;
	}

	public String getWhscrUpdtBy() {
		return this.whscrUpdtBy;
	}

	public void setWhscrUpdtBy(String whscrUpdtBy) {
		this.whscrUpdtBy = whscrUpdtBy;
	}

	public Timestamp getWhscrUpdtDate() {
		return this.whscrUpdtDate;
	}

	public void setWhscrUpdtDate(Timestamp whscrUpdtDate) {
		this.whscrUpdtDate = whscrUpdtDate;
	}

	public Integer getWhscrUserNum() {
		return this.whscrUserNum;
	}

	public void setWhscrUserNum(Integer whscrUserNum) {
		this.whscrUserNum = whscrUserNum;
	}

	@Override
	public String toString() {
		return "WhatifSelectCriteria [whscrRunId=" + whscrRunId + ", whatifLargeCxlQty=" + whatifLargeCxlQty
				+ ", whatifLargeUnexecutedQty=" + whatifLargeUnexecutedQty + ", whatifMktcloseTime="
				+ whatifMktcloseTime + ", whatifPectAwayLtp=" + whatifPectAwayLtp + ", whatifSlPectAwayLtp="
				+ whatifSlPectAwayLtp + ", whscrCrtBy=" + whscrCrtBy + ", whscrCrtDate=" + whscrCrtDate
				+ ", whscrErrorCode=" + whscrErrorCode + ", whscrErrorDesc=" + whscrErrorDesc + ", whscrFromTime="
				+ whscrFromTime + ", whscrIndexName=" + whscrIndexName + ", whscrRequestDate=" + whscrRequestDate
				+ ", whscrRunDate=" + whscrRunDate + ", whscrSegInd=" + whscrSegInd + ", whscrSeries=" + whscrSeries
				+ ", whscrStatus=" + whscrStatus + ", whscrSymbol=" + whscrSymbol + ", whscrToTime=" + whscrToTime
				+ ", whscrUpdtBy=" + whscrUpdtBy + ", whscrUpdtDate=" + whscrUpdtDate + ", whscrUserNum=" + whscrUserNum
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((whatifLargeCxlQty == null) ? 0 : whatifLargeCxlQty.hashCode());
		result = prime * result + ((whatifLargeUnexecutedQty == null) ? 0 : whatifLargeUnexecutedQty.hashCode());
		result = prime * result + ((whatifMktcloseTime == null) ? 0 : whatifMktcloseTime.hashCode());
		result = prime * result + ((whatifPectAwayLtp == null) ? 0 : whatifPectAwayLtp.hashCode());
		result = prime * result + ((whatifSlPectAwayLtp == null) ? 0 : whatifSlPectAwayLtp.hashCode());
		result = prime * result + ((whscrFromTime == null) ? 0 : whscrFromTime.hashCode());
		result = prime * result + ((whscrIndexName == null) ? 0 : whscrIndexName.hashCode());
		result = prime * result + ((whscrRunDate == null) ? 0 : whscrRunDate.hashCode());
		result = prime * result + ((whscrRunId == null) ? 0 : whscrRunId.hashCode());
		result = prime * result + ((whscrSeries == null) ? 0 : whscrSeries.hashCode());
		result = prime * result + ((whscrSymbol == null) ? 0 : whscrSymbol.hashCode());
		result = prime * result + ((whscrToTime == null) ? 0 : whscrToTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WhatifSelectCriteria other = (WhatifSelectCriteria) obj;
		if (whatifLargeCxlQty == null) {
			if (other.whatifLargeCxlQty != null)
				return false;
		} else if (!whatifLargeCxlQty.equals(other.whatifLargeCxlQty))
			return false;
		if (whatifLargeUnexecutedQty == null) {
			if (other.whatifLargeUnexecutedQty != null)
				return false;
		} else if (!whatifLargeUnexecutedQty.equals(other.whatifLargeUnexecutedQty))
			return false;
		if (whatifMktcloseTime == null) {
			if (other.whatifMktcloseTime != null)
				return false;
		} else if (!whatifMktcloseTime.equals(other.whatifMktcloseTime))
			return false;
		if (whatifPectAwayLtp == null) {
			if (other.whatifPectAwayLtp != null)
				return false;
		} else if (!whatifPectAwayLtp.equals(other.whatifPectAwayLtp))
			return false;
		if (whatifSlPectAwayLtp == null) {
			if (other.whatifSlPectAwayLtp != null)
				return false;
		} else if (!whatifSlPectAwayLtp.equals(other.whatifSlPectAwayLtp))
			return false;
		if (whscrFromTime == null) {
			if (other.whscrFromTime != null)
				return false;
		} else if (!whscrFromTime.equals(other.whscrFromTime))
			return false;
		if (whscrIndexName == null) {
			if (other.whscrIndexName != null)
				return false;
		} else if (!whscrIndexName.equals(other.whscrIndexName))
			return false;
		if (whscrRunId == null) {
			if (other.whscrRunId != null)
				return false;
		} else if (!whscrRunId.equals(other.whscrRunId))
			return false;
		if (whscrSeries == null) {
			if (other.whscrSeries != null)
				return false;
		} else if (!whscrSeries.equals(other.whscrSeries))
			return false;
		if (whscrSymbol == null) {
			if (other.whscrSymbol != null)
				return false;
		} else if (!whscrSymbol.equals(other.whscrSymbol))
			return false;
		if (whscrToTime == null) {
			if (other.whscrToTime != null)
				return false;
		} else if (!whscrToTime.equals(other.whscrToTime))
			return false;
		return true;
	}
	
	
	
}