package com.surv.entity.marketreplay;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.surv.utility.Util;

@Entity
@Table(name="MKTWTCH_HIGHLIGHT")
public class MktwtchHighlightVO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MKWHG_RUN_ID")
	private Integer mkwhgRunId;

	@Id
	@Column(name="MKWHG_USER_NUM")
	private Integer mkwhgUserNum;

	@Column(name="MKWHG_RUN_DATE")
	private Date mkwhgRunDate;

	@Column(name="MKWHG_SEG_IND")
	private String mkwhgSegInd;

	@Column(name="MKWHG_SYMBOL")
	private String mkwhgSymbol;

	@Column(name="MKWHG_SERIES")
	private String mkwhgSeries;

	@Column(name="MKWHG_BROKER")
	private String mkwhgBroker;

	@Column(name="MKWHG_DEALER")
	private String mkwhgDealer;

	@Column(name="MKWHG_ACC_NO")
	private String mkwhgAccNo;

	@Column(name="MKWHG_PAN")
	private String mkwhgPan;

	@Column(name="MKWHG_NNF_ID")
	private String mkwhgNnfId;
	
	@Column(name="MKWHG_ORDER_NO")
	private String mkwhgOrderNo; 

	@Column(name="MKWHG_LST_UNEXEC_QTY")
	private Integer mkwhgLstUnexecQty;

	@Column(name="MKWHG_LST_CANCELLED_QTY")
	private Integer mkwhgLstCancelledQty;

	@Column(name="MKWHG_PRCNTG_AWAY_LTP")
	private Double mkwhgPrcntgAwayLtp;

	@Column(name="MKWHG_PRCNTG_AWAY_LTP_SL")
	private Double mkwhgPrcntgAwayLtpSl;

	@Column(name="MKWHG_CRT_BY")
	private String mkwhgCrtBy;

	@Column(name="MKWHG_CRT_DATE")
	private Date mkwhgCrtDate;

	@Column(name="MKWHG_UPDT_BY")
	private String mkwhgUpdtBy;

	@Column(name="MKWHG_UPDT_DATE")
	private Date mkwhgUpdtDate;

	@Transient
	private String[] mkwhgBrokerArray;

	@Transient
	private String[] mkwhgDealerArray;

	@Transient
	private String[] mkwhgAccNoArray;

	@Transient
	private String[] mkwhgPanArray;

	@Transient
	private String[] mkwhgNnfIdArray;
	
	@Transient
	private String[] mkwhgOrderNoArray; 

	public Integer getMkwhgRunId() {
		return mkwhgRunId;
	}

	public void setMkwhgRunId(Integer mkwhgRunId) {
		this.mkwhgRunId = mkwhgRunId;
	}

	public Integer getMkwhgUserNum() {
		return mkwhgUserNum;
	}

	public void setMkwhgUserNum(Integer mkwhgUserNum) {
		this.mkwhgUserNum = mkwhgUserNum;
	}

	public Date getMkwhgRunDate() {
		return mkwhgRunDate;
	}

	public void setMkwhgRunDate(Date mkwhgRunDate) {
		this.mkwhgRunDate = mkwhgRunDate;
	}

	public String getMkwhgSegInd() {
		return mkwhgSegInd;
	}

	public void setMkwhgSegInd(String mkwhgSegInd) {
		this.mkwhgSegInd = mkwhgSegInd;
	}

	public String getMkwhgSymbol() {
		return mkwhgSymbol;
	}

	public void setMkwhgSymbol(String mkwhgSymbol) {
		this.mkwhgSymbol = mkwhgSymbol;
	}

	public String getMkwhgSeries() {
		return mkwhgSeries;
	}

	public void setMkwhgSeries(String mkwhgSeries) {
		this.mkwhgSeries = mkwhgSeries;
	}

	public String getMkwhgBroker() {
		return Util.convertArrayToString(mkwhgBrokerArray);
	}

	public void setMkwhgBroker(String mkwhgBroker) {
		this.mkwhgBroker = mkwhgBroker;
	}

	public String getMkwhgDealer() {
		return Util.convertArrayToString(mkwhgDealerArray);
	}

	public void setMkwhgDealer(String mkwhgDealer) {
		this.mkwhgDealer = mkwhgDealer;
	}

	public String getMkwhgAccNo() {
		return Util.convertArrayToString(mkwhgAccNoArray);
	}

	public void setMkwhgAccNo(String mkwhgAccNo) {
		this.mkwhgAccNo = mkwhgAccNo;
	}

	public String getMkwhgPan() {
		return Util.convertArrayToString(mkwhgPanArray);
	}

	public void setMkwhgPan(String mkwhgPan) {
		this.mkwhgPan = mkwhgPan;
	}

	public String getMkwhgNnfId() {
		return Util.convertArrayToString(mkwhgNnfIdArray);
	}

	public void setMkwhgNnfId(String mkwhgNnfId) {
		this.mkwhgNnfId = mkwhgNnfId;
	}

	public String getMkwhgOrderNo() {
		return Util.convertArrayToString(mkwhgOrderNoArray);	}

	public void setMkwhgOrderNo(String mkwhgOrderNo) {
		this.mkwhgOrderNo = mkwhgOrderNo;
	}  
	
	public Integer getMkwhgLstUnexecQty() {
		return mkwhgLstUnexecQty;
	}

	public void setMkwhgLstUnexecQty(Integer mkwhgLstUnexecQty) {
		this.mkwhgLstUnexecQty = mkwhgLstUnexecQty;
	}

	public Integer getMkwhgLstCancelledQty() {
		return mkwhgLstCancelledQty;
	}

	public void setMkwhgLstCancelledQty(Integer mkwhgLstCancelledQty) {
		this.mkwhgLstCancelledQty = mkwhgLstCancelledQty;
	}

	public Double getMkwhgPrcntgAwayLtp() {
		return mkwhgPrcntgAwayLtp;
	}

	public void setMkwhgPrcntgAwayLtp(Double mkwhgPrcntgAwayLtp) {
		this.mkwhgPrcntgAwayLtp = mkwhgPrcntgAwayLtp;
	}

	public Double getMkwhgPrcntgAwayLtpSl() {
		return mkwhgPrcntgAwayLtpSl;
	}

	public void setMkwhgPrcntgAwayLtpSl(Double mkwhgPrcntgAwayLtpSl) {
		this.mkwhgPrcntgAwayLtpSl = mkwhgPrcntgAwayLtpSl;
	}

	public String getMkwhgCrtBy() {
		return mkwhgCrtBy;
	}

	public void setMkwhgCrtBy(String mkwhgCrtBy) {
		this.mkwhgCrtBy = mkwhgCrtBy;
	}

	public Date getMkwhgCrtDate() {
		return mkwhgCrtDate;
	}

	public void setMkwhgCrtDate(Date mkwhgCrtDate) {
		this.mkwhgCrtDate = mkwhgCrtDate;
	}

	public String getMkwhgUpdtBy() {
		return mkwhgUpdtBy;
	}

	public void setMkwhgUpdtBy(String mkwhgUpdtBy) {
		this.mkwhgUpdtBy = mkwhgUpdtBy;
	}

	public Date getMkwhgUpdtDate() {
		return mkwhgUpdtDate;
	}

	public void setMkwhgUpdtDate(Date mkwhgUpdtDate) {
		this.mkwhgUpdtDate = mkwhgUpdtDate;
	}

	public String[] getMkwhgBrokerArray() {
		return Util.convertStringToArray(mkwhgBroker);
	}

	public void setMkwhgBrokerArray(String[] mkwhgBrokerArray) {
		this.mkwhgBrokerArray = mkwhgBrokerArray;
	}

	public String[] getMkwhgDealerArray() {
		return Util.convertStringToArray(mkwhgDealer);
	}

	public void setMkwhgDealerArray(String[] mkwhgDealerArray) {
		this.mkwhgDealerArray = mkwhgDealerArray;
	}

	public String[] getMkwhgAccNoArray() {
		return Util.convertStringToArray(mkwhgAccNo);
	}

	public void setMkwhgAccNoArray(String[] mkwhgAccNoArray) {
		this.mkwhgAccNoArray = mkwhgAccNoArray;
	}

	public String[] getMkwhgPanArray() {
		return Util.convertStringToArray(mkwhgPan);
	}

	public void setMkwhgPanArray(String[] mkwhgPanArray) {
		this.mkwhgPanArray = mkwhgPanArray;
	}

	public String[] getMkwhgNnfIdArray() {
		return Util.convertStringToArray(mkwhgNnfId);
	}

	public void setMkwhgNnfIdArray(String[] mkwhgNnfIdArray) {
		this.mkwhgNnfIdArray = mkwhgNnfIdArray;
	}

	@Override
	public String toString() {
		return "MktwtchHighlightVO [mkwhgRunId=" + mkwhgRunId + ", mkwhgUserNum=" + mkwhgUserNum + ", mkwhgRunDate="
				+ mkwhgRunDate + ", mkwhgSegInd=" + mkwhgSegInd + ", mkwhgSymbol=" + mkwhgSymbol + ", mkwhgSeries="
				+ mkwhgSeries + ", mkwhgBroker=" + mkwhgBroker + ", mkwhgDealer=" + mkwhgDealer + ", mkwhgAccNo="
				+ mkwhgAccNo + ", mkwhgPan=" + mkwhgPan + ", mkwhgNnfId=" + mkwhgNnfId + ", mkwhgLstUnexecQty="
				+ mkwhgLstUnexecQty + ", mkwhgLstCancelledQty=" + mkwhgLstCancelledQty + ", mkwhgPrcntgAwayLtp="
				+ mkwhgPrcntgAwayLtp + ", mkwhgPrcntgAwayLtpSl=" + mkwhgPrcntgAwayLtpSl + ", mkwhgCrtBy=" + mkwhgCrtBy
				+ ", mkwhgCrtDate=" + mkwhgCrtDate + ", mkwhgUpdtBy=" + mkwhgUpdtBy + ", mkwhgUpdtDate=" + mkwhgUpdtDate
				+ ", mkwhgBrokerArray=" + Arrays.toString(mkwhgBrokerArray) + ", mkwhgDealerArray="
				+ Arrays.toString(mkwhgDealerArray) + ", mkwhgAccNoArray=" + Arrays.toString(mkwhgAccNoArray)
				+ ", mkwhgPanArray=" + Arrays.toString(mkwhgPanArray) + ", mkwhgNnfIdArray="
				+ Arrays.toString(mkwhgNnfIdArray) + "]";
	}
	
}