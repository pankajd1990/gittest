package com.surv.entity.marketreplay;

import java.text.ParseException;

import com.surv.exception.ValidationException;

public class EventVO {
	private Integer mrEventRunId;  
	private Integer mrEventSeqNmbr;
	private String  mrEventType;
	private String  mrEventTime;
	private String  mrEventSymbol;
	private String  mrEventSeries;
	private String  mrEvent;
	private String  mrEventDescription;
	public EventVO(Object[] object) throws ValidationException, ParseException{
		this.mrEventRunId = object[0] != null ? Integer.parseInt(object[0].toString()) : null;
		this.mrEventSeqNmbr = object[1] != null ? Integer.parseInt(object[1].toString()) : null;
		this.mrEventType = object[2] != null ? object[2].toString() : null;
		String eventTime = object[3].toString().split(" ")[1];
		eventTime = eventTime.substring(0,8);
		this.mrEventTime = object[3] != null ? eventTime  : null;
		this.mrEventSymbol = object[4] != null ? object[4].toString() : null;
		this.mrEventSeries = object[5] != null ? object[5].toString() : null;
		this.mrEvent = object[6] != null ? object[6].toString() : null;
		this.mrEventDescription = object[7] != null ? object[7].toString() : null;
	}
	public Integer getMrEventRunId() {
		return mrEventRunId;
	}
	public void setMrEventRunId(Integer mrEventRunId) {
		this.mrEventRunId = mrEventRunId;
	}
	public Integer getMrEventSeqNmbr() {
		return mrEventSeqNmbr;
	}
	public void setMrEventSeqNmbr(Integer mrEventSeqNmbr) {
		this.mrEventSeqNmbr = mrEventSeqNmbr;
	}

	public String getMrEventTime() {
		return mrEventTime;
	}
	public void setMrEventTime(String mrEventTime) {
		this.mrEventTime = mrEventTime;
	}
	public String getMrEventSymbol() {
		return mrEventSymbol;
	}
	public void setMrEventSymbol(String mrEventSymbol) {
		this.mrEventSymbol = mrEventSymbol;
	}
	public String getMrEventSeries() {
		return mrEventSeries;
	}
	public void setMrEventSeries(String mrEventSeries) {
		this.mrEventSeries = mrEventSeries;
	}
	
	public String getMrEventType() {
		return mrEventType;
	}
	public void setMrEventType(String mrEventType) {
		this.mrEventType = mrEventType;
	}
	public String getMrEvent() {
		return mrEvent;
	}
	public void setMrEvent(String mrEvent) {
		this.mrEvent = mrEvent;
	}
	public String getMrEventDescription() {
		return mrEventDescription;
	}
	public void setMrEventDescription(String mrEventDescription) {
		this.mrEventDescription = mrEventDescription;
	}
}