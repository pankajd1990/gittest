package com.surv.entity.marketreplay;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name="ALERT_RULE")
public class AlertRuleVO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="RULE_NUM")
	private Integer ruleNum;

	@Column(name="RULE_ALERT_TYPE")
	private String ruleAlertType;
	
	@Column(name="RULE_PARENT_RULE_NUM")
	private Long ruleParentRuleNum;
	
	@Column(name="RULE_TYPE")
	private String ruleType;
	
	@Column(name="RULE_NAME")
	private String ruleName;

	@Column(name="RULE_ENGINE_STRING")
	private String ruleEngineString;

	@Column(name="RULE_STRING")
	private String ruleString;

	@Column(name="RULE_USER_STRING")
	private String ruleUserString;

	public Integer getRuleNum() {
		return ruleNum;
	}

	public void setRuleNum(Integer ruleNum) {
		this.ruleNum = ruleNum;
	}

	public String getRuleAlertType() {
		return ruleAlertType;
	}

	public void setRuleAlertType(String ruleAlertType) {
		this.ruleAlertType = ruleAlertType;
	}

	public Long getRuleParentRuleNum() {
		return ruleParentRuleNum;
	}

	public void setRuleParentRuleNum(Long ruleParentRuleNum) {
		this.ruleParentRuleNum = ruleParentRuleNum;
	}

	public String getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getRuleEngineString() {
		return ruleEngineString;
	}

	public void setRuleEngineString(String ruleEngineString) {
		this.ruleEngineString = ruleEngineString;
	}

	public String getRuleString() {
		return ruleString;
	}

	public void setRuleString(String ruleString) {
		this.ruleString = ruleString;
	}

	public String getRuleUserString() {
		return ruleUserString;
	}

	public void setRuleUserString(String ruleUserString) {
		this.ruleUserString = ruleUserString;
	}

	@Override
	public String toString() {
		return "AlertRuleVO [ruleNum=" + ruleNum + ", ruleAlertType=" + ruleAlertType + ", ruleParentRuleNum="
				+ ruleParentRuleNum + ", ruleType=" + ruleType + ", ruleName=" + ruleName + ", ruleEngineString="
				+ ruleEngineString + ", ruleString=" + ruleString + ", ruleUserString=" + ruleUserString + "]";
	}
	
}