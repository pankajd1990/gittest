package com.surv.entity.marketreplay;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import com.surv.utility.Util;

public class AlertDetailsVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private int ruleNum;
	
	private String ruleName;
	
	private String ruleAlertType;
	
	private int ruleParentRuleNum;
	
	private String ruleType;
	
	private String thrshThresholdNum;
	
    private String thrshThresholdDesc;
	
	private String thrshCurrentValue;
	
	private String thrshNewValue;
	
	private Date thrshEffDate;
	
	private String thrshEffDateString;
	
	private String thrshThreshUpdtBy;
	
	private Timestamp threshUpdtDate;
	
	private int thrshRuleNo;
	
	public AlertDetailsVO() {}
	
	public AlertDetailsVO(Object[] object) {
		this.ruleNum =  object[1] != null ? Integer.parseInt(object[1].toString()) : null;
		this.ruleName =  object[0] != null ? object[0].toString() : null;
		this.ruleAlertType =  object[2] != null ? object[2].toString() : null;
		this.ruleParentRuleNum = object[3] != null ? Integer.parseInt(object[3].toString()) : null;
		this.ruleType =  object[4] != null ? object[4].toString() : null;
		this.thrshThresholdNum =  object[5] != null ? object[5].toString() : null;
		this.thrshThresholdDesc =  object[6] != null ? object[6].toString() : null;
		this.thrshCurrentValue =  object[7] != null ? object[7].toString() : null;
		this.thrshNewValue =  object[8] != null ? object[8].toString() : null;
		this.thrshEffDate = object[9] != null ? (Date)object[9] : null;
		this.thrshEffDateString = object[9] != null ? Util.convertTimeStamToDate(object[9].toString()) : null;
		this.thrshThreshUpdtBy =  object[10] != null ? object[10].toString() : null;
		this.threshUpdtDate =  object[11] != null ? (Timestamp) object[11] : null;	
		this.thrshRuleNo =  object[12] != null ? Integer.parseInt(object[12].toString()) : null;
	}
	
	public Integer getRuleNum() {
		return ruleNum;
	}

	public void setRuleNum(Integer ruleNum) {
		this.ruleNum = ruleNum;
	}

	public String getRuleName() {
		return ruleName;
	}

	public String getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getRuleAlertType() {
		return ruleAlertType;
	}

	public void setRuleAlertType(String ruleAlertType) {
		this.ruleAlertType = ruleAlertType;
	}

	public Integer getRuleParentRuleNum() {
		return ruleParentRuleNum;
	}

	public void setRuleParentRuleNum(Integer ruleParentRuleNum) {
		this.ruleParentRuleNum = ruleParentRuleNum;
	}

	public String getThrshThresholdNum() {
		return thrshThresholdNum;
	}

	public void setThrshThresholdNum(String thrshThresholdNum) {
		this.thrshThresholdNum = thrshThresholdNum;
	}

	public String getThrshThresholdDesc() {
		return thrshThresholdDesc;
	}

	public void setThrshThresholdDesc(String thrshThresholdDesc) {
		this.thrshThresholdDesc = thrshThresholdDesc;
	}

	public String getThrshCurrentValue() {
		return thrshCurrentValue;
	}

	public void setThrshCurrentValue(String thrshCurrentValue) {
		this.thrshCurrentValue = thrshCurrentValue;
	}

	public String getThrshNewValue() {
		return thrshNewValue;
	}

	public void setThrshNewValue(String thrshNewValue) {
		this.thrshNewValue = thrshNewValue;
	}

	public Date getThrshEffDate() {
		return thrshEffDate;
	}

	public void setThrshEffDate(Date thrshEffDate) {
		this.thrshEffDate = thrshEffDate;
	}

	public String getThrshThreshUpdtBy() {
		return thrshThreshUpdtBy;
	}

	public void setThrshThreshUpdtBy(String thrshThreshUpdtBy) {
		this.thrshThreshUpdtBy = thrshThreshUpdtBy;
	}

	public Timestamp getThreshUpdtDate() {
		return threshUpdtDate;
	}

	public void setThreshUpdtDate(Timestamp threshUpdtDate) {
		this.threshUpdtDate = threshUpdtDate;
	}

	public int getThrshRuleNo() {
		return thrshRuleNo;
	}
	
	public void setThrshRuleNo(int thrshRuleNo) {
		this.thrshRuleNo = thrshRuleNo;
	}

	public String getThrshEffDateString() {
		return thrshEffDateString;
	}

	public void setThrshEffDateString(String thrshEffDateString) {
		this.thrshEffDateString = thrshEffDateString;
	}
	
}