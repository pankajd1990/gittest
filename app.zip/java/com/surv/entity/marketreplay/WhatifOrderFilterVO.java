package com.surv.entity.marketreplay;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import com.surv.cache.CacheManager;
import com.surv.constant.ValidationMessage;
import com.surv.constraints.annotations.ValidateAccCodeValidation;
import com.surv.constraints.annotations.ValidateLimitOrdTypeValidation;
import com.surv.constraints.annotations.ValidateMarketOrdTypeValidation;
import com.surv.constraints.annotations.ValidatePriceAdjSignValueValidation;
import com.surv.constraints.annotations.ValidateSLLimitOrdTypeValidation;
import com.surv.constraints.annotations.ValidateSLMarketOrdTypeValidation;
import com.surv.constraints.group.addWhatifOrderFiltersVO;
import com.surv.constraints.group.modifyWhatifOrderFiltersVO;


/**
 * The persistent class for the whatif_order_filters database table.
 * 
 */
@ValidatePriceAdjSignValueValidation(groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
@ValidateSLLimitOrdTypeValidation(groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
@ValidateSLMarketOrdTypeValidation(groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
@ValidateLimitOrdTypeValidation(groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
@ValidateAccCodeValidation(groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
@ValidateMarketOrdTypeValidation(groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
@Entity
@Table(name="whatif_order_filters")

public class WhatifOrderFilterVO implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="WHATIF_RUN_ID")
	private Integer whatifRunId;

	@Column(name="WHATIF_ACCOUNT_CODE")
	@Pattern(regexp="[A-Za-z0-9]+$", message=ValidationMessage.ERROR_ACC_CODE_INVALID, groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
	private String whatifAccountCode;

	@Column(name="WHATIF_ALGO_CATEGORY")
	//	@Pattern(regexp="^[0-9]*$", message=ValidationMessage.ERROR_PAN_ID_INVALID, groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
	private Integer whatifAlgoCategory;

	@Column(name="WHATIF_ALGO_ID")
	//	@Pattern(regexp="^[0-9]*$", message=ValidationMessage.ERROR_PAN_ID_INVALID, groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
	private Integer whatifAlgoId;

	@Column(name="WHATIF_BRANCH_ID")
	private Integer whatifBranchId;

	@Column(name="WHATIF_BUYSELL")
	private String whatifBuysell;

	@Column(name="WHATIF_CLIENT_PANID")
	@Pattern(regexp="^([A-Z]{5})([0-9]{4})([A-Z]{1})+$", message=ValidationMessage.ERROR_PAN_ID_INVALID, groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
	private String whatifClientPanid;

	@Column(name="WHATIF_CRT_BY")
	private String whatifCrtBy;

	@Column(name="WHATIF_CRT_DATE")
	private Timestamp whatifCrtDate;

	@Column(name="WHATIF_DEALER_ID")
	//	@Length(min=5, max=5, message=ValidationMessage.ERROR_DEALER_ID_LENGHT, groups=addWhatifOrderFiltersVO.class)
	@NotNull(message=ValidationMessage.ERROR_DEALER_ID_NOT_EMPTY, groups=addWhatifOrderFiltersVO.class)
	//	@Pattern(regexp="^[0-9]*$", message=ValidationMessage.ERROR_DEALER_ID_INVALID, groups=addWhatifOrderFiltersVO.class)
	private Integer whatifDealerId;

	@Column(name="WHATIF_ERROR_CODE")
	private Integer whatifErrorCode;

	@Column(name="WHATIF_ERROR_DESC")
	private String whatifErrorDesc;

	@Column(name="WHATIF_FILTER_NUMBER")
	private Integer whatifFilterNumber;

	@Column(name="WHATIF_FILTER_TYPE")
	private String whatifFilterType;

	@Column(name="WHATIF_LIMIT_PRICE")
	//	@Pattern(regexp="^[0-9]+(.[0-9]{0,2})?$", message=ValidationMessage.ERROR_PAN_ID_INVALID, groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
	private Double whatifLimitPrice;

	@Column(name="WHATIF_MKT_TYPE")
	@NotEmpty(message=ValidationMessage.ERROR_MKT_TYPE_NOT_EMPTY, groups=addWhatifOrderFiltersVO.class)
	private String whatifMktType;

	@Column(name="WHATIF_NNF_ID")
	//	@Pattern(regexp="^[0-9]*$", message=ValidationMessage.ERROR_PAN_ID_INVALID, groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
	private Long whatifNnfId;

	@Column(name="WHATIF_ORD_DISCLOSED_QTY")
	//	@Pattern(regexp="^[0-9]*$", message=ValidationMessage.ERROR_PAN_ID_INVALID, groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
	private Integer whatifOrdDisclosedQty;

	@Column(name="WHATIF_ORD_QTY")
	//	@Pattern(regexp="^[0-9]*$", message=ValidationMessage.ERROR_PAN_ID_INVALID, groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
	private Integer whatifOrdQty;

	@Column(name="WHATIF_ORD_TYPE")
	@NotEmpty(message=ValidationMessage.ERROR_ORD_TYPE_NOT_EMPTY, groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
	private String whatifOrdType;

	@Column(name="WHATIF_ORD_VALIDITY")
	@NotEmpty(message=ValidationMessage.ERROR_ORD_VALIDITY_NOT_EMPTY,groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
	private String whatifOrdValidity;

	@Column(name="WHATIF_ORDER_NUMBER")
	//	@Pattern(regexp="^[0-9]*$", message=ValidationMessage.ERROR_PAN_ID_INVALID, groups=addWhatifOrderFiltersVO.class)
	private Long whatifOrderNumber;

	@Column(name="WHATIF_PREOPEN_IND")
	private Integer whatifPreopenInd;

	@Column(name="WHATIF_PRICEADJ_SIGN")
	private String whatifPriceadjSign;

	@Column(name="WHATIF_PRICEADJ_VAL")
	//	@Pattern(regexp="^[0-9]+(.[0-9]{0,2})?$", message=ValidationMessage.ERROR_PAN_ID_INVALID,groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
	private Double whatifPriceadjVal;

	@Column(name="WHATIF_PROCLI_TYPE")
	private Integer whatifProcliType;

	@Column(name="WHATIF_RUN_SEQ_NUMBER")
	private Integer whatifRunSeqNumber;

	@Column(name="WHATIF_SEQ_NUMBER")
	private Long whatifSeqNumber;

	@Column(name="WHATIF_TM_CODE")
	@Length(min=5, max=5, message=ValidationMessage.ERROR_TM_CODE_LENGHT, groups=addWhatifOrderFiltersVO.class)
	@NotEmpty(message=ValidationMessage.ERROR_TM_CODE_NOT_EMPTY, groups=addWhatifOrderFiltersVO.class)
	@Pattern(regexp="^[a-zA-Z0-9]+$", message=ValidationMessage.ERROR_TM_CODE_INVALID, groups=addWhatifOrderFiltersVO.class)
	private String whatifTmCode;

	@Column(name="WHATIF_TRIGGER_PRICE")
	//	@Pattern(regexp="^[0-9]+(.[0-9]{0,2})?$", message=ValidationMessage.ERROR_PAN_ID_INVALID, groups={addWhatifOrderFiltersVO.class,modifyWhatifOrderFiltersVO.class})
	private Double whatifTriggerPrice;

	@Column(name="WHATIF_UPD_BY")
	private String whatifUpdBy;

	@Column(name="WHATIF_UPD_DATE")
	private Timestamp whatifUpdDate;

	@Transient
	private String whatifBuysellName;

	@Transient
	private String whatifMktTypeName;

	@Transient
	private String whatifOrdTypeName;

	@Transient
	private String whatifOrdValidityName;

	@Transient
	private String whatifProcliTypeName;

	@Transient
	private String whatifPriceadjSignName;

	@Transient
	private String whatifPreopenIndName;



	@Override
	public String toString() {
		return "WhatifOrderFilterVO [whatifAccountCode=" + whatifAccountCode + ", whatifAlgoCategory="
				+ whatifAlgoCategory + ", whatifAlgoId=" + whatifAlgoId + ", whatifBranchId=" + whatifBranchId
				+ ", whatifBuysell=" + whatifBuysell + ", whatifClientPanid=" + whatifClientPanid + ", whatifCrtBy="
				+ whatifCrtBy + ", whatifCrtDate=" + whatifCrtDate + ", whatifDealerId=" + whatifDealerId
				+ ", whatifErrorCode=" + whatifErrorCode + ", whatifErrorDesc=" + whatifErrorDesc
				+ ", whatifFilterNumber=" + whatifFilterNumber + ", whatifFilterType=" + whatifFilterType
				+ ", whatifLimitPrice=" + whatifLimitPrice + ", whatifMktType=" + whatifMktType + ", whatifNnfId="
				+ whatifNnfId + ", whatifOrdDisclosedQty=" + whatifOrdDisclosedQty + ", whatifOrdQty=" + whatifOrdQty
				+ ", whatifOrdType=" + whatifOrdType + ", whatifOrdValidity=" + whatifOrdValidity
				+ ", whatifOrderNumber=" + whatifOrderNumber + ", whatifPreopenInd=" + whatifPreopenInd
				+ ", whatifPriceadjSign=" + whatifPriceadjSign + ", whatifPriceadjVal=" + whatifPriceadjVal
				+ ", whatifProcliType=" + whatifProcliType + ", whatifRunId=" + whatifRunId + ", whatifRunSeqNumber="
				+ whatifRunSeqNumber + ", whatifSeqNumber=" + whatifSeqNumber + ", whatifTmCode=" + whatifTmCode
				+ ", whatifTriggerPrice=" + whatifTriggerPrice + ", whatifUpdBy=" + whatifUpdBy + ", whatifUpdDate="
				+ whatifUpdDate + ", whatifBuysellName=" + whatifBuysellName + ", whatifMktTypeName="
				+ whatifMktTypeName + ", whatifOrdTypeName=" + whatifOrdTypeName + ", whatifOrdValidityName="
				+ whatifOrdValidityName + ", whatifProcliTypeName=" + whatifProcliTypeName + ", whatifPriceadjSignName="
				+ whatifPriceadjSignName + ", whatifPreopenIndName=" + whatifPreopenIndName + "]";
	}

	public WhatifOrderFilterVO() {
	}

	public String getWhatifBuysellName() {
		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_BUY_SELL");
		return map.get(this.getWhatifBuysell().toString()) != null ? map.get(this.getWhatifBuysell().toString()) : "";
	}

	public void setWhatifBuysellName(String whatifBuysellName) {
		this.whatifBuysellName = whatifBuysellName;
	}

	public String getWhatifMktTypeName() {
		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_MARKET");
		return map.get(this.getWhatifMktType().toString()) != null ? map.get(this.getWhatifMktType().toString()) : "";
	}

	public void setwhatifMktTypeName(String whatifMktTypeName) {
		this.whatifMktTypeName = whatifMktTypeName;
	}

	public String getWhatifOrdTypeName() {
		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_ORDER_TYPE");
		return map.get(this.getWhatifOrdType().toString()) != null ? map.get(this.getWhatifOrdType().toString()) : "";
	}

	public void setWhatifOrdTypeName(String whatifOrdTypeName) {
		this.whatifOrdTypeName = whatifOrdTypeName;
	}

	public String getWhatifOrdValidityName() {
		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_ORDER_VALIDITY");
		return map.get(this.getWhatifOrdValidity().toString()) != null ? map.get(this.getWhatifOrdValidity().toString()) : "";
	}

	public void setWhatifOrdValidityName(String whatifOrdValidityName) {
		this.whatifOrdValidityName = whatifOrdValidityName;
	}

	public String getWhatifProcliTypeName() {
		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_PRO_CLI");
		return map.get(this.getWhatifProcliType().toString()) != null ? map.get(this.getWhatifProcliType().toString()) : "";
	}

	public void setWhatifProcliTypeName(String whatifProcliTypeName) {
		this.whatifProcliTypeName = whatifProcliTypeName;
	}

	public String getWhatifPriceadjSignName() {
		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_PRICE_ADJUST");
		return map.get(this.getWhatifPriceadjSign().toString()) != null ? map.get(this.getWhatifPriceadjSign().toString()) : "";
	}

	public void setWhatifPriceadjSignName(String whatifPriceadjSignName) {
		this.whatifPriceadjSignName = whatifPriceadjSignName;
	}

	public String getWhatifPreopenIndName() {
		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_PREOPEN");
		return map.get(this.getWhatifPreopenInd().toString()) != null ? map.get(this.getWhatifPreopenInd().toString()) : "";
	}

	public void setWhatifPreopenIndName(String whatifPreopenIndName) {
		this.whatifPreopenIndName = whatifPreopenIndName;
	}

	public String getWhatifAccountCode() {
		return this.whatifAccountCode;
	}

	public void setWhatifAccountCode(String whatifAccountCode) {
		this.whatifAccountCode = whatifAccountCode;
	}

	public Integer getWhatifAlgoCategory() {
		return this.whatifAlgoCategory;
	}

	public void setWhatifAlgoCategory(Integer whatifAlgoCategory) {
		this.whatifAlgoCategory = whatifAlgoCategory;
	}

	public Integer getWhatifAlgoId() {
		return this.whatifAlgoId;
	}

	public void setWhatifAlgoId(Integer whatifAlgoId) {
		this.whatifAlgoId = whatifAlgoId;
	}

	public Integer getWhatifBranchId() {
		return this.whatifBranchId;
	}

	public void setWhatifBranchId(Integer whatifBranchId) {
		this.whatifBranchId = whatifBranchId;
	}

	public String getWhatifBuysell() {
		return this.whatifBuysell;
	}

	public void setWhatifBuysell(String whatifBuysell) {
		this.whatifBuysell = whatifBuysell;
	}

	public String getWhatifClientPanid() {
		return this.whatifClientPanid;
	}

	public void setWhatifClientPanid(String whatifClientPanid) {
		this.whatifClientPanid = whatifClientPanid;
	}

	public String getWhatifCrtBy() {
		return this.whatifCrtBy;
	}

	public void setWhatifCrtBy(String whatifCrtBy) {
		this.whatifCrtBy = whatifCrtBy;
	}

	public Timestamp getWhatifCrtDate() {
		return this.whatifCrtDate;
	}

	public void setWhatifCrtDate(Timestamp whatifCrtDate) {
		this.whatifCrtDate = whatifCrtDate;
	}

	public Integer getWhatifDealerId() {
		return this.whatifDealerId;
	}

	public void setWhatifDealerId(Integer whatifDealerId) {
		this.whatifDealerId = whatifDealerId;
	}

	public Integer getWhatifErrorCode() {
		return this.whatifErrorCode;
	}

	public void setWhatifErrorCode(Integer whatifErrorCode) {
		this.whatifErrorCode = whatifErrorCode;
	}

	public String getWhatifErrorDesc() {
		return this.whatifErrorDesc;
	}

	public void setWhatifErrorDesc(String whatifErrorDesc) {
		this.whatifErrorDesc = whatifErrorDesc;
	}

	public Integer getWhatifFilterNumber() {
		return this.whatifFilterNumber;
	}

	public void setWhatifFilterNumber(Integer whatifFilterNumber) {
		this.whatifFilterNumber = whatifFilterNumber;
	}

	public String getWhatifFilterType() {
		return this.whatifFilterType;
	}

	public void setWhatifFilterType(String whatifFilterType) {
		this.whatifFilterType = whatifFilterType;
	}

	public Double getWhatifLimitPrice() {
		return this.whatifLimitPrice;
	}

	public void setWhatifLimitPrice(Double whatifLimitPrice) {
		this.whatifLimitPrice = whatifLimitPrice;
	}

	public String getWhatifMktType() {
		return this.whatifMktType;
	}

	public void setWhatifMktType(String whatifMktType) {
		this.whatifMktType = whatifMktType;
	}

	public Long getWhatifNnfId() {
		return this.whatifNnfId;
	}

	public void setWhatifNnfId(Long whatifNnfId) {
		this.whatifNnfId = whatifNnfId;
	}

	public Integer getWhatifOrdDisclosedQty() {
		return this.whatifOrdDisclosedQty;
	}

	public void setWhatifOrdDisclosedQty(Integer whatifOrdDisclosedQty) {
		this.whatifOrdDisclosedQty = whatifOrdDisclosedQty;
	}

	public Integer getWhatifOrdQty() {
		return this.whatifOrdQty;
	}

	public void setWhatifOrdQty(Integer whatifOrdQty) {
		this.whatifOrdQty = whatifOrdQty;
	}

	public String getWhatifOrdType() {
		return this.whatifOrdType;
	}

	public void setWhatifOrdType(String whatifOrdType) {
		this.whatifOrdType = whatifOrdType;
	}

	public String getWhatifOrdValidity() {
		return this.whatifOrdValidity;
	}

	public void setWhatifOrdValidity(String whatifOrdValidity) {
		this.whatifOrdValidity = whatifOrdValidity;
	}

	public Long getWhatifOrderNumber() {
		return this.whatifOrderNumber;
	}

	public void setWhatifOrderNumber(Long whatifOrderNumber) {
		this.whatifOrderNumber = whatifOrderNumber;
	}

	public Integer getWhatifPreopenInd() {
		return this.whatifPreopenInd;
	}

	public void setWhatifPreopenInd(Integer whatifPreopenInd) {
		this.whatifPreopenInd = whatifPreopenInd;
	}

	public String getWhatifPriceadjSign() {
		return this.whatifPriceadjSign;
	}

	public void setWhatifPriceadjSign(String whatifPriceadjSign) {
		this.whatifPriceadjSign = whatifPriceadjSign;
	}

	public Double getWhatifPriceadjVal() {
		return this.whatifPriceadjVal;
	}

	public void setWhatifPriceadjVal(Double whatifPriceadjVal) {
		this.whatifPriceadjVal = whatifPriceadjVal;
	}

	public Integer getWhatifProcliType() {
		return this.whatifProcliType;
	}

	public void setWhatifProcliType(Integer whatifProcliType) {
		this.whatifProcliType = whatifProcliType;
	}

	public Integer getWhatifRunId() {
		return this.whatifRunId;
	}

	public void setWhatifRunId(Integer whatifRunId) {
		this.whatifRunId = whatifRunId;
	}

	public Integer getWhatifRunSeqNumber() {
		return this.whatifRunSeqNumber;
	}

	public void setWhatifRunSeqNumber(Integer whatifRunSeqNumber) {
		this.whatifRunSeqNumber = whatifRunSeqNumber;
	}

	public Long getWhatifSeqNumber() {
		return this.whatifSeqNumber;
	}

	public void setWhatifSeqNumber(Long whatifSeqNumber) {
		this.whatifSeqNumber = whatifSeqNumber;
	}

	public String getWhatifTmCode() {
		return this.whatifTmCode;
	}

	public void setWhatifTmCode(String whatifTmCode) {
		this.whatifTmCode = whatifTmCode;
	}

	public Double getWhatifTriggerPrice() {
		return this.whatifTriggerPrice;
	}

	public void setWhatifTriggerPrice(Double whatifTriggerPrice) {
		this.whatifTriggerPrice = whatifTriggerPrice;
	}

	public String getWhatifUpdBy() {
		return this.whatifUpdBy;
	}

	public void setWhatifUpdBy(String whatifUpdBy) {
		this.whatifUpdBy = whatifUpdBy;
	}

	public Timestamp getWhatifUpdDate() {
		return this.whatifUpdDate;
	}

	public void setWhatifUpdDate(Timestamp whatifUpdDate) {
		this.whatifUpdDate = whatifUpdDate;
	}

}