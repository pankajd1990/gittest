package com.surv.entity.marketreplay;

import java.io.Serializable;

import com.nse.ngs.domain.mr.PricePoint;

public class SellOrderVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Double price;
	private Long qty;
	private Long order;
	private Integer seqNo;

	public SellOrderVO() {}

	public SellOrderVO(Integer mrSeqNmbr, PricePoint pricePoint) {
		this.seqNo = mrSeqNmbr;
		this.price = pricePoint.getPricePoint();
		this.qty = pricePoint.getQty();
		this.order = pricePoint.getCount();
		
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Long getQty() {
		return qty;
	}

	public void setQty(Long qty) {
		this.qty = qty;
	}

	public Long getOrder() {
		return order;
	}

	public void setOrder(Long order) {
		this.order = order;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	@Override
	public String toString() {
		return "SellOrderVO [price=" + price + ", qty=" + qty + ", order=" + order + "]";
	}

}