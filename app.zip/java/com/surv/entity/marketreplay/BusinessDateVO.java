package com.surv.entity.marketreplay;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.surv.utility.Util;

@Entity
@Table(name="BUSINESS_DATE")
public class BusinessDateVO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="BSDT_SEG_IND")
	private String bsdtSegInd;

	@Id
	@Column(name="BSDT_CURR_BUSS_DATE")
	private Date bsdtCurrBussDate;

	@Column(name="BSDT_PREV_BUSS_DATE")
	private Date bsdtPrevBussDate;

	@Column(name="BSDT_NEXT_BUSS_DATE")
	private Date bsdtNextBussDate;

	@Column(name="BSDT_SYSTEM_STAT")
	private String bsdtSystemStat;

	@Column(name="BSDT_CRT_BY")
	private String bsdtCrtBy;

	@Column(name="BSDT_CRT_DATE")
	private Date bsdtCrtDate;

	@Column(name="BSDT_UPDT_BY")
	private String bsdtUpdtBy;

	@Column(name="BSDT_UPDT_DATE")
	private Date bsdtUpdtDate;

	@Transient
	private String currBussDate;

	@Transient
	private String prevBussDate;

	@Transient
	private String nextBussDate;


	public String getBsdtSegInd() {
		return bsdtSegInd;
	}

	public void setBsdtSegInd(String bsdtSegInd) {
		this.bsdtSegInd = bsdtSegInd;
	}

	public Date getBsdtCurrBussDate() {
		return bsdtCurrBussDate;
	}

	public void setBsdtCurrBussDate(Date bsdtCurrBussDate) {
		this.bsdtCurrBussDate = bsdtCurrBussDate;
	}

	public Date getBsdtPrevBussDate() {
		return bsdtPrevBussDate;
	}

	public void setBsdtPrevBussDate(Date bsdtPrevBussDate) {
		this.bsdtPrevBussDate = bsdtPrevBussDate;
	}

	public Date getBsdtNextBussDate() {
		return bsdtNextBussDate;
	}

	public void setBsdtNextBussDate(Date bsdtNextBussDate) {
		this.bsdtNextBussDate = bsdtNextBussDate;
	}

	public String getBsdtSystemStat() {
		return bsdtSystemStat;
	}

	public void setBsdtSystemStat(String bsdtSystemStat) {
		this.bsdtSystemStat = bsdtSystemStat;
	}

	public String getBsdtCrtBy() {
		return bsdtCrtBy;
	}

	public void setBsdtCrtBy(String bsdtCrtBy) {
		this.bsdtCrtBy = bsdtCrtBy;
	}

	public Date getBsdtCrtDate() {
		return bsdtCrtDate;
	}

	public void setBsdtCrtDate(Date bsdtCrtDate) {
		this.bsdtCrtDate = bsdtCrtDate;
	}

	public String getBsdtUpdtBy() {
		return bsdtUpdtBy;
	}

	public void setBsdtUpdtBy(String bsdtUpdtBy) {
		this.bsdtUpdtBy = bsdtUpdtBy;
	}

	public Date getBsdtUpdtDate() {
		return bsdtUpdtDate;
	}

	public void setBsdtUpdtDate(Date bsdtUpdtDate) {
		this.bsdtUpdtDate = bsdtUpdtDate;
	}

	public String getCurrBussDate() {
		return Util.getDateString(this.bsdtCurrBussDate);
	}

	public void setCurrBussDate(String currBussDate) {
		this.currBussDate = currBussDate;
	}

	public String getPrevBussDate() {
		return prevBussDate;
	}

	public void setPrevBussDate(String prevBussDate) {
		this.prevBussDate = prevBussDate;
	}

	public String getNextBussDate() {
		return nextBussDate;
	}

	public void setNextBussDate(String nextBussDate) {
		this.nextBussDate = nextBussDate;
	}

	@Override
	public String toString() {
		return "BusinessDateVO [bsdtSegInd=" + bsdtSegInd + ", bsdtCurrBussDate=" + bsdtCurrBussDate
				+ ", bsdtPrevBussDate=" + bsdtPrevBussDate + ", bsdtNextBussDate=" + bsdtNextBussDate
				+ ", bsdtSystemStat=" + bsdtSystemStat + ", bsdtCrtBy=" + bsdtCrtBy + ", bsdtCrtDate=" + bsdtCrtDate
				+ ", bsdtUpdtBy=" + bsdtUpdtBy + ", bsdtUpdtDate=" + bsdtUpdtDate + "]";
	}

}