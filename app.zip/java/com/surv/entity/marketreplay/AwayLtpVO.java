package com.surv.entity.marketreplay;

import java.io.Serializable;

import com.surv.exception.ValidationException;
import com.surv.utility.Util;

public class AwayLtpVO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long mrBuyQtyAwayLTP;
	private Long mrSellQtyAwayLTP;
	private Long mrBuySLQtyAwayLTP;
	private Long mrSellSLQtyAwayLTP;
	
	public AwayLtpVO() {}
	
	public AwayLtpVO(Object[] object) throws ValidationException {
		this.mrBuyQtyAwayLTP = Util.getLongValue(object, "mrBuyQtyAwayLTP");
		this.mrSellQtyAwayLTP = Util.getLongValue(object, "mrSellQtyAwayLTP");
		this.mrBuySLQtyAwayLTP = Util.getLongValue(object, "mrBuySLQtyAwayLTP");
		this.mrSellSLQtyAwayLTP = Util.getLongValue(object, "mrSellSLQtyAwayLTP");
	}

	public Long getMrBuyQtyAwayLP() {
		return mrBuyQtyAwayLTP;
	}

	public void setMrBuyQtyAwayLP(Long mrBuyQtyAwayLP) {
		this.mrBuyQtyAwayLTP = mrBuyQtyAwayLP;
	}

	public Long getMrSellQtyAwayLP() {
		return mrSellQtyAwayLTP;
	}

	public void setMrSellQtyAwayLP(Long mrSellQtyAwayLP) {
		this.mrSellQtyAwayLTP = mrSellQtyAwayLP;
	}

	public Long getMrBuySLQtyAwayLTP() {
		return mrBuySLQtyAwayLTP;
	}

	public void setMrBuySLQtyAwayLTP(Long mrBuySLQtyAwayLTP) {
		this.mrBuySLQtyAwayLTP = mrBuySLQtyAwayLTP;
	}

	public Long getMrSellSLQtyAwayLTP() {
		return mrSellSLQtyAwayLTP;
	}

	public void setMrSellSLQtyAwayLTP(Long mrSellSLQtyAwayLTP) {
		this.mrSellSLQtyAwayLTP = mrSellSLQtyAwayLTP;
	}

	@Override
	public String toString() {
		return "AwayLtpVO [mrBuyQtyAwayLP=" + mrBuyQtyAwayLTP + ", mrSellQtyAwayLP=" + mrSellQtyAwayLTP
				+ ", mrBuySLQtyAwayLTP=" + mrBuySLQtyAwayLTP + ", mrSellSLQtyAwayLTP=" + mrSellSLQtyAwayLTP + "]";
	}

}