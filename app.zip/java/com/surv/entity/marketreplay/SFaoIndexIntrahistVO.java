package com.surv.entity.marketreplay;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the s_fao_index_intrahist database table.
 * 
 */
@Entity
@Table(name="s_fao_index_intrahist")
public class SFaoIndexIntrahistVO implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="idx_close_val")
	private BigDecimal idxCloseVal;
	
	@Id
	@Column(name="idx_curr_val")
	private BigDecimal idxCurrVal;
	
	@Id
	@Column(name="idx_high_val")
	private BigDecimal idxHighVal;

	@Id
	@Column(name="idx_idx_seq_num")
	private Long idxIdxSeqNum;

	@Id
	@Column(name="idx_low_val")
	private BigDecimal idxLowVal;

	@Id
	@Column(name="idx_name_ck")
	private String idxNameCk;

	@Id
	@Column(name="idx_opn_val")
	private BigDecimal idxOpnVal;

	@Id
	@Column(name="idx_perc_dev_hi_lo")
	private BigDecimal idxPercDevHiLo;

	@Id
	@Column(name="idx_perc_dev_prev_close_open")
	private BigDecimal idxPercDevPrevCloseOpen;

	@Id
	@Column(name="idx_prev_close_val")
	private BigDecimal idxPrevCloseVal;

	@Id
	@Column(name="idx_rcvd_time_ck")
	private Date idxRcvdTimeCk;

	@Id
	@Column(name="idx_seq_num")
	private Long idxSeqNum;

	@Id
	@Column(name="idx_yr_high")
	private BigDecimal idxYrHigh;

	@Id
	@Column(name="idx_yr_low")
	private BigDecimal idxYrLow;


	public BigDecimal getIdxCloseVal() {
		return this.idxCloseVal;
	}

	public void setIdxCloseVal(BigDecimal idxCloseVal) {
		this.idxCloseVal = idxCloseVal;
	}

	public BigDecimal getIdxCurrVal() {
		return this.idxCurrVal;
	}

	public void setIdxCurrVal(BigDecimal idxCurrVal) {
		this.idxCurrVal = idxCurrVal;
	}

	public BigDecimal getIdxHighVal() {
		return this.idxHighVal;
	}

	public void setIdxHighVal(BigDecimal idxHighVal) {
		this.idxHighVal = idxHighVal;
	}

	public Long getIdxIdxSeqNum() {
		return this.idxIdxSeqNum;
	}

	public void setIdxIdxSeqNum(Long idxIdxSeqNum) {
		this.idxIdxSeqNum = idxIdxSeqNum;
	}

	public BigDecimal getIdxLowVal() {
		return this.idxLowVal;
	}

	public void setIdxLowVal(BigDecimal idxLowVal) {
		this.idxLowVal = idxLowVal;
	}

	public String getIdxNameCk() {
		return this.idxNameCk;
	}

	public void setIdxNameCk(String idxNameCk) {
		this.idxNameCk = idxNameCk;
	}

	public BigDecimal getIdxOpnVal() {
		return this.idxOpnVal;
	}

	public void setIdxOpnVal(BigDecimal idxOpnVal) {
		this.idxOpnVal = idxOpnVal;
	}

	public BigDecimal getIdxPercDevHiLo() {
		return this.idxPercDevHiLo;
	}

	public void setIdxPercDevHiLo(BigDecimal idxPercDevHiLo) {
		this.idxPercDevHiLo = idxPercDevHiLo;
	}

	public BigDecimal getIdxPercDevPrevCloseOpen() {
		return this.idxPercDevPrevCloseOpen;
	}

	public void setIdxPercDevPrevCloseOpen(BigDecimal idxPercDevPrevCloseOpen) {
		this.idxPercDevPrevCloseOpen = idxPercDevPrevCloseOpen;
	}

	public BigDecimal getIdxPrevCloseVal() {
		return this.idxPrevCloseVal;
	}

	public void setIdxPrevCloseVal(BigDecimal idxPrevCloseVal) {
		this.idxPrevCloseVal = idxPrevCloseVal;
	}

	public Date getIdxRcvdTimeCk() {
		return this.idxRcvdTimeCk;
	}

	public void setIdxRcvdTimeCk(Date idxRcvdTimeCk) {
		this.idxRcvdTimeCk = idxRcvdTimeCk;
	}

	public Long getIdxSeqNum() {
		return this.idxSeqNum;
	}

	public void setIdxSeqNum(Long idxSeqNum) {
		this.idxSeqNum = idxSeqNum;
	}

	public BigDecimal getIdxYrHigh() {
		return this.idxYrHigh;
	}

	public void setIdxYrHigh(BigDecimal idxYrHigh) {
		this.idxYrHigh = idxYrHigh;
	}

	public BigDecimal getIdxYrLow() {
		return this.idxYrLow;
	}

	public void setIdxYrLow(BigDecimal idxYrLow) {
		this.idxYrLow = idxYrLow;
	}

	@Override
	public String toString() {
		return "SFaoIndexIntrahistVO [idxCloseVal=" + idxCloseVal + ", idxCurrVal=" + idxCurrVal + ", idxHighVal="
				+ idxHighVal + ", idxIdxSeqNum=" + idxIdxSeqNum + ", idxLowVal=" + idxLowVal + ", idxNameCk="
				+ idxNameCk + ", idxOpnVal=" + idxOpnVal + ", idxPercDevHiLo=" + idxPercDevHiLo
				+ ", idxPercDevPrevCloseOpen=" + idxPercDevPrevCloseOpen + ", idxPrevCloseVal=" + idxPrevCloseVal
				+ ", idxRcvdTimeCk=" + idxRcvdTimeCk + ", idxSeqNum=" + idxSeqNum + ", idxYrHigh=" + idxYrHigh
				+ ", idxYrLow=" + idxYrLow + "]";
	}
}