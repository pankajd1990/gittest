package com.surv.entity.marketreplay;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the s_cm_security_master database table.
 * 
 */
@Entity
@Table(name="s_cm_security_master")
public class SCmSecurityMasterVO implements Serializable {
	private static final long serialVersionUID = 1L;
	public SCmSecurityMasterVO() {}
	public SCmSecurityMasterVO(Object[] object) {
		this.symbol = object[0] != null ? object[0].toString() : null;
		this.series = object[1] != null ? object[1].toString() : null;
	}
	
	
	@Id
	@Column(name="issue_ip_date")
	private Date issueIpDate;

	@Id
	@Column(name="issue_mat_date")
	private Date issueMatDate;

	@Id
	@Temporal(TemporalType.DATE)
	@Column(name="issue_strt_date")
	private Date issueStrtDate;

	@Id
	@Temporal(TemporalType.DATE)
	@Column(name="sec_adm_dt")
	private Date secAdmDt;

	@Id
	@Column(name="sec_agm_purp")
	private String secAgmPurp;

	@Id
	@Column(name="sec_aon_allow")
	private String secAonAllow;

	@Id
	@Column(name="sec_bc_end_dt")
	private Date secBcEndDt;

	@Id
	@Temporal(TemporalType.DATE)
	@Column(name="sec_bc_strt_dt")
	private Date secBcStrtDt;

	@Id
	@Column(name="sec_bon_purp")
	private String secBonPurp;

	@Id
	@Column(name="sec_cd")
	private String secCd;

	@Id
	@Column(name="sec_cr_rating")
	private String secCrRating;

	@Id
	@Column(name="sec_ctrl_id")
	private Long secCtrlId;

	@Id
	@Column(name="sec_currency")
	private String secCurrency;

	@Id
	@Column(name="sec_div_purp")
	private String secDivPurp;

	@Id
	@Column(name="sec_egm_purp")
	private String secEgmPurp;

	@Id
	@Temporal(TemporalType.DATE)
	@Column(name="sec_ex_dt")
	private Date secExDt;

	@Id
	@Temporal(TemporalType.DATE)
	@Column(name="sec_expl_dt")
	private Date secExplDt;

	@Id
	@Column(name="sec_freeze_pct")
	private BigDecimal secFreezePct;
	
	@Id
	@Column(name="sec_id")
	private String secId;

	@Id
	@Column(name="sec_int_purp")
	private String secIntPurp;

	@Id
	@Column(name="sec_mf_allow")
	private String secMfAllow;

	@Id
	@Temporal(TemporalType.DATE)
	@Column(name="sec_nd_end_dt")
	private Date secNdEndDt;

	@Id
	@Temporal(TemporalType.DATE)
	@Column(name="sec_nd_strt_dt")
	private Date secNdStrtDt;

	@Id
	@Temporal(TemporalType.DATE)
	@Column(name="sec_open_dt")
	private Date secOpenDt;

	@Id
	@Column(name="sec_oth_purp")
	private String secOthPurp;

	@Id
	@Column(name="sec_part_ind")
	private String secPartInd;

	@Id
	@Column(name="sec_pr")
	private BigDecimal secPr;

	@Id
	@Temporal(TemporalType.DATE)
	@Column(name="sec_readm_dt")
	private Date secReadmDt;

	@Id
	@Temporal(TemporalType.DATE)
	@Column(name="sec_rec_dt")
	private Date secRecDt;

	@Id
	@Column(name="sec_rht_purp")
	private String secRhtPurp;

	@Id
	@Column(name="sec_tic_size")
	private BigDecimal secTicSize;

	@Id
	@Column(name="sec_type")
	private String secType;

	@Id
	@Column(name="sec_upd_dt_tr")
	private Timestamp secUpdDtTr;

	@Id
	@Column(name="sec_warn_pct")
	private BigDecimal secWarnPct;

	@Id
	@Column(name="security_base_price")
	private BigDecimal securityBasePrice;

	@Id
	@Column(name="security_face_value")
	private BigDecimal securityFaceValue;

	@Id
	@Column(name="security_hi_percent")
	private BigDecimal securityHiPercent;

	@Id
	@Column(name="security_hi_pr_range")
	private BigDecimal securityHiPrRange;

	@Id
	@Column(name="security_int_rate")
	private BigDecimal securityIntRate;

	@Id
	@Column(name="security_intl_code")
	private String securityIntlCode;

	@Id
	@Column(name="security_issue_size")
	private Long securityIssueSize;

	@Id
	@Column(name="security_list_status")
	private String securityListStatus;

	@Id
	@Column(name="security_lo_percent")
	private BigDecimal securityLoPercent;

	@Id
	@Column(name="security_lo_pr_range")
	private BigDecimal securityLoPrRange;

	@Id
	@Column(name="security_lot_size")
	private Integer securityLotSize;

	@Id
	@Column(name="security_remarks")
	private String securityRemarks;

	@Id
	@Column(name="security_sname")
	private String securitySname;

	@Id
	@Column(name="series")
	private String series;

	@Id
	@Column(name="symbol")
	private String symbol;

	@Id
	@Column(name="token")
	private String token;

	@Transient
	private Long from;
	
	@Transient
	private Long pageSize;
	
	public Date getIssueIpDate() {
		return this.issueIpDate;
	}

	public void setIssueIpDate(Date issueIpDate) {
		this.issueIpDate = issueIpDate;
	}

	public Date getIssueMatDate() {
		return this.issueMatDate;
	}

	public void setIssueMatDate(Date issueMatDate) {
		this.issueMatDate = issueMatDate;
	}

	public Date getIssueStrtDate() {
		return this.issueStrtDate;
	}

	public void setIssueStrtDate(Date issueStrtDate) {
		this.issueStrtDate = issueStrtDate;
	}

	public Date getSecAdmDt() {
		return this.secAdmDt;
	}

	public void setSecAdmDt(Date secAdmDt) {
		this.secAdmDt = secAdmDt;
	}

	public String getSecAgmPurp() {
		return this.secAgmPurp;
	}

	public void setSecAgmPurp(String secAgmPurp) {
		this.secAgmPurp = secAgmPurp;
	}

	public String getSecAonAllow() {
		return this.secAonAllow;
	}

	public void setSecAonAllow(String secAonAllow) {
		this.secAonAllow = secAonAllow;
	}

	public Date getSecBcEndDt() {
		return this.secBcEndDt;
	}

	public void setSecBcEndDt(Date secBcEndDt) {
		this.secBcEndDt = secBcEndDt;
	}

	public Date getSecBcStrtDt() {
		return this.secBcStrtDt;
	}

	public void setSecBcStrtDt(Date secBcStrtDt) {
		this.secBcStrtDt = secBcStrtDt;
	}

	public String getSecBonPurp() {
		return this.secBonPurp;
	}

	public void setSecBonPurp(String secBonPurp) {
		this.secBonPurp = secBonPurp;
	}

	public String getSecCd() {
		return this.secCd;
	}

	public void setSecCd(String secCd) {
		this.secCd = secCd;
	}

	public String getSecCrRating() {
		return this.secCrRating;
	}

	public void setSecCrRating(String secCrRating) {
		this.secCrRating = secCrRating;
	}

	public Long getSecCtrlId() {
		return this.secCtrlId;
	}

	public void setSecCtrlId(Long secCtrlId) {
		this.secCtrlId = secCtrlId;
	}

	public String getSecCurrency() {
		return this.secCurrency;
	}

	public void setSecCurrency(String secCurrency) {
		this.secCurrency = secCurrency;
	}

	public String getSecDivPurp() {
		return this.secDivPurp;
	}

	public void setSecDivPurp(String secDivPurp) {
		this.secDivPurp = secDivPurp;
	}

	public String getSecEgmPurp() {
		return this.secEgmPurp;
	}

	public void setSecEgmPurp(String secEgmPurp) {
		this.secEgmPurp = secEgmPurp;
	}

	public Date getSecExDt() {
		return this.secExDt;
	}

	public void setSecExDt(Date secExDt) {
		this.secExDt = secExDt;
	}

	public Date getSecExplDt() {
		return this.secExplDt;
	}

	public void setSecExplDt(Date secExplDt) {
		this.secExplDt = secExplDt;
	}

	public BigDecimal getSecFreezePct() {
		return this.secFreezePct;
	}

	public void setSecFreezePct(BigDecimal secFreezePct) {
		this.secFreezePct = secFreezePct;
	}

	public String getSecId() {
		return this.secId;
	}

	public void setSecId(String secId) {
		this.secId = secId;
	}

	public String getSecIntPurp() {
		return this.secIntPurp;
	}

	public void setSecIntPurp(String secIntPurp) {
		this.secIntPurp = secIntPurp;
	}

	public String getSecMfAllow() {
		return this.secMfAllow;
	}

	public void setSecMfAllow(String secMfAllow) {
		this.secMfAllow = secMfAllow;
	}

	public Date getSecNdEndDt() {
		return this.secNdEndDt;
	}

	public void setSecNdEndDt(Date secNdEndDt) {
		this.secNdEndDt = secNdEndDt;
	}

	public Date getSecNdStrtDt() {
		return this.secNdStrtDt;
	}

	public void setSecNdStrtDt(Date secNdStrtDt) {
		this.secNdStrtDt = secNdStrtDt;
	}

	public Date getSecOpenDt() {
		return this.secOpenDt;
	}

	public void setSecOpenDt(Date secOpenDt) {
		this.secOpenDt = secOpenDt;
	}

	public String getSecOthPurp() {
		return this.secOthPurp;
	}

	public void setSecOthPurp(String secOthPurp) {
		this.secOthPurp = secOthPurp;
	}

	public String getSecPartInd() {
		return this.secPartInd;
	}

	public void setSecPartInd(String secPartInd) {
		this.secPartInd = secPartInd;
	}

	public BigDecimal getSecPr() {
		return this.secPr;
	}

	public void setSecPr(BigDecimal secPr) {
		this.secPr = secPr;
	}

	public Date getSecReadmDt() {
		return this.secReadmDt;
	}

	public void setSecReadmDt(Date secReadmDt) {
		this.secReadmDt = secReadmDt;
	}

	public Date getSecRecDt() {
		return this.secRecDt;
	}

	public void setSecRecDt(Date secRecDt) {
		this.secRecDt = secRecDt;
	}

	public String getSecRhtPurp() {
		return this.secRhtPurp;
	}

	public void setSecRhtPurp(String secRhtPurp) {
		this.secRhtPurp = secRhtPurp;
	}

	public BigDecimal getSecTicSize() {
		return this.secTicSize;
	}

	public void setSecTicSize(BigDecimal secTicSize) {
		this.secTicSize = secTicSize;
	}

	public String getSecType() {
		return this.secType;
	}

	public void setSecType(String secType) {
		this.secType = secType;
	}

	public Timestamp getSecUpdDtTr() {
		return this.secUpdDtTr;
	}

	public void setSecUpdDtTr(Timestamp secUpdDtTr) {
		this.secUpdDtTr = secUpdDtTr;
	}

	public BigDecimal getSecWarnPct() {
		return this.secWarnPct;
	}

	public void setSecWarnPct(BigDecimal secWarnPct) {
		this.secWarnPct = secWarnPct;
	}

	public BigDecimal getSecurityBasePrice() {
		return this.securityBasePrice;
	}

	public void setSecurityBasePrice(BigDecimal securityBasePrice) {
		this.securityBasePrice = securityBasePrice;
	}

	public BigDecimal getSecurityFaceValue() {
		return this.securityFaceValue;
	}

	public void setSecurityFaceValue(BigDecimal securityFaceValue) {
		this.securityFaceValue = securityFaceValue;
	}

	public BigDecimal getSecurityHiPercent() {
		return this.securityHiPercent;
	}

	public void setSecurityHiPercent(BigDecimal securityHiPercent) {
		this.securityHiPercent = securityHiPercent;
	}

	public BigDecimal getSecurityHiPrRange() {
		return this.securityHiPrRange;
	}

	public void setSecurityHiPrRange(BigDecimal securityHiPrRange) {
		this.securityHiPrRange = securityHiPrRange;
	}

	public BigDecimal getSecurityIntRate() {
		return this.securityIntRate;
	}

	public void setSecurityIntRate(BigDecimal securityIntRate) {
		this.securityIntRate = securityIntRate;
	}

	public String getSecurityIntlCode() {
		return this.securityIntlCode;
	}

	public void setSecurityIntlCode(String securityIntlCode) {
		this.securityIntlCode = securityIntlCode;
	}

	public Long getSecurityIssueSize() {
		return this.securityIssueSize;
	}

	public void setSecurityIssueSize(Long securityIssueSize) {
		this.securityIssueSize = securityIssueSize;
	}

	public String getSecurityListStatus() {
		return this.securityListStatus;
	}

	public void setSecurityListStatus(String securityListStatus) {
		this.securityListStatus = securityListStatus;
	}

	public BigDecimal getSecurityLoPercent() {
		return this.securityLoPercent;
	}

	public void setSecurityLoPercent(BigDecimal securityLoPercent) {
		this.securityLoPercent = securityLoPercent;
	}

	public BigDecimal getSecurityLoPrRange() {
		return this.securityLoPrRange;
	}

	public void setSecurityLoPrRange(BigDecimal securityLoPrRange) {
		this.securityLoPrRange = securityLoPrRange;
	}

	public Integer getSecurityLotSize() {
		return this.securityLotSize;
	}

	public void setSecurityLotSize(Integer securityLotSize) {
		this.securityLotSize = securityLotSize;
	}

	public String getSecurityRemarks() {
		return this.securityRemarks;
	}

	public void setSecurityRemarks(String securityRemarks) {
		this.securityRemarks = securityRemarks;
	}

	public String getSecuritySname() {
		return this.securitySname;
	}

	public void setSecuritySname(String securitySname) {
		this.securitySname = securitySname;
	}

	public String getSeries() {
		return this.series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public String getSymbol() {
		return this.symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getToken() {
		return this.token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
	public Long getFrom() {
		return from;
	}
	public void setFrom(Long from) {
		this.from = from;
	}
	public Long getPageSize() {
		return pageSize;
	}
	public void setPageSize(Long pageSize) {
		this.pageSize = pageSize;
	}
	
	@Override
	public String toString() {
		return "SCmSecurityMasterVO [issueIpDate=" + issueIpDate + ", issueMatDate=" + issueMatDate + ", issueStrtDate="
				+ issueStrtDate + ", secAdmDt=" + secAdmDt + ", secAgmPurp=" + secAgmPurp + ", secAonAllow="
				+ secAonAllow + ", secBcEndDt=" + secBcEndDt + ", secBcStrtDt=" + secBcStrtDt + ", secBonPurp="
				+ secBonPurp + ", secCd=" + secCd + ", secCrRating=" + secCrRating + ", secCtrlId=" + secCtrlId
				+ ", secCurrency=" + secCurrency + ", secDivPurp=" + secDivPurp + ", secEgmPurp=" + secEgmPurp
				+ ", secExDt=" + secExDt + ", secExplDt=" + secExplDt + ", secFreezePct=" + secFreezePct + ", secId="
				+ secId + ", secIntPurp=" + secIntPurp + ", secMfAllow=" + secMfAllow + ", secNdEndDt=" + secNdEndDt
				+ ", secNdStrtDt=" + secNdStrtDt + ", secOpenDt=" + secOpenDt + ", secOthPurp=" + secOthPurp
				+ ", secPartInd=" + secPartInd + ", secPr=" + secPr + ", secReadmDt=" + secReadmDt + ", secRecDt="
				+ secRecDt + ", secRhtPurp=" + secRhtPurp + ", secTicSize=" + secTicSize + ", secType=" + secType
				+ ", secUpdDtTr=" + secUpdDtTr + ", secWarnPct=" + secWarnPct + ", securityBasePrice="
				+ securityBasePrice + ", securityFaceValue=" + securityFaceValue + ", securityHiPercent="
				+ securityHiPercent + ", securityHiPrRange=" + securityHiPrRange + ", securityIntRate="
				+ securityIntRate + ", securityIntlCode=" + securityIntlCode + ", securityIssueSize="
				+ securityIssueSize + ", securityListStatus=" + securityListStatus + ", securityLoPercent="
				+ securityLoPercent + ", securityLoPrRange=" + securityLoPrRange + ", securityLotSize="
				+ securityLotSize + ", securityRemarks=" + securityRemarks + ", securitySname=" + securitySname
				+ ", series=" + series + ", symbol=" + symbol + ", token=" + token + "]";
	}
}