package com.surv.entity.marketreplay;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;

import com.surv.constant.ValidationMessage;
import com.surv.constraints.annotations.CheckThresholdDataValidation;
@CheckThresholdDataValidation
@Entity
@Table(name="ALERT_RULE_THRESHOLD_DETAILS")
public class AlertRuleThresholdDetailVO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="THRSH_RULE_NO")
	private Long thrshRuleNo;

	@Id
	@Column(name="THRSH_THRESHOLD_NUM")
	private String thrshThresholdNum;
	
	@Column(name="THRSH_THRESHOLD_DESC")
	private String thrshThresholdDesc;
	
	@Column(name="THRSH_CURRENT_VALUE")
	private String thrshCurrentValue;
	
	@Column(name="THRSH_NEW_VALUE")
	@Pattern(regexp = "^[0-9]*\\.?[0-9]+$", message = ValidationMessage.ERROR_INVALID_NEW_VALUE)
	private String thrshNewValue;

	@Column(name="THRSH_EFF_DATE")
	private Date thrshEffDate;

	@Column(name="THRSH_CRT_BY")
	private String thrshCrtBy;
	
	@Column(name="THRSH_CRT_DATE")
	private Date thrshCrtDate;
	
	@Column(name="THRSH_THRESH_UPDT_BY")
	private String thrshThreshUpdtBy;
	
	@Column(name="THRESH_UPDT_DATE")
	private Date threshUpdtDate;
	
	@Transient
	private String thrshEffDateString;

	public Long getThrshRuleNo() {
		return thrshRuleNo;
	}

	public void setThrshRuleNo(Long thrshRuleNo) {
		this.thrshRuleNo = thrshRuleNo;
	}

	public String getThrshThresholdNum() {
		return thrshThresholdNum;
	}

	public void setThrshThresholdNum(String thrshThresholdNum) {
		this.thrshThresholdNum = thrshThresholdNum;
	}

	public String getThrshThresholdDesc() {
		return thrshThresholdDesc;
	}

	public void setThrshThresholdDesc(String thrshThresholdDesc) {
		this.thrshThresholdDesc = thrshThresholdDesc;
	}

	public String getThrshCurrentValue() {
		return thrshCurrentValue;
	}

	public void setThrshCurrentValue(String thrshCurrentValue) {
		this.thrshCurrentValue = thrshCurrentValue;
	}

	public String getThrshNewValue() {
		return thrshNewValue;
	}

	public void setThrshNewValue(String thrshNewValue) {
		this.thrshNewValue = thrshNewValue;
	}

	public Date getThrshEffDate() {
		return thrshEffDate;
	}

	public void setThrshEffDate(Date thrshEffDate) {
		this.thrshEffDate = thrshEffDate;
	}

	public String getThrshCrtBy() {
		return thrshCrtBy;
	}

	public void setThrshCrtBy(String thrshCrtBy) {
		this.thrshCrtBy = thrshCrtBy;
	}

	public Date getThrshCrtDate() {
		return thrshCrtDate;
	}

	public void setThrshCrtDate(Date thrshCrtDate) {
		this.thrshCrtDate = thrshCrtDate;
	}

	public String getThrshThreshUpdtBy() {
		return thrshThreshUpdtBy;
	}

	public void setThrshThreshUpdtBy(String thrshThreshUpdtBy) {
		this.thrshThreshUpdtBy = thrshThreshUpdtBy;
	}

	public Date getThreshUpdtDate() {
		return threshUpdtDate;
	}

	public void setThreshUpdtDate(Date threshUpdtDate) {
		this.threshUpdtDate = threshUpdtDate;
	}
	
	public String getThrshEffDateString() {
		return thrshEffDateString;
	}

	public void setThrshEffDateString(String thrshEffDateString) {
		this.thrshEffDateString = thrshEffDateString;
	}

	@Override
	public String toString() {
		return "AlertRuleThresholdDetailVO [thrshRuleNo=" + thrshRuleNo + ", thrshThresholdNum=" + thrshThresholdNum
				+ ", thrshThresholdDesc=" + thrshThresholdDesc + ", thrshCurrentValue=" + thrshCurrentValue
				+ ", thrshNewValue=" + thrshNewValue + ", thrshEffDate=" + thrshEffDate + ", thrshCrtBy=" + thrshCrtBy
				+ ", thrshCrtDate=" + thrshCrtDate + ", thrshThreshUpdtBy=" + thrshThreshUpdtBy + ", threshUpdtDate="
				+ threshUpdtDate + "]";
	}
	
}