package com.surv.entity.marketreplay;

import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.nse.ngs.domain.mr.PricePoint;
import com.surv.cache.CacheManager;
import com.surv.constant.StaticConstants;
import com.surv.exception.ValidationException;
import com.surv.utility.Util;

public class MarketReplayVO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * Activity Grid
	 */
	private Integer mrSeqNmbr;
	private String mrSymbol;
	private String mrSeries;
	private String mrRcrdIndctr;
	private String mrBuySellFlag;
	private Integer mrActivityType;
	private String mrFillNmbr;
	private Integer mrFillQty;
	private Double mrFillPrice;
	private Double mrFillAmnt;
	private Long mrJiffyTmst;
	private String mrLiquidityFlag;
	private String mrFirstTradeAfterFlex;
	private Date mrRecordTime;
	private String mrRecordTimeString;
	private String mrMktType;
	private Double mrBuyOrderNmbr;
	private String mrBuyBrokerId;
	private String mrBuyClientId;
	private Integer mrBuyProClientFlag;
	private Integer mrBuyDealerId;
	private Long mrBuyNnfId;
	private String mrBuyCpCode;
	private Integer mrBuyOrderQty;
	private Integer mrBuyRmngQty;
	private Integer mrBuyDisclQty;
	private Integer mrBuyRmngDisclQty;
	private Double mrBuyLimitPrice;
	private Double mrBuyTriggerPrice;
	private Date mrBuyEntryTmst;
	private String mrBuyEntryTmstString;
	private Date mrBuyLastModTmst;
	private String mrBuyLastModTmstString;
	private Integer mrBuyBookType;
	private String mrBuyMktFlag;
	private String mrBuyOnStopFlag;
	private String mrBuyDayFlag;
	private String mrBuyFokFlag;
	private String mrBuyTtpFlag;
	private String mrBuyStpFlag;
	private String mrBuyStpClxFlag;
	private String mrBuyAlgoInd;
	private String mrBuyPan;
	private Integer mrBuyAlgoId;
	private Integer mrBuyAlgoCategory;
	private String mrBuyAtoFlag;
	private String mrBuyColoFlag;
	private Double mrSellOrderNmbr;
	private String mrSellBrokerId;
	private String mrSellClientId;
	private Integer mrSellProClientFlag;
	private Integer mrSellDealerId;
	private Long mrSellNnfId;
	private String mrSellCpCode;
	private Integer mrSellOrderQty;
	private Integer mrSellRmngQty;
	private Integer mrSellDisclQty;
	private Integer mrSellRmngDisclQty;
	private Double mrSellLimitPrice;
	private Double mrSellTriggerPrice;
	private Date mrSellEntryTmst;
	private String mrSellEntryTmstString;
	private Date mrSellLastModTmst;
	private String mrSellLastModTmstString;
	private Integer mrSellBookType;
	private String mrSellMktFlag;
	private String mrSellOnStopFlag;
	private String mrSellDayFlag;
	private String mrSellFokFlag;
	private String mrSellTtpFlag;
	private String mrSellStpFlag;
	private String mrSellStpClxFlag;
	private String mrSellAlgoInd;
	private String mrSellPan;
	private Integer mrSellAlgoId;
	private Integer mrSellAlgoCategory;
	private String mrSellAtoFlag;
	private String mrSellColoFlag;
	private String mrIndexVal;
	private String mrDayBuyPendingQty;
	private String mrDaySellPendingQty;
	private String mrTradeDevLtp;
	private Double mrLastTradePrice;
	private Double mrTradePrice;

	/**
	 * Trade Log Data
	 */
	private String mrtradeLogData;

	/**
	 * Buy Order Grid
	 */
	private List<BuyOrderVO> mdBuyPricePointArray;

	/**
	 * Sell Order Grid
	 */
	private List<SellOrderVO> mdSellPricePointArray;

	/**
	 * Away LTP Grid
	 */
	private AwayLtpVO mdAwayLtpData;

	/**
	 * Event Grid
	 */
	private EventVO mdEventData;

	/**
	 * Getter & Setter... 
	 */
	public Integer getMrSeqNmbr() {
		return mrSeqNmbr;
	}

	public void setMrSeqNmbr(Integer mrSeqNmbr) {
		this.mrSeqNmbr = mrSeqNmbr;
	}

	public String getMrSymbol() {
		return mrSymbol;
	}

	public void setMrSymbol(String mrSymbol) {
		this.mrSymbol = mrSymbol;
	}

	public String getMrSeries() {
		return mrSeries;
	}

	public void setMrSeries(String mrSeries) {
		this.mrSeries = mrSeries;
	}

	public String getMrRcrdIndctr() {
		return mrRcrdIndctr;
	}

	public void setMrRcrdIndctr(String mrRcrdIndctr) {
		this.mrRcrdIndctr = mrRcrdIndctr;
	}

	public String getMrBuySellFlag() {
		return mrBuySellFlag;
	}

	public void setMrBuySellFlag(String mrBuySellFlag) {
		this.mrBuySellFlag = mrBuySellFlag;
	}

	public Integer getMrActivityType() {
		return mrActivityType;
	}

	public void setMrActivityType(Integer mrActivityType) {
		this.mrActivityType = mrActivityType;
	}

	public String getMrFillNmbr() {
		return mrFillNmbr;
	}

	public void setMrFillNmbr(String mrFillNmbr) {
		this.mrFillNmbr = mrFillNmbr;
	}

	public Integer getMrFillQty() {
		return mrFillQty;
	}

	public void setMrFillQty(Integer mrFillQty) {
		this.mrFillQty = mrFillQty;
	}

	public Double getMrFillPrice() {
		return mrFillPrice;
	}

	public void setMrFillPrice(Double mrFillPrice) {
		this.mrFillPrice = mrFillPrice;
	}

	public Double getMrFillAmnt() {
		return mrFillAmnt;
	}

	public void setMrFillAmnt(Double mrFillAmnt) {
		this.mrFillAmnt = mrFillAmnt;
	}

	public Long getMrJiffyTmst() {
		return mrJiffyTmst;
	}

	public void setMrJiffyTmst(Long mrJiffyTmst) {
		this.mrJiffyTmst = mrJiffyTmst;
	}

	public String getMrLiquidityFlag() {
		return mrLiquidityFlag;
	}

	public void setMrLiquidityFlag(String mrLiquidityFlag) {
		this.mrLiquidityFlag = mrLiquidityFlag;
	}

	public String getMrFirstTradeAfterFlex() {
		return mrFirstTradeAfterFlex;
	}

	public void setMrFirstTradeAfterFlex(String mrFirstTradeAfterFlex) {
		this.mrFirstTradeAfterFlex = mrFirstTradeAfterFlex;
	}

	public Date getMrRecordTime() {
		return mrRecordTime;
	}

	public void setMrRecordTime(Date mrRecordTime) {
		this.mrRecordTime = mrRecordTime;
	}

	public String getMrRecordTimeString() {
		return Util.getDateTimeString(this.mrRecordTime);
	}

	public void setMrRecordTimeString(String mrRecordTimeString) {
		this.mrRecordTimeString = mrRecordTimeString;
	}

	public String getMrMktType() {
		return mrMktType;
	}

	public void setMrMktType(String mrMktType) {
		this.mrMktType = mrMktType;
	}

	public Double getMrBuyOrderNmbr() {
		return mrBuyOrderNmbr;
	}

	public void setMrBuyOrderNmbr(Double mrBuyOrderNmbr) {
		this.mrBuyOrderNmbr = mrBuyOrderNmbr;
	}

	public String getMrBuyBrokerId() {
		return mrBuyBrokerId;
	}

	public void setMrBuyBrokerId(String mrBuyBrokerId) {
		this.mrBuyBrokerId = mrBuyBrokerId;
	}

	public String getMrBuyClientId() {
		return mrBuyClientId;
	}

	public void setMrBuyClientId(String mrBuyClientId) {
		this.mrBuyClientId = mrBuyClientId;
	}

	public Integer getMrBuyProClientFlag() {
		return mrBuyProClientFlag;
	}

	public void setMrBuyProClientFlag(Integer mrBuyProClientFlag) {
		this.mrBuyProClientFlag = mrBuyProClientFlag;
	}

	public Integer getMrBuyDealerId() {
		return mrBuyDealerId;
	}

	public void setMrBuyDealerId(Integer mrBuyDealerId) {
		this.mrBuyDealerId = mrBuyDealerId;
	}

	public Long getMrBuyNnfId() {
		return mrBuyNnfId;
	}

	public void setMrBuyNnfId(Long mrBuyNnfId) {
		this.mrBuyNnfId = mrBuyNnfId;
	}

	public String getMrBuyCpCode() {
		return mrBuyCpCode;
	}

	public void setMrBuyCpCode(String mrBuyCpCode) {
		this.mrBuyCpCode = mrBuyCpCode;
	}

	public Integer getMrBuyOrderQty() {
		return mrBuyOrderQty;
	}

	public void setMrBuyOrderQty(Integer mrBuyOrderQty) {
		this.mrBuyOrderQty = mrBuyOrderQty;
	}

	public Integer getMrBuyRmngQty() {
		return mrBuyRmngQty;
	}

	public void setMrBuyRmngQty(Integer mrBuyRmngQty) {
		this.mrBuyRmngQty = mrBuyRmngQty;
	}

	public Integer getMrBuyDisclQty() {
		return mrBuyDisclQty;
	}

	public void setMrBuyDisclQty(Integer mrBuyDisclQty) {
		this.mrBuyDisclQty = mrBuyDisclQty;
	}

	public Integer getMrBuyRmngDisclQty() {
		return mrBuyRmngDisclQty;
	}

	public void setMrBuyRmngDisclQty(Integer mrBuyRmngDisclQty) {
		this.mrBuyRmngDisclQty = mrBuyRmngDisclQty;
	}

	public Double getMrBuyLimitPrice() {
		return mrBuyLimitPrice;
	}

	public void setMrBuyLimitPrice(Double mrBuyLimitPrice) {
		this.mrBuyLimitPrice = mrBuyLimitPrice;
	}

	public Double getMrBuyTriggerPrice() {
		return mrBuyTriggerPrice;
	}

	public void setMrBuyTriggerPrice(Double mrBuyTriggerPrice) {
		this.mrBuyTriggerPrice = mrBuyTriggerPrice;
	}

	public Date getMrBuyEntryTmst() {
		return mrBuyEntryTmst;
	}

	public void setMrBuyEntryTmst(Date mrBuyEntryTmst) {
		this.mrBuyEntryTmst = mrBuyEntryTmst;
	}

	public String getMrBuyEntryTmstString() {
		return Util.getDateTimeString(this.mrBuyEntryTmst);
	}

	public void setMrBuyEntryTmstString(String mrBuyEntryTmstString) {
		this.mrBuyEntryTmstString = mrBuyEntryTmstString;
	}

	public Date getMrBuyLastModTmst() {
		return mrBuyLastModTmst;
	}

	public void setMrBuyLastModTmst(Date mrBuyLastModTmst) {
		this.mrBuyLastModTmst = mrBuyLastModTmst;
	}

	public String getMrBuyLastModTmstString() {
		return Util.getDateTimeString(this.mrBuyLastModTmst);
	}

	public void setMrBuyLastModTmstString(String mrBuyLastModTmstString) {
		this.mrBuyLastModTmstString = mrBuyLastModTmstString;
	}

	public Integer getMrBuyBookType() {
		return mrBuyBookType;
	}

	public void setMrBuyBookType(Integer mrBuyBookType) {
		this.mrBuyBookType = mrBuyBookType;
	}

	public String getMrBuyMktFlag() {
		return mrBuyMktFlag;
	}

	public void setMrBuyMktFlag(String mrBuyMktFlag) {
		this.mrBuyMktFlag = mrBuyMktFlag;
	}

	public String getMrBuyOnStopFlag() {
		return mrBuyOnStopFlag;
	}

	public void setMrBuyOnStopFlag(String mrBuyOnStopFlag) {
		this.mrBuyOnStopFlag = mrBuyOnStopFlag;
	}

	public String getMrBuyDayFlag() {
		return mrBuyDayFlag;
	}

	public void setMrBuyDayFlag(String mrBuyDayFlag) {
		this.mrBuyDayFlag = mrBuyDayFlag;
	}

	public String getMrBuyFokFlag() {
		return mrBuyFokFlag;
	}

	public void setMrBuyFokFlag(String mrBuyFokFlag) {
		this.mrBuyFokFlag = mrBuyFokFlag;
	}

	public String getMrBuyTtpFlag() {
		return mrBuyTtpFlag;
	}

	public void setMrBuyTtpFlag(String mrBuyTtpFlag) {
		this.mrBuyTtpFlag = mrBuyTtpFlag;
	}

	public String getMrBuyStpFlag() {
		return mrBuyStpFlag;
	}

	public void setMrBuyStpFlag(String mrBuyStpFlag) {
		this.mrBuyStpFlag = mrBuyStpFlag;
	}

	public String getMrBuyStpClxFlag() {
		return mrBuyStpClxFlag;
	}

	public void setMrBuyStpClxFlag(String mrBuyStpClxFlag) {
		this.mrBuyStpClxFlag = mrBuyStpClxFlag;
	}

	public String getMrBuyAlgoInd() {
		return mrBuyAlgoInd;
	}

	public void setMrBuyAlgoInd(String mrBuyAlgoInd) {
		this.mrBuyAlgoInd = mrBuyAlgoInd;
	}

	public String getMrBuyPan() {
		return mrBuyPan;
	}

	public void setMrBuyPan(String mrBuyPan) {
		this.mrBuyPan = mrBuyPan;
	}

	public Integer getMrBuyAlgoId() {
		return mrBuyAlgoId;
	}

	public void setMrBuyAlgoId(Integer mrBuyAlgoId) {
		this.mrBuyAlgoId = mrBuyAlgoId;
	}

	public Integer getMrBuyAlgoCategory() {
		return mrBuyAlgoCategory;
	}

	public void setMrBuyAlgoCategory(Integer mrBuyAlgoCategory) {
		this.mrBuyAlgoCategory = mrBuyAlgoCategory;
	}

	public String getMrBuyAtoFlag() {
		return mrBuyAtoFlag;
	}

	public void setMrBuyAtoFlag(String mrBuyAtoFlag) {
		this.mrBuyAtoFlag = mrBuyAtoFlag;
	}

	public String getMrBuyColoFlag() {
		return mrBuyColoFlag;
	}

	public void setMrBuyColoFlag(String mrBuyColoFlag) {
		this.mrBuyColoFlag = mrBuyColoFlag;
	}

	public Double getMrSellOrderNmbr() {
		return mrSellOrderNmbr;
	}

	public void setMrSellOrderNmbr(Double mrSellOrderNmbr) {
		this.mrSellOrderNmbr = mrSellOrderNmbr;
	}

	public String getMrSellBrokerId() {
		return mrSellBrokerId;
	}

	public void setMrSellBrokerId(String mrSellBrokerId) {
		this.mrSellBrokerId = mrSellBrokerId;
	}

	public String getMrSellClientId() {
		return mrSellClientId;
	}

	public void setMrSellClientId(String mrSellClientId) {
		this.mrSellClientId = mrSellClientId;
	}

	public Integer getMrSellProClientFlag() {
		return mrSellProClientFlag;
	}

	public void setMrSellProClientFlag(Integer mrSellProClientFlag) {
		this.mrSellProClientFlag = mrSellProClientFlag;
	}

	public Integer getMrSellDealerId() {
		return mrSellDealerId;
	}

	public void setMrSellDealerId(Integer mrSellDealerId) {
		this.mrSellDealerId = mrSellDealerId;
	}

	public Long getMrSellNnfId() {
		return mrSellNnfId;
	}

	public void setMrSellNnfId(Long mrSellNnfId) {
		this.mrSellNnfId = mrSellNnfId;
	}

	public String getMrSellCpCode() {
		return mrSellCpCode;
	}

	public void setMrSellCpCode(String mrSellCpCode) {
		this.mrSellCpCode = mrSellCpCode;
	}

	public Integer getMrSellOrderQty() {
		return mrSellOrderQty;
	}

	public void setMrSellOrderQty(Integer mrSellOrderQty) {
		this.mrSellOrderQty = mrSellOrderQty;
	}

	public Integer getMrSellRmngQty() {
		return mrSellRmngQty;
	}

	public void setMrSellRmngQty(Integer mrSellRmngQty) {
		this.mrSellRmngQty = mrSellRmngQty;
	}

	public Integer getMrSellDisclQty() {
		return mrSellDisclQty;
	}

	public void setMrSellDisclQty(Integer mrSellDisclQty) {
		this.mrSellDisclQty = mrSellDisclQty;
	}

	public Integer getMrSellRmngDisclQty() {
		return mrSellRmngDisclQty;
	}

	public void setMrSellRmngDisclQty(Integer mrSellRmngDisclQty) {
		this.mrSellRmngDisclQty = mrSellRmngDisclQty;
	}

	public Double getMrSellLimitPrice() {
		return mrSellLimitPrice;
	}

	public void setMrSellLimitPrice(Double mrSellLimitPrice) {
		this.mrSellLimitPrice = mrSellLimitPrice;
	}

	public Double getMrSellTriggerPrice() {
		return mrSellTriggerPrice;
	}

	public void setMrSellTriggerPrice(Double mrSellTriggerPrice) {
		this.mrSellTriggerPrice = mrSellTriggerPrice;
	}

	public Date getMrSellEntryTmst() {
		return mrSellEntryTmst;
	}

	public void setMrSellEntryTmst(Date mrSellEntryTmst) {
		this.mrSellEntryTmst = mrSellEntryTmst;
	}

	public String getMrSellEntryTmstString() {
		return Util.getDateTimeString(this.mrSellEntryTmst);
	}

	public void setMrSellEntryTmstString(String mrSellEntryTmstString) {
		this.mrSellEntryTmstString = mrSellEntryTmstString;
	}

	public Date getMrSellLastModTmst() {
		return mrSellLastModTmst;
	}

	public void setMrSellLastModTmst(Date mrSellLastModTmst) {
		this.mrSellLastModTmst = mrSellLastModTmst;
	}

	public String getMrSellLastModTmstString() {
		return Util.getDateTimeString(this.mrSellLastModTmst);
	}

	public void setMrSellLastModTmstString(String mrSellLastModTmstString) {
		this.mrSellLastModTmstString = mrSellLastModTmstString;
	}

	public Integer getMrSellBookType() {
		return mrSellBookType;
	}

	public void setMrSellBookType(Integer mrSellBookType) {
		this.mrSellBookType = mrSellBookType;
	}

	public String getMrSellMktFlag() {
		return mrSellMktFlag;
	}

	public void setMrSellMktFlag(String mrSellMktFlag) {
		this.mrSellMktFlag = mrSellMktFlag;
	}

	public String getMrSellOnStopFlag() {
		return mrSellOnStopFlag;
	}

	public void setMrSellOnStopFlag(String mrSellOnStopFlag) {
		this.mrSellOnStopFlag = mrSellOnStopFlag;
	}

	public String getMrSellDayFlag() {
		return mrSellDayFlag;
	}

	public void setMrSellDayFlag(String mrSellDayFlag) {
		this.mrSellDayFlag = mrSellDayFlag;
	}

	public String getMrSellFokFlag() {
		return mrSellFokFlag;
	}

	public void setMrSellFokFlag(String mrSellFokFlag) {
		this.mrSellFokFlag = mrSellFokFlag;
	}

	public String getMrSellTtpFlag() {
		return mrSellTtpFlag;
	}

	public void setMrSellTtpFlag(String mrSellTtpFlag) {
		this.mrSellTtpFlag = mrSellTtpFlag;
	}

	public String getMrSellStpFlag() {
		return mrSellStpFlag;
	}

	public void setMrSellStpFlag(String mrSellStpFlag) {
		this.mrSellStpFlag = mrSellStpFlag;
	}

	public String getMrSellStpClxFlag() {
		return mrSellStpClxFlag;
	}

	public void setMrSellStpClxFlag(String mrSellStpClxFlag) {
		this.mrSellStpClxFlag = mrSellStpClxFlag;
	}

	public String getMrSellAlgoInd() {
		return mrSellAlgoInd;
	}

	public void setMrSellAlgoInd(String mrSellAlgoInd) {
		this.mrSellAlgoInd = mrSellAlgoInd;
	}

	public String getMrSellPan() {
		return mrSellPan;
	}

	public void setMrSellPan(String mrSellPan) {
		this.mrSellPan = mrSellPan;
	}

	public Integer getMrSellAlgoId() {
		return mrSellAlgoId;
	}

	public void setMrSellAlgoId(Integer mrSellAlgoId) {
		this.mrSellAlgoId = mrSellAlgoId;
	}

	public Integer getMrSellAlgoCategory() {
		return mrSellAlgoCategory;
	}

	public void setMrSellAlgoCategory(Integer mrSellAlgoCategory) {
		this.mrSellAlgoCategory = mrSellAlgoCategory;
	}

	public String getMrSellAtoFlag() {
		return mrSellAtoFlag;
	}

	public void setMrSellAtoFlag(String mrSellAtoFlag) {
		this.mrSellAtoFlag = mrSellAtoFlag;
	}

	public String getMrSellColoFlag() {
		return mrSellColoFlag;
	}

	public void setMrSellColoFlag(String mrSellColoFlag) {
		this.mrSellColoFlag = mrSellColoFlag;
	}

	public String getMrIndexVal() {
		return mrIndexVal;
	}

	public void setMrIndexVal(String mrIndexVal) {
		this.mrIndexVal = mrIndexVal;
	}

	public Double getMrTradePrice() {
		return mrTradePrice;
	}

	public void setMrTradePrice(Double mrTradePrice) {
		this.mrTradePrice = mrTradePrice;
	}

	public String getMrDayBuyPendingQty() {
		return mrDayBuyPendingQty;
	}

	public void setMrDayBuyPendingQty(String mrDayBuyPendingQty) {
		this.mrDayBuyPendingQty = mrDayBuyPendingQty;
	}

	public String getMrDaySellPendingQty() {
		return mrDaySellPendingQty;
	}

	public void setMrDaySellPendingQty(String mrDaySellPendingQty) {
		this.mrDaySellPendingQty = mrDaySellPendingQty;
	}

	public Double getMrLastTradePrice() {
		return mrLastTradePrice;
	}

	public void setMrLastTradePrice(Double mrLastTradePrice) {
		this.mrLastTradePrice = mrLastTradePrice;
	}

	public String getMrTradeDevLtp() {
		return mrTradeDevLtp;
	}

	public void setMrTradeDevLtp(String mrTradeDevLtp) {
		this.mrTradeDevLtp = mrTradeDevLtp;
	}

	public String getMrtradeLogData() {
		return mrtradeLogData;
	}

	public void setMrtradeLogData(String mrtradeLogData) {
		this.mrtradeLogData = mrtradeLogData;
	}

	public List<BuyOrderVO> getMdBuyPricePointArray() {
		return mdBuyPricePointArray;
	}

	public void setMdBuyPricePointArray(List<BuyOrderVO> mdBuyPricePointArray) {
		this.mdBuyPricePointArray = mdBuyPricePointArray;
	}

	public List<SellOrderVO> getMdSellPricePointArray() {
		return mdSellPricePointArray;
	}

	public void setMdSellPricePointArray(List<SellOrderVO> mdSellPricePointArray) {
		this.mdSellPricePointArray = mdSellPricePointArray;
	}

	public AwayLtpVO getMdAwayLtpData() {
		return mdAwayLtpData;
	}

	public void setMdAwayLtpData(AwayLtpVO mdAwayLtpData) {
		this.mdAwayLtpData = mdAwayLtpData;
	}

	public EventVO getMdEventData() {
		return mdEventData;
	}

	public void setMdEventData(EventVO mdEventData) {
		this.mdEventData = mdEventData;
	}

	@Override
	public String toString() {
		return "MarketReplayVO [mrSeqNmbr=" + mrSeqNmbr + ", mrSymbol=" + mrSymbol + ", mrSeries=" + mrSeries
				+ ", mrRcrdIndctr=" + mrRcrdIndctr + ", mrBuySellFlag=" + mrBuySellFlag + ", mrActivityType="
				+ mrActivityType + ", mrFillNmbr=" + mrFillNmbr + ", mrFillQty=" + mrFillQty + ", mrFillPrice="
				+ mrFillPrice + ", mrFillAmnt=" + mrFillAmnt + ", mrJiffyTmst=" + mrJiffyTmst + ", mrLiquidityFlag="
				+ mrLiquidityFlag + ", mrFirstTradeAfterFlex=" + mrFirstTradeAfterFlex + ", mrRecordTime="
				+ mrRecordTime + ", mrRecordTimeString=" + mrRecordTimeString + ", mrMktType=" + mrMktType
				+ ", mrBuyOrderNmbr=" + mrBuyOrderNmbr + ", mrBuyBrokerId=" + mrBuyBrokerId + ", mrBuyClientId="
				+ mrBuyClientId + ", mrBuyProClientFlag=" + mrBuyProClientFlag + ", mrBuyDealerId=" + mrBuyDealerId
				+ ", mrBuyNnfId=" + mrBuyNnfId + ", mrBuyCpCode=" + mrBuyCpCode + ", mrBuyOrderQty=" + mrBuyOrderQty
				+ ", mrBuyRmngQty=" + mrBuyRmngQty + ", mrBuyDisclQty=" + mrBuyDisclQty + ", mrBuyRmngDisclQty="
				+ mrBuyRmngDisclQty + ", mrBuyLimitPrice=" + mrBuyLimitPrice + ", mrBuyTriggerPrice="
				+ mrBuyTriggerPrice + ", mrBuyEntryTmst=" + mrBuyEntryTmst + ", mrBuyEntryTmstString="
				+ mrBuyEntryTmstString + ", mrBuyLastModTmst=" + mrBuyLastModTmst + ", mrBuyLastModTmstString="
				+ mrBuyLastModTmstString + ", mrBuyBookType=" + mrBuyBookType + ", mrBuyMktFlag=" + mrBuyMktFlag
				+ ", mrBuyOnStopFlag=" + mrBuyOnStopFlag + ", mrBuyDayFlag=" + mrBuyDayFlag + ", mrBuyFokFlag="
				+ mrBuyFokFlag + ", mrBuyTtpFlag=" + mrBuyTtpFlag + ", mrBuyStpFlag=" + mrBuyStpFlag
				+ ", mrBuyStpClxFlag=" + mrBuyStpClxFlag + ", mrBuyAlgoInd=" + mrBuyAlgoInd + ", mrBuyPan=" + mrBuyPan
				+ ", mrBuyAlgoId=" + mrBuyAlgoId + ", mrBuyAlgoCategory=" + mrBuyAlgoCategory + ", mrBuyAtoFlag="
				+ mrBuyAtoFlag + ", mrBuyColoFlag=" + mrBuyColoFlag + ", mrSellOrderNmbr=" + mrSellOrderNmbr
				+ ", mrSellBrokerId=" + mrSellBrokerId + ", mrSellClientId=" + mrSellClientId + ", mrSellProClientFlag="
				+ mrSellProClientFlag + ", mrSellDealerId=" + mrSellDealerId + ", mrSellNnfId=" + mrSellNnfId
				+ ", mrSellCpCode=" + mrSellCpCode + ", mrSellOrderQty=" + mrSellOrderQty + ", mrSellRmngQty="
				+ mrSellRmngQty + ", mrSellDisclQty=" + mrSellDisclQty + ", mrSellRmngDisclQty=" + mrSellRmngDisclQty
				+ ", mrSellLimitPrice=" + mrSellLimitPrice + ", mrSellTriggerPrice=" + mrSellTriggerPrice
				+ ", mrSellEntryTmst=" + mrSellEntryTmst + ", mrSellEntryTmstString=" + mrSellEntryTmstString
				+ ", mrSellLastModTmst=" + mrSellLastModTmst + ", mrSellLastModTmstString=" + mrSellLastModTmstString
				+ ", mrSellBookType=" + mrSellBookType + ", mrSellMktFlag=" + mrSellMktFlag + ", mrSellOnStopFlag="
				+ mrSellOnStopFlag + ", mrSellDayFlag=" + mrSellDayFlag + ", mrSellFokFlag=" + mrSellFokFlag
				+ ", mrSellTtpFlag=" + mrSellTtpFlag + ", mrSellStpFlag=" + mrSellStpFlag + ", mrSellStpClxFlag="
				+ mrSellStpClxFlag + ", mrSellAlgoInd=" + mrSellAlgoInd + ", mrSellPan=" + mrSellPan + ", mrSellAlgoId="
				+ mrSellAlgoId + ", mrSellAlgoCategory=" + mrSellAlgoCategory + ", mrSellAtoFlag=" + mrSellAtoFlag
				+ ", mrSellColoFlag=" + mrSellColoFlag + ", mdBuyPricePointArray=" + mdBuyPricePointArray
				+ ", mdSellPricePointArray=" + mdSellPricePointArray + ", mdAwayLtpData=" + mdAwayLtpData
				+ ", mdEventData=" + mdEventData + "]";
	}

	public MarketReplayVO generateMarketReplayData(Object[] object) throws ValidationException, ParseException {

		/**
		 * Activity Grid
		 */
		this.mrSeqNmbr = Util.getIntegerValue(object, "mrSeqNmbr");
		this.mrRcrdIndctr = Util.getStringValue(object, "mrRcrdIndctr");
		this.mrBuySellFlag = Util.getStringValue(object, "mrBuySellFlag");
		this.mrActivityType = Util.getIntegerValue(object, "mrActivityType");
		this.mrFillNmbr = Util.getStringValue(object, "mrFillNmbr");
		this.mrFillQty = Util.getIntegerValue(object, "mrFillQty");
		this.mrFillPrice = Util.getDoubleValue(object, "mrFillPrice");
		this.mrFillAmnt = Util.getDoubleValue(object, "mrFillAmnt");
		this.mrJiffyTmst = Util.getLongValue(object, "mrJiffyTmst");
		this.mrLiquidityFlag = Util.getStringValue(object, "mrLiquidityFlag");
		this.mrFirstTradeAfterFlex = Util.getStringValue(object, "mrFirstTradeAfterFlex");
		this.mrRecordTime = Util.getDateValue(object, "mrRecordTime");
		this.mrMktType = Util.getStringValue(object, "mrMktType");
		this.mrBuyOrderNmbr = Util.getDoubleValue(object, "mrBuyOrderNmbr");
		this.mrBuyBrokerId = Util.getStringValue(object, "mrBuyBrokerId");
		this.mrBuyClientId = Util.getStringValue(object, "mrBuyClientId");
		this.mrBuyProClientFlag = Util.getIntegerValue(object, "mrBuyProClientFlag");
		this.mrBuyDealerId = Util.getIntegerValue(object, "mrBuyDealerId");
		this.mrBuyNnfId = Util.getLongValue(object, "mrBuyNnfId");
		this.mrBuyCpCode = Util.getStringValue(object, "mrBuyCpCode");
		this.mrBuyOrderQty = Util.getIntegerValue(object, "mrBuyOrderQty");
		this.mrBuyRmngQty = Util.getIntegerValue(object, "mrBuyRmngQty");
		this.mrBuyDisclQty = Util.getIntegerValue(object, "mrBuyDisclQty");
		this.mrBuyRmngDisclQty = Util.getIntegerValue(object, "mrBuyRmngDisclQty");
		this.mrBuyLimitPrice = Util.getDoubleValue(object, "mrBuyLimitPrice");
		this.mrBuyTriggerPrice = Util.getDoubleValue(object, "mrBuyTriggerPrice");
		this.mrBuyEntryTmst = Util.getDateValue(object, "mrBuyEntryTmst");
		this.mrBuyLastModTmst = Util.getDateValue(object, "mrBuyLastModTmst");
		this.mrBuyBookType = Util.getIntegerValue(object, "mrBuyBookType");
		this.mrBuyMktFlag = Util.getStringValue(object, "mrBuyMktFlag");
		this.mrBuyOnStopFlag = Util.getStringValue(object, "mrBuyOnStopFlag");
		this.mrBuyDayFlag = Util.getStringValue(object, "mrBuyDayFlag");
		this.mrBuyFokFlag = Util.getStringValue(object, "mrBuyFokFlag");
		this.mrBuyTtpFlag = Util.getStringValue(object, "mrBuyTtpFlag");
		this.mrBuyStpFlag = Util.getStringValue(object, "mrBuyStpFlag");
		this.mrBuyStpClxFlag = Util.getStringValue(object, "mrBuyStpClxFlag");
		this.mrBuyAlgoInd = Util.getStringValue(object, "mrBuyAlgoInd");
		this.mrBuyPan = Util.getStringValue(object, "mrBuyPan");
		this.mrBuyAlgoId = Util.getIntegerValue(object, "mrBuyAlgoId");
		this.mrBuyAlgoCategory = Util.getIntegerValue(object, "mrBuyAlgoCategory");
		this.mrBuyAtoFlag = Util.getStringValue(object, "mrBuyAtoFlag");
		this.mrBuyColoFlag = Util.getStringValue(object, "mrBuyColoFlag");
		this.mrSellOrderNmbr = Util.getDoubleValue(object, "mrSellOrderNmbr");
		this.mrSellBrokerId = Util.getStringValue(object, "mrSellBrokerId");
		this.mrSellClientId = Util.getStringValue(object, "mrSellClientId");
		this.mrSellProClientFlag = Util.getIntegerValue(object, "mrSellProClientFlag");
		this.mrSellDealerId = Util.getIntegerValue(object, "mrSellDealerId");
		this.mrSellNnfId = Util.getLongValue(object, "mrSellNnfId");
		this.mrSellCpCode = Util.getStringValue(object, "mrSellCpCode");
		this.mrSellOrderQty = Util.getIntegerValue(object, "mrSellOrderQty");
		this.mrSellRmngQty = Util.getIntegerValue(object, "mrSellRmngQty");
		this.mrSellDisclQty = Util.getIntegerValue(object, "mrSellDisclQty");
		this.mrSellRmngDisclQty = Util.getIntegerValue(object, "mrSellRmngDisclQty");
		this.mrSellLimitPrice = Util.getDoubleValue(object, "mrSellLimitPrice");
		this.mrSellTriggerPrice = Util.getDoubleValue(object, "mrSellTriggerPrice");
		this.mrSellEntryTmst = Util.getDateValue(object, "mrSellEntryTmst");
		this.mrSellLastModTmst = Util.getDateValue(object, "mrSellLastModTmst");
		this.mrSellBookType = Util.getIntegerValue(object, "mrSellBookType");
		this.mrSellMktFlag = Util.getStringValue(object, "mrSellMktFlag");
		this.mrSellOnStopFlag = Util.getStringValue(object, "mrSellOnStopFlag");
		this.mrSellDayFlag = Util.getStringValue(object, "mrSellDayFlag");
		this.mrSellFokFlag = Util.getStringValue(object, "mrSellFokFlag");
		this.mrSellTtpFlag = Util.getStringValue(object, "mrSellTtpFlag");
		this.mrSellStpFlag = Util.getStringValue(object, "mrSellStpFlag");
		this.mrSellStpClxFlag = Util.getStringValue(object, "mrSellStpClxFlag");
		this.mrSellAlgoInd = Util.getStringValue(object, "mrSellAlgoInd");
		this.mrSellPan = Util.getStringValue(object, "mrSellPan");
		this.mrSellAlgoId = Util.getIntegerValue(object, "mrSellAlgoId");
		this.mrSellAlgoCategory = Util.getIntegerValue(object, "mrSellAlgoCategory");
		this.mrSellAtoFlag = Util.getStringValue(object, "mrSellAtoFlag");
		this.mrSellColoFlag = Util.getStringValue(object, "mrSellColoFlag");
		this.mrIndexVal = Util.getTradeLogData(object, "mrIndexVal");
		this.mrLastTradePrice = Util.getDoubleValue(object, "mrLastTradePrice");
		this.mrDayBuyPendingQty = Util.getStringValue(object, "mrDayBuyPendingQty");
		this.mrDaySellPendingQty = Util.getStringValue(object, "mrDaySellPendingQty");
		this.mrTradeDevLtp = Util.getStringValue(object, "mrTradeDevLtp");
		this.mrTradePrice = Util.getDoubleValue(object, "mrTradePrice");
		/**
		 * Trade Log Data
		 */
		this.mrtradeLogData = StaticConstants.IOP + StaticConstants.TRADE_SEPARATE 
				+ Util.getTradeLogData(object, "mrIndicativeOpenPrice") + StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.PCP + StaticConstants.TRADE_SEPARATE 
				+ Util.getTradeLogData(object, "mrPrevDayClosePrice") + StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.TTQ + StaticConstants.TRADE_SEPARATE 
				+ Util.getStringValue(object, "mrDayQty") + StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.TTO + StaticConstants.TRADE_SEPARATE 
				+ Util.getTradeLogData(object, "mrDayTurnoverVal") + StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.DO + StaticConstants.TRADE_SEPARATE 
				+ Util.getTradeLogData(object, "mrDayOpenPrice") + StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.DH + StaticConstants.TRADE_SEPARATE 
				+ Util.getTradeLogData(object, "mrDayHighPrice") + StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.DL + StaticConstants.TRADE_SEPARATE 
				+ Util.getTradeLogData(object, "mrDayLowPrice") + StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.LTP + StaticConstants.TRADE_SEPARATE 
				+ Util.getTradeLogData(object, "mrLastTradePrice") + StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.TP + StaticConstants.TRADE_SEPARATE 
				+ Util.getTradeLogData(object, "mrTradePrice") + StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.LTT + StaticConstants.TRADE_SEPARATE 
				+ Util.getStringValue(object, "mrLastTradeTime") + StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.LLTP + StaticConstants.TRADE_SEPARATE 
				+ Util.getTradeLogData(object, "mrTradeDevLtp") + StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.BPQ + StaticConstants.TRADE_SEPARATE 
				+ Util.getStringValue(object, "mrDayBuyPendingQty") + StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.SPQ + StaticConstants.TRADE_SEPARATE 
				+ Util.getStringValue(object, "mrDaySellPendingQty")+ StaticConstants.COMMA;
		this.mrtradeLogData += StaticConstants.IV + StaticConstants.TRADE_SEPARATE  
				+ this.mrIndexVal;

		/**
		 * Buy Order Grid
		 */
		int buyIndex = CacheManager.marketReplayMapping.get("mdBuyPricePointArray".toUpperCase());
		Object[] buyArray = (Object[]) object[buyIndex];
		if(buyArray != null && buyArray.length > 0) {
			this.mdBuyPricePointArray = new ArrayList<>();
			for(int i = 0; i < buyArray.length; i++) {
				if(buyArray[i] != null) {
					this.mdBuyPricePointArray.add(new BuyOrderVO(this.mrSeqNmbr, (PricePoint)buyArray[i]));
				}
			}
		}

		/**
		 * Sell Order Grid
		 */
		int sellIndex = CacheManager.marketReplayMapping.get("mdSellPricePointArray".toUpperCase());
		Object[] sellArray = (Object[]) object[sellIndex];
		if(sellArray != null && sellArray.length > 0) {
			this.mdSellPricePointArray = new ArrayList<>();
			for(int i = 0; i < sellArray.length; i++) {
				if(sellArray[i] != null) {
					this.mdSellPricePointArray.add(new SellOrderVO(this.mrSeqNmbr,(PricePoint)sellArray[i]));
				}
			}
		}

		/**
		 * Away LTP Grid
		 */
		this.mdAwayLtpData = new AwayLtpVO(object);

		return this;
	}

	public MarketReplayVO generateBuySideData(Object[] object) throws ValidationException, ParseException {
		this.mrSeqNmbr = Util.getIntegerValue(object[0]);
		this.mrRecordTime = Util.getDateValue(object[1]);
		this.mrBuyOrderNmbr = Util.getDoubleValue(object[2]);
		this.mrBuyBrokerId = Util.getStringValue(object[3]);
		this.mrBuyClientId = Util.getStringValue(object[4]);
		this.mrBuyProClientFlag = Util.getIntegerValue(object[5]);
		this.mrBuyDealerId = Util.getIntegerValue(object[6]);
		this.mrBuyNnfId = Util.getLongValue(object[7]);
		this.mrBuyOrderQty = Util.getIntegerValue(object[8]);
		this.mrBuyRmngQty = Util.getIntegerValue(object[9]);
		this.mrBuyDisclQty = Util.getIntegerValue(object[10]);
		this.mrBuyRmngDisclQty = Util.getIntegerValue(object[11]);
		this.mrBuyLimitPrice = Util.getDoubleValue(object[12]);
		this.mrBuyTriggerPrice = Util.getDoubleValue(object[13]);
		this.mrBuyAlgoInd = Util.getStringValue(object[14]);
		this.mrBuyPan = Util.getStringValue(object[15]);
		this.mrBuyAtoFlag = Util.getStringValue(object[16]);
		this.mrBuyColoFlag = Util.getStringValue(object[17]);
		return this;
	}

}