package com.surv.entity.marketreplay;

import java.io.Serializable;
import java.util.Map;

import com.surv.cache.CacheManager;
import com.surv.utility.Util;

public class SetOrderFilterVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String whscrRunDate;
	private Integer whatifFilterNumber;
	private String whscrSeries;
	private String whatifAccountCode;
	private String whatifFilterType;
	private String whscrSymbol;
	private Long whatifOrderNumber;
	private Long whatifSeqNumber;
	private String whatifPriceadjSign;
	private Double whatifPriceadjVal;
	private String whatifTmCode;
	private Integer whatifDealerId;
	private String whatifBuysell;
	private String whatifOrdType;
	private Double whatifLimitPrice;
	private Double whatifTriggerPrice;
	private String whatifOrdValidity;
	private Integer whatifOrdQty;
	private Integer whatifOrdDisclosedQty;
	private Integer whatifProcliType;
	private String whatifClientPanid;
	private Integer whatifRunSeqNumber;
	private String whatifMktType;
	private Integer whatifBranchId;
	private Long whatifNnfId;
	private Integer whatifAlgoId;
	private Integer whatifAlgoCategory;
	private Integer whatifPreopenInd;
	private Integer whscrRunId;
	private String whatifBuysellName;
	private String whatifMktTypeName;
	private String whatifOrdTypeName;
	private String whatifOrdValidityName;
	private String whatifProcliTypeName;
	private String whatifPriceadjSignName;
	private String whatifPreopenIndName;
	
	


	public SetOrderFilterVO(Object[] object) {
		
		this.whscrRunDate =  object[0] != null ? Util.convertTimeStamToDate(object[0].toString()) : null;
		this.whatifFilterType =  object[1] != null ? object[1].toString() : null;
		this.whatifFilterNumber =  object[2] != null ? Integer.parseInt(object[2].toString()) : null;
		this.whscrSymbol =  object[3] != null ? object[3].toString() : null;
		this.whscrSeries =  object[4] != null ? object[4].toString() : null;
		this.whatifOrderNumber =  object[5] != null ? Long.parseLong(object[5].toString()) : null;
		this.whatifSeqNumber =  object[6] != null ? Long.parseLong(object[6].toString()) : null;
		this.whatifRunSeqNumber =  object[7] != null ? Integer.parseInt(object[7].toString()) : null;
		this.whatifPriceadjSign =  object[8] != null ? object[8].toString() : null;
		this.whatifPriceadjVal = object[9] != null ? Double.parseDouble(object[9].toString()) : null;
		this.whatifTmCode =  object[10] != null ? object[10].toString() : null;
		this.whatifDealerId =  object[11] != null ? Integer.parseInt(object[11].toString()) : null;
		this.whatifBuysell =   object[12] != null ? object[12].toString() : null;	
		this.whatifOrdType =   object[13] != null ? object[13].toString() : null;
		this.whatifLimitPrice =   object[14] != null ? Double.parseDouble(object[14].toString()) : null;
		this.whatifTriggerPrice =  object[15] != null ? Double.parseDouble(object[15].toString()) : null;
		this.whatifOrdValidity =  object[16] != null ? object[16].toString() : null;
		this.whatifOrdQty = object[17] != null ? Integer.parseInt(object[17].toString()) : null;
		this.whatifOrdDisclosedQty = object[18] != null ? Integer.parseInt(object[18].toString()) : null;
		this.whatifProcliType =  object[19] != null ? Integer.parseInt(object[19].toString()) : null;
		this.whatifAccountCode = object[20] != null ? object[20].toString() : null;
		this.whatifClientPanid =  object[21] != null ? object[21].toString() : null;
		this.whatifMktType =  object[22] != null ? object[22].toString() : null;
		this.whatifBranchId = object[23] != null ? Integer.parseInt(object[23].toString()) : null;
		this.whatifNnfId = object[24] != null ? Long.parseLong(object[24].toString()) : null;
		this.whatifAlgoId = object[25] != null ? Integer.parseInt(object[25].toString()) : null;
		this.whatifAlgoCategory =  object[26] != null ? Integer.parseInt(object[26].toString()) : null;
		this.whatifPreopenInd =  object[27] != null ? Integer.parseInt(object[27].toString()) : null;
		this.whscrRunId =  object[28] != null ? Integer.parseInt(object[28].toString()) : null;
		
		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_BUY_SELL");
		this.whatifBuysellName = map.get(this.whatifBuysell != null ? this.whatifBuysell.toString() : ""  ) != null ? map.get(this.whatifBuysell.toString()) : "";
		
		Map<String, String> mapMktType = CacheManager.staticReferenceLOV.get("LOV_MARKET");
		this.whatifMktTypeName = mapMktType.get(this.whatifMktType != null ? this.whatifMktType.toString() : ""  ) != null ? mapMktType.get(this.whatifMktType.toString()) : ""; 
		
		Map<String, String> mapOrdType = CacheManager.staticReferenceLOV.get("LOV_ORDER_TYPE");
		this.whatifOrdTypeName =  mapOrdType.get(this.whatifOrdType != null ? this.whatifOrdType.toString() : ""  ) != null ? mapOrdType.get(this.whatifOrdType.toString()) : "";
		
		Map<String, String> mapOrdValidity = CacheManager.staticReferenceLOV.get("LOV_ORDER_VALIDITY");
		this.whatifOrdValidityName =  mapOrdValidity.get(this.whatifOrdValidity != null ? this.whatifOrdValidity.toString() : ""  ) != null ? mapOrdValidity.get(this.whatifOrdValidity.toString()) : "";
		
		Map<String, String> mapProCli = CacheManager.staticReferenceLOV.get("LOV_PRO_CLI");
		this.whatifProcliTypeName =  mapProCli.get(this.whatifProcliType != null ? this.whatifProcliType.toString() : ""  ) != null ? mapProCli.get(this.whatifProcliType.toString()) : "";
		
		Map<String, String> mapPriceadjSign = CacheManager.staticReferenceLOV.get("LOV_PRICE_ADJUST");
		this.whatifPriceadjSignName =  mapPriceadjSign.get(this.whatifPriceadjSign != null ? this.whatifPriceadjSign.toString() : ""  ) != null ? mapPriceadjSign.get(this.whatifPriceadjSign.toString()) : "";
		
		Map<String, String> mapPreopenInd = CacheManager.staticReferenceLOV.get("LOV_PREOPEN");
		this.whatifPreopenIndName =  mapPreopenInd.get(this.whatifPreopenInd != null ? this.whatifPreopenInd.toString() : ""  ) != null ? mapPreopenInd.get(this.whatifPreopenInd.toString()) : "";

		
	}
	
	
	
	



	public String getWhscrRunDate() {
		return whscrRunDate;
	}
	public void setWhscrRunDate(String whscrRunDate) {
		this.whscrRunDate = whscrRunDate;
	}
	
	public String getWhscrSeries() {
		return whscrSeries;
	}
	public void setWhscrSeries(String whscrSeries) {
		this.whscrSeries = whscrSeries;
	}
	public String getWhatifAccountCode() {
		return whatifAccountCode;
	}
	public void setWhatifAccountCode(String whatifAccountCode) {
		this.whatifAccountCode = whatifAccountCode;
	}
	public String getWhatifFilterType() {
		return whatifFilterType;
	}
	public void setWhatifFilterType(String whatifFilterType) {
		this.whatifFilterType = whatifFilterType;
	}
	public String getWhscrSymbol() {
		return whscrSymbol;
	}
	public void setWhscrSymbol(String whscrSymbol) {
		this.whscrSymbol = whscrSymbol;
	}
	public Long getWhatifOrderNumber() {
		return whatifOrderNumber;
	}
	public void setWhatifOrderNumber(Long whatifOrderNumber) {
		this.whatifOrderNumber = whatifOrderNumber;
	}
	public Long getWhatifSeqNumber() {
		return whatifSeqNumber;
	}
	public void setWhatifSeqNumber(Long whatifSeqNumber) {
		this.whatifSeqNumber = whatifSeqNumber;
	}
	public String getWhatifPriceadjSign() {
		return whatifPriceadjSign;
	}
	public void setWhatifPriceadjSign(String whatifPriceadjSign) {
		this.whatifPriceadjSign = whatifPriceadjSign;
	}
	public Double getWhatifPriceadjVal() {
		return whatifPriceadjVal;
	}
	public void setWhatifPriceadjVal(Double whatifPriceadjVal) {
		this.whatifPriceadjVal = whatifPriceadjVal;
	}
	
	public Integer getWhatifDealerId() {
		return whatifDealerId;
	}
	public void setWhatifDealerId(Integer whatifDealerId) {
		this.whatifDealerId = whatifDealerId;
	}
	public String getWhatifBuysell() {
		return whatifBuysell;
	}
	public void setWhatifBuysell(String whatifBuysell) {
		this.whatifBuysell = whatifBuysell;
	}
	public String getWhatifOrdType() {
		return whatifOrdType;
	}
	public void setWhatifOrdType(String whatifOrdType) {
		this.whatifOrdType = whatifOrdType;
	}
	public Double getWhatifLimitPrice() {
		return whatifLimitPrice;
	}
	public void setWhatifLimitPrice(Double whatifLimitPrice) {
		this.whatifLimitPrice = whatifLimitPrice;
	}
	public Double getWhatifTriggerPrice() {
		return whatifTriggerPrice;
	}
	public void setWhatifTriggerPrice(Double whatifTriggerPrice) {
		this.whatifTriggerPrice = whatifTriggerPrice;
	}
	public String getWhatifOrdValidity() {
		return whatifOrdValidity;
	}
	public void setWhatifOrdValidity(String whatifOrdValidity) {
		this.whatifOrdValidity = whatifOrdValidity;
	}
	public Integer getWhatifOrdQty() {
		return whatifOrdQty;
	}
	public void setWhatifOrdQty(Integer whatifOrdQty) {
		this.whatifOrdQty = whatifOrdQty;
	}
	
	public Integer getWhatifProcliType() {
		return whatifProcliType;
	}
	public void setWhatifProcliType(Integer whatifProcliType) {
		this.whatifProcliType = whatifProcliType;
	}
	
	
	
	public String getWhatifMktType() {
		return whatifMktType;
	}


	public void setWhatifMktType(String whatifMktType) {
		this.whatifMktType = whatifMktType;
	}


	public Integer getWhatifBranchId() {
		return whatifBranchId;
	}


	public void setWhatifBranchId(Integer whatifBranchId) {
		this.whatifBranchId = whatifBranchId;
	}


	public Long getWhatifNnfId() {
		return whatifNnfId;
	}


	public void setWhatifNnfId(Long whatifNnfId) {
		this.whatifNnfId = whatifNnfId;
	}


	public Integer getWhatifAlgoId() {
		return whatifAlgoId;
	}


	public void setWhatifAlgoId(Integer whatifAlgoId) {
		this.whatifAlgoId = whatifAlgoId;
	}


	public Integer getWhatifAlgoCategory() {
		return whatifAlgoCategory;
	}


	public void setWhatifAlgoCategory(Integer whatifAlgoCategory) {
		this.whatifAlgoCategory = whatifAlgoCategory;
	}


	public Integer getWhatifPreopenInd() {
		return whatifPreopenInd;
	}


	public void setWhatifPreopenInd(Integer whatifPreopenInd) {
		this.whatifPreopenInd = whatifPreopenInd;
	}
	
	public Integer getWhscrRunId() {
		return whscrRunId;
	}


	public void setWhscrRunId(Integer whscrRunId) {
		this.whscrRunId = whscrRunId;
	}

	public Integer getWhatifFilterNumber() {
		return whatifFilterNumber;
	}

	public void setWhatifFilterNumber(Integer whatifFilterNumber) {
		this.whatifFilterNumber = whatifFilterNumber;
	}

	public String getWhatifTmCode() {
		return whatifTmCode;
	}

	public void setWhatifTmCode(String whatifTmCode) {
		this.whatifTmCode = whatifTmCode;
	}

	public Integer getWhatifOrdDisclosedQty() {
		return whatifOrdDisclosedQty;
	}
	public void setWhatifOrdDisclosedQty(Integer whatifOrdDisclosedQty) {
		this.whatifOrdDisclosedQty = whatifOrdDisclosedQty;
	}

	public String getWhatifClientPanid() {
		return whatifClientPanid;
	}

	public void setWhatifClientPanid(String whatifClientPanid) {
		this.whatifClientPanid = whatifClientPanid;
	}

	public Integer getWhatifRunSeqNumber() {
		return whatifRunSeqNumber;
	}

	public void setWhatifRunSeqNumber(Integer whatifRunSeqNumber) {
		this.whatifRunSeqNumber = whatifRunSeqNumber;
	}

	public String getWhatifBuysellName() {
//		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_BUY_SELL");
//		return map.get(this.getWhatifBuysell().toString()) != null ? map.get(this.getWhatifBuysell().toString()) : "";
		return whatifBuysellName;
	}

	public void setWhatifBuysellName(String whatifBuysellName) {
		this.whatifBuysellName = whatifBuysellName;
	}

	public String getWhatifMktTypeName() {
		return whatifMktTypeName;
	}

	public void setWhatifMktTypeName(String whatifMktTypeName) {
		this.whatifMktTypeName = whatifMktTypeName;
	}
	
	public String getWhatifOrdTypeName() {
//		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_ORDER_TYPE");
//		return map.get(this.getWhatifOrdType().toString()) != null ? map.get(this.getWhatifOrdType().toString()) : "";
		return  whatifOrdTypeName;
	}
	
	public void setWhatifOrdTypeName(String whatifOrdTypeName) {
		this.whatifOrdTypeName = whatifOrdTypeName;
	}

	public String getWhatifOrdValidityName() {
//		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_ORDER_VALIDITY");
//		return map.get(this.getWhatifOrdValidity().toString()) != null ? map.get(this.getWhatifOrdValidity().toString()) : "";
		return whatifOrdValidityName;
	}

	public void setWhatifOrdValidityName(String whatifOrdValidityName) {
		this.whatifOrdValidityName = whatifOrdValidityName;
	}

	public String getWhatifProcliTypeName() {
//		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_PRO_CLI");
//		return map.get(this.getWhatifProcliType().toString()) != null ? map.get(this.getWhatifProcliType().toString()) : "";
		return whatifProcliTypeName;
	}

	public void setWhatifProcliTypeName(String whatifProcliTypeName) {
		this.whatifProcliTypeName = whatifProcliTypeName;
	}

	public String getWhatifPriceadjSignName() {
//		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_PRICE_ADJUST");
//		return map.get(this.getWhatifPriceadjSign().toString()) != null ? map.get(this.getWhatifPriceadjSign().toString()) : "";
		return whatifPriceadjSignName;
	}

	public void setWhatifPriceadjSignName(String whatifPriceadjSignName) {
		this.whatifPriceadjSignName = whatifPriceadjSignName;
	}

	public String getWhatifPreopenIndName() {
//		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_PREOPEN");
//		return map.get(this.getWhatifPreopenInd().toString()) != null ? map.get(this.getWhatifPreopenInd().toString()) : "";
		return whatifPreopenIndName;
	}

	public void setWhatifPreopenIndName(String whatifPreopenIndName) {
		this.whatifPreopenIndName = whatifPreopenIndName;
	}

	@Override
	public String toString() {
		return "SetOrderFilterVO [whscrRunDate=" + whscrRunDate + ", whatifFilterNumber=" + whatifFilterNumber
				+ ", whscrSeries=" + whscrSeries + ", whatifAccountCode=" + whatifAccountCode + ", whatifFilterType="
				+ whatifFilterType + ", whscrSymbol=" + whscrSymbol + ", whatifOrderNumber=" + whatifOrderNumber
				+ ", whatifSeqNumber=" + whatifSeqNumber + ", whatifPriceadjSign=" + whatifPriceadjSign
				+ ", whatifPriceadjVal=" + whatifPriceadjVal + ", whatifTmCode=" + whatifTmCode + ", whatifDealerId="
				+ whatifDealerId + ", whatifBuysell=" + whatifBuysell + ", whatifOrdType=" + whatifOrdType
				+ ", whatifLimitPrice=" + whatifLimitPrice + ", whatifTriggerPrice=" + whatifTriggerPrice
				+ ", whatifOrdValidity=" + whatifOrdValidity + ", whatifOrdQty=" + whatifOrdQty
				+ ", whatifOrdDisclosedQty=" + whatifOrdDisclosedQty + ", whatifProcliType=" + whatifProcliType
				+ ", whatifClientPanid=" + whatifClientPanid + ", whatifRunSeqNumber=" + whatifRunSeqNumber
				+ ", whatifMktType=" + whatifMktType + ", whatifBranchId=" + whatifBranchId + ", whatifNnfId="
				+ whatifNnfId + ", whatifAlgoId=" + whatifAlgoId + ", whatifAlgoCategory=" + whatifAlgoCategory
				+ ", whatifPreopenInd=" + whatifPreopenInd + ", whscrRunId=" + whscrRunId + ", whatifBuysellName="
				+ whatifBuysellName + ", whatifMktTypeName=" + whatifMktTypeName + ", whatifOrdTypeName="
				+ whatifOrdTypeName + ", whatifOrdValidityName=" + whatifOrdValidityName + ", whatifProcliTypeName="
				+ whatifProcliTypeName + ", whatifPriceadjSignName=" + whatifPriceadjSignName
				+ ", whatifPreopenIndName=" + whatifPreopenIndName + "]";
	}
	
}
