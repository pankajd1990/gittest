package com.surv.entity.admin;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.NotEmpty;
import com.surv.constant.ValidationMessage;

@Entity
@Table(name="UAD_USER_GROUP")
public class UadUserGroupVO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="UAD_USER_GROUP_NUM")
	
	private Long uadUserGroupNum;
	
	@Column(name="UAD_USER_GROUP_NAME")
	@NotEmpty(message= ValidationMessage.ERROR_UAD_USER_GROUP_NAME_NOT_EMPTY)
	@Max(value=100 , message = ValidationMessage.ERROR_UAD_USER_GROUP_NAME_MAX)
	@Pattern(regexp = "[a-zA-Z]", message= ValidationMessage.ERROR_INVALID_UAD_USER_GROUP_NAME)
	private String uadUserGroupName;
	
	@Column(name="UAD_USER_PARENT_GROUP_NUM")
	@NotEmpty(message=ValidationMessage.ERROR_INVALID_UAD_USER_PARENT_GROUP_NUM)
	private Long uadUserParentGroupNum;
	
	@Column(name="UAD_QUERY_NOTALLWD_WRKNG_DAYS")
	private Long uadQueryNotallwdWrkngDays;

	@Column(name="UAD_CRT_BY")
	private String uadCrtBy;

	@Column(name="UAD_CRT_DATE")
	private Date uadCrtDate;
	
	@Column(name="UAD_UPDT_BY")
	private String uadUpdtBy;

	@Column(name="UAD_UPDT_DATE")
	private Date uadUpdtDate;
	
	@Transient
	private String userParentGroupName;
	
	@Transient
	private Date funcWorkingdate;

	public UadUserGroupVO() {}
	
	public UadUserGroupVO(Object[] object) {
		this.uadUserGroupNum = object[0] != null ? Long.parseLong(object[0].toString()) : null;
		this.uadUserGroupName = object[1] != null ? object[1].toString() : null;
		this.uadUserParentGroupNum = object[2] != null ? Long.parseLong(object[2].toString()) : null;
		this.uadQueryNotallwdWrkngDays = object[3] != null ? Long.parseLong(object[3].toString()) : null;
		this.uadCrtBy = object[4] != null ? object[4].toString() : null;
		this.uadCrtDate = object[5] != null ? (Date) object[5] : null;
		this.uadUpdtBy = object[6] != null ? object[6].toString() : null;
		this.uadUpdtDate = object[7] != null ? (Date) object[7] : null;
		this.userParentGroupName = object[8] != null ? object[8].toString() : null;
	}

	public Long getUadUserGroupNum() {
		return uadUserGroupNum;
	}

	public void setUadUserGroupNum(Long uadUserGroupNum) {
		this.uadUserGroupNum = uadUserGroupNum;
	}

	public String getUadUserGroupName() {
		return uadUserGroupName;
	}

	public void setUadUserGroupName(String uadUserGroupName) {
		this.uadUserGroupName = uadUserGroupName;
	}

	public Long getUadUserParentGroupNum() {
		return uadUserParentGroupNum;
	}

	public void setUadUserParentGroupNum(Long uadUserParentGroupNum) {
		this.uadUserParentGroupNum = uadUserParentGroupNum;
	}

	public Long getUadQueryNotallwdWrkngDays() {
		return uadQueryNotallwdWrkngDays;
	}

	public void setUadQueryNotallwdWrkngDays(Long uadQueryNotallwdWrkngDays) {
		this.uadQueryNotallwdWrkngDays = uadQueryNotallwdWrkngDays;
	}

	public String getUadCrtBy() {
		return uadCrtBy;
	}

	public void setUadCrtBy(String uadCrtBy) {
		this.uadCrtBy = uadCrtBy;
	}

	public Date getUadCrtDate() {
		return uadCrtDate;
	}

	public void setUadCrtDate(Date uadCrtDate) {
		this.uadCrtDate = uadCrtDate;
	}

	public String getUadUpdtBy() {
		return uadUpdtBy;
	}

	public void setUadUpdtBy(String uadUpdtBy) {
		this.uadUpdtBy = uadUpdtBy;
	}

	public Date getUadUpdtDate() {
		return uadUpdtDate;
	}

	public void setUadUpdtDate(Date uadUpdtDate) {
		this.uadUpdtDate = uadUpdtDate;
	}

	public String getUserParentGroupName() {
		return userParentGroupName;
	}

	public void setUserParentGroupName(String userParentGroupName) {
		this.userParentGroupName = userParentGroupName;
	}
	
	public Date getFuncWorkingdate() {
		return funcWorkingdate;
	}

	public void setFuncWorkingdate(Date funcWorkingdate) {
		this.funcWorkingdate = funcWorkingdate;
	}

	@Override
	public String toString() {
		return "UadUserGroupVO [uadUserGroupNum=" + uadUserGroupNum + ", uadUserGroupName=" + uadUserGroupName
				+ ", uadUserParentGroupNum=" + uadUserParentGroupNum + ", uadQueryNotallwdWrkngDays="
				+ uadQueryNotallwdWrkngDays + ", uadCrtBy=" + uadCrtBy + ", uadCrtDate=" + uadCrtDate + ", uadUpdtBy="
				+ uadUpdtBy + ", uadUpdtDate=" + uadUpdtDate + ", userParentGroupName=" + userParentGroupName + "]";
	}

}