package com.surv.entity.admin;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.surv.cache.CacheManager;
import com.surv.constant.StaticConstants;
import com.surv.utility.Util;

@Entity
@Table(name="UAD_USER")
public class UadUserVO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="UAD_USER_NUM")
	private Long uadUserNum;
	
	@Column(name="UAD_USER_ID")
	private String uadUserId;
	
	@Column(name="UAD_USER_FIRST_NAME")
	private String uadUserFirstName;

	@Column(name="UAD_USER_LAST_NAME")
	private String uadUserLastName;
	
	@Column(name="UAD_USER_EMAIL")
	private String uadUserEmail;

	@Column(name="UAD_USER_AUTH_TYPE")
	private String uadUserAuthType;
	
	@Column(name="UAD_USER_PSSWRD")
	private String uadUserPsswrd;

	@Column(name="UAD_USER_GROUP_NUM")
	private Long uadUserGroupNum;

	@Column(name="UAD_USER_LAST_LOGON_DATE")
	private Date uadUserLastLogonDate;

	@Column(name="UAD_USER_LAST_PSSWRD_CHNG_DATE")
	private Date uadUserLastPsswrdChngDate;

	@Column(name="UAD_USER_LOCK_STATUS")
	private String uadUserLockStatus;

	@Column(name="UAD_USER_RESET_FLAG")
	private String uadUserResetFlag;

	@Column(name="UAD_USER_STATUS")
	private Long uadUserStatus;

	@Column(name="UAD_USER_TYPE")
	private Long uadUserType;

	@Column(name="UAD_USER_UNSUCESSFUL_ATTEMPTS")
	private Long uadUserUnsucessfulAttempts;
	
	@Column(name="UAD_CRT_BY")
	private String uadCrtBy;

	@Column(name="UAD_CRT_DATE")
	private Date uadCrtDate;

	@Column(name="UAD_UPDT_BY")
	private String uadUpdtBy;

	@Column(name="UAD_UPDT_DATE")
	private Date uadUpdtDate;
	
	@Transient
	private String userStatusName;
	
	@Transient
	private String userResetFlagName;
	
	@Transient
	private String userLockStatusName;
	
	@Transient
	private String userAuthTypeName;
	
	@Transient
	private String userTypeName;
	
	@Transient
	private String userGroupName;
	
	@Transient
	private String userLastLogonString;
	
	@Transient
	private String userLastPsswrdChngString;
	
	@Column(name="UAD_USER_KEY")
	private String uadUserKey;
	
	public String getUadUserKey() {
		return uadUserKey;
	}
	
	public void setUadUserKey(String uadUserKey) {
		this.uadUserKey = uadUserKey;
	}

	public Long getUadUserNum() {
		return uadUserNum;
	}

	public void setUadUserNum(Long uadUserNum) {
		this.uadUserNum = uadUserNum;
	}

	public String getUadUserId() {
		return uadUserId;
	}

	public void setUadUserId(String uadUserId) {
		this.uadUserId = uadUserId;
	}

	public String getUadUserFirstName() {
		return uadUserFirstName;
	}

	public void setUadUserFirstName(String uadUserFirstName) {
		this.uadUserFirstName = uadUserFirstName;
	}

	public String getUadUserLastName() {
		return uadUserLastName;
	}

	public void setUadUserLastName(String uadUserLastName) {
		this.uadUserLastName = uadUserLastName;
	}

	public String getUadUserEmail() {
		return uadUserEmail;
	}

	public void setUadUserEmail(String uadUserEmail) {
		this.uadUserEmail = uadUserEmail;
	}

	public String getUadUserAuthType() {
		return uadUserAuthType;
	}

	public void setUadUserAuthType(String uadUserAuthType) {
		this.uadUserAuthType = uadUserAuthType;
	}

	public String getUadUserPsswrd() {
		return uadUserPsswrd;
	}

	public void setUadUserPsswrd(String uadUserPsswrd) {
		this.uadUserPsswrd = uadUserPsswrd;
	}

	public Long getUadUserGroupNum() {
		return uadUserGroupNum;
	}

	public void setUadUserGroupNum(Long uadUserGroupNum) {
		this.uadUserGroupNum = uadUserGroupNum;
	}

	public Date getUadUserLastLogonDate() {
		return uadUserLastLogonDate;
	}

	public void setUadUserLastLogonDate(Date uadUserLastLogonDate) {
		this.uadUserLastLogonDate = uadUserLastLogonDate;
	}

	public Date getUadUserLastPsswrdChngDate() {
		return uadUserLastPsswrdChngDate;
	}

	public void setUadUserLastPsswrdChngDate(Date uadUserLastPsswrdChngDate) {
		this.uadUserLastPsswrdChngDate = uadUserLastPsswrdChngDate;
	}

	public String getUadUserLockStatus() {
		return uadUserLockStatus;
	}

	public void setUadUserLockStatus(String uadUserLockStatus) {
		this.uadUserLockStatus = uadUserLockStatus;
	}

	public String getUadUserResetFlag() {
		return uadUserResetFlag;
	}

	public void setUadUserResetFlag(String uadUserResetFlag) {
		this.uadUserResetFlag = uadUserResetFlag;
	}

	public Long getUadUserStatus() {
		return uadUserStatus;
	}

	public void setUadUserStatus(Long uadUserStatus) {
		this.uadUserStatus = uadUserStatus;
	}

	public Long getUadUserType() {
		return uadUserType;
	}

	public void setUadUserType(Long uadUserType) {
		this.uadUserType = uadUserType;
	}

	public Long getUadUserUnsucessfulAttempts() {
		return uadUserUnsucessfulAttempts;
	}

	public void setUadUserUnsucessfulAttempts(Long uadUserUnsucessfulAttempts) {
		this.uadUserUnsucessfulAttempts = uadUserUnsucessfulAttempts;
	}

	public String getUadCrtBy() {
		return uadCrtBy;
	}

	public void setUadCrtBy(String uadCrtBy) {
		this.uadCrtBy = uadCrtBy;
	}

	public Date getUadCrtDate() {
		return uadCrtDate;
	}

	public void setUadCrtDate(Date uadCrtDate) {
		this.uadCrtDate = uadCrtDate;
	}

	public String getUadUpdtBy() {
		return uadUpdtBy;
	}

	public void setUadUpdtBy(String uadUpdtBy) {
		this.uadUpdtBy = uadUpdtBy;
	}

	public Date getUadUpdtDate() {
		return uadUpdtDate;
	}

	public void setUadUpdtDate(Date uadUpdtDate) {
		this.uadUpdtDate = uadUpdtDate;
	}

	public String getUserStatusName() {
		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_USER_STATUS");
		return map.get(this.getUadUserStatus().toString()) != null ? map.get(this.getUadUserStatus().toString()) : "";
	}

	public void setUserStatusName(String userStatusName) {
		this.userStatusName = userStatusName;
	}

	public String getUserResetFlagName() {
		return uadUserResetFlag != null && uadUserResetFlag.equals(StaticConstants.STRING_Y) ? "YES" : "NO";
	}

	public void setUserResetFlagName(String userResetFlagName) {
		this.userResetFlagName = userResetFlagName;
	}

	public String getUserLockStatusName() {
		return uadUserLockStatus != null && uadUserLockStatus.equals(StaticConstants.STRING_Y) ? "YES" : "NO";
	}

	public void setUserLockStatusName(String userLockStatusName) {
		this.userLockStatusName = userLockStatusName;
	}

	public String getUserAuthTypeName() {
		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_USER_AUTH_TYPE");
		return map.get(this.getUadUserAuthType()) != null ? map.get(this.getUadUserAuthType()) : "";
	}

	public void setUserAuthTypeName(String userAuthTypeName) {
		this.userAuthTypeName = userAuthTypeName;
	}

	public String getUserTypeName() {
		Map<String, String> map = CacheManager.staticReferenceLOV.get("LOV_USER_TYPE");
		return map.get(this.getUadUserType().toString()) != null ? map.get(this.getUadUserType().toString()) : "";
	}

	public void setUserTypeName(String userTypeName) {
		this.userTypeName = userTypeName;
	}

	public String getUserGroupName() {
		return userGroupName;
	}

	public void setUserGroupName(String userGroupName) {
		this.userGroupName = userGroupName;
	}

	public String getUserLastLogonString() {
		return uadUserLastLogonDate != null ? Util.getDateTimeString(uadUserLastLogonDate) : null;
	}

	public void setUserLastLogonString(String userLastLogonString) {
		this.userLastLogonString = userLastLogonString;
	}

	public String getUserLastPsswrdChngString() {
		return uadUserLastPsswrdChngDate != null ? Util.getDateTimeString(uadUserLastPsswrdChngDate) : null;
	}

	public void setUserLastPsswrdChngString(String userLastPsswrdChngString) {
		this.userLastPsswrdChngString = userLastPsswrdChngString;
	}

	@Override
	public String toString() {
		return "UadUserVO [uadUserNum=" + uadUserNum + ", uadUserId=" + uadUserId + ", uadUserFirstName="
				+ uadUserFirstName + ", uadUserLastName=" + uadUserLastName + ", uadUserEmail=" + uadUserEmail
				+ ", uadUserAuthType=" + uadUserAuthType + ", uadUserPsswrd=" + uadUserPsswrd + ", uadUserGroupNum="
				+ uadUserGroupNum + ", uadUserLastLogonDate=" + uadUserLastLogonDate + ", uadUserLastPsswrdChngDate="
				+ uadUserLastPsswrdChngDate + ", uadUserLockStatus=" + uadUserLockStatus + ", uadUserResetFlag="
				+ uadUserResetFlag + ", uadUserStatus=" + uadUserStatus + ", uadUserType=" + uadUserType
				+ ", uadUserUnsucessfulAttempts=" + uadUserUnsucessfulAttempts + ", uadCrtBy=" + uadCrtBy
				+ ", uadCrtDate=" + uadCrtDate + ", uadUpdtBy=" + uadUpdtBy + ", uadUpdtDate=" + uadUpdtDate
				+ ", userStatusName=" + userStatusName + ", userResetFlagName=" + userResetFlagName
				+ ", userLockStatusName=" + userLockStatusName + ", userAuthTypeName=" + userAuthTypeName
				+ ", userTypeName=" + userTypeName + ", userGroupName=" + userGroupName + ", userLastLogonString="
				+ userLastLogonString + ", userLastPsswrdChngString=" + userLastPsswrdChngString +  ", uadUserKey="
						+ uadUserKey +"]";
	}

}