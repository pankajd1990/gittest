package com.surv.service.marketreplay;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.query.QueryCursor;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.surv.cache.CacheManager;
import com.surv.config.SqlConfig;
import com.surv.constant.StaticConstants;
import com.surv.constant.StaticMsgConstants;
import com.surv.dao.marketreplay.MarketReplayDAO;
import com.surv.entity.marketreplay.EventVO;
import com.surv.entity.marketreplay.MarketReplayVO;
import com.surv.entity.marketreplay.MktwtchHighlightVO;
import com.surv.exception.RepositoryException;
import com.surv.exception.ServiceException;
import com.surv.json.ResponseSetter;
import com.surv.json.ResponseVO;
import com.surv.service.common.GenericService;
import com.surv.utility.Logger;
import com.surv.utility.MasterUtil;
@Service("marketReplayService")
public class MarketReplayService extends GenericService {
	
	@Autowired
	private SqlConfig sqlConfig;
	
	@Autowired
	@Qualifier("marketReplayDAO")
	private MarketReplayDAO marketReplayDAO;
	
	
	@Transactional(readOnly = true)
	public void playMarketReplay(Long runId,Integer mrSeqNmbr, ResponseVO responseVO) throws ServiceException {
		try {
			IgniteCache<?, ?> activityCache = CacheManager.igniteCache;

			if(activityCache == null) {
				ResponseSetter.getResponseString(responseVO, 
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERROR_IGNITE_CACHE_NULL, null);
				return;
			}

			String activityQuery = this.sqlConfig.getCacheQuery("PLAYMARKETREPLAY");

			Map<String, Object> activityMap = new HashMap<>();
			activityMap.put("MREVENTRUNID", runId);
			activityMap.put("MRSEQNMBR", mrSeqNmbr);

			SqlFieldsQuery activitySqlQuery = new SqlFieldsQuery(MasterUtil.queryGenerater(activityQuery, activityMap));
			List<MarketReplayVO> listMarketData = new ArrayList<>();

			try (QueryCursor<List<?>> cursor = activityCache.query(activitySqlQuery)) {
				for (List<?> record : cursor) {
					listMarketData.add(new MarketReplayVO().generateMarketReplayData(record.toArray()));
				}
			}

			IgniteCache<?, ?> eventCache = CacheManager.igniteEventCache;

			if(eventCache == null) {
				ResponseSetter.getResponseString(responseVO, 
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERROR_IGNITE_CACHE_NULL, null);
				return;
			}

			String eventQuery = this.sqlConfig.getCacheQuery("GETDATAFROMEVENTCACHE");

			Map<String, Object> eventMap = new HashMap<>();
			eventMap.put("MREVENTRUNID", runId);

			SqlFieldsQuery eventSqlQuery = new SqlFieldsQuery(MasterUtil.queryGenerater(eventQuery, eventMap));
			
			List<EventVO> listEventData = new ArrayList<>();
			try (QueryCursor<List<?>> cursor = eventCache.query(eventSqlQuery)) {
				for (List<?> record : cursor) {
					listEventData.add(new EventVO(record.toArray()));
				}
			}

			Map<String, Object> map = new HashMap<>();
			map.put("Event", listEventData);
			map.put("Activity", listMarketData);

			ResponseSetter.getResponseString(responseVO, 
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, map);
			

		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
	}

	@Transactional(readOnly = true)
	public void marketReplayPopupGridDataCount(String flag, Long runId, Integer mrSeqNmbr, Double limitPrice,Integer thresholdQty,Integer thresholdCxlQty ,Integer mrStartSeqNmbr, ResponseVO responseVO) throws ServiceException {
		try {
			IgniteCache<?, ?> igniteCache = CacheManager.igniteCache;
			String query = "";
			Map<String, Object> map = new HashMap<>();
			if(igniteCache == null) {
				ResponseSetter.getResponseString(responseVO, 
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERROR_IGNITE_CACHE_NULL, null);
				return;
			}

			if(flag.equalsIgnoreCase("B")){
				query = this.sqlConfig.getCacheQuery("BUYSIDEGRIDDATA");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);
				map.put("LIMITPRICE", limitPrice);
			}
			if(flag.equalsIgnoreCase("S")){
				query = this.sqlConfig.getCacheQuery("SELLSIDEGRIDDATA");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);
				map.put("LIMITPRICE", limitPrice);
			}
			if(flag.equalsIgnoreCase("BU")){
				query = this.sqlConfig.getCacheQuery("BUYSIDEUNEXECUTEDGRIDDATA");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);
				map.put("THRESHOLDQTY", thresholdQty);
				map.put("MRSTARTSEQNMBR", mrStartSeqNmbr);
				
			}
			if(flag.equalsIgnoreCase("SU")){
				query = this.sqlConfig.getCacheQuery("SELLSIDEUNEXECUTEDGRIDDATA");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);
				map.put("THRESHOLDQTY", thresholdQty);
				map.put("MRSTARTSEQNMBR", mrStartSeqNmbr);
			}
			if(flag.equalsIgnoreCase("BC")){
				query = this.sqlConfig.getCacheQuery("BUYSIDECANCELLEDGRIDDATA");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);
				map.put("MRSTARTSEQNMBR", mrStartSeqNmbr);
				map.put("THRESHOLDCXLQTY", thresholdCxlQty);
			}
			if(flag.equalsIgnoreCase("SC")){
				query = this.sqlConfig.getCacheQuery("SELLSIDECANCELLEDGRIDDATA");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);
				map.put("MRSTARTSEQNMBR", mrStartSeqNmbr);
				map.put("THRESHOLDCXLQTY", thresholdCxlQty);
			}
			if(flag.equalsIgnoreCase("BLTP")){
				query = this.sqlConfig.getCacheQuery("BUYSIDEAWAYLTPGRIDDATA");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);	
				map.put("LIMITPRICE", limitPrice);
			}
			if(flag.equalsIgnoreCase("SLTP")){
				query = this.sqlConfig.getCacheQuery("SELLSIDEAWAYLTPGRIDDATA");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);	
				map.put("LIMITPRICE", limitPrice);
			}
			if(flag.equalsIgnoreCase("BLTPSL")){
				query = this.sqlConfig.getCacheQuery("BUYSIDEAWAYLTPSLGRIDDATA");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);	
				map.put("LIMITPRICE", limitPrice);
			}
			if(flag.equalsIgnoreCase("SLTPSL")){
				query = this.sqlConfig.getCacheQuery("SELLSIDEAWAYLTPSLGRIDDATA");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);	
				map.put("LIMITPRICE", limitPrice);
			}

			SqlFieldsQuery sqlFieldsQueryBuy = new SqlFieldsQuery(MasterUtil.queryGenerater(query, map));

			List<MarketReplayVO> listData = new ArrayList<>();
			try (QueryCursor<List<?>> cursor = igniteCache.query(sqlFieldsQueryBuy)) {
				for (List<?> record : cursor) {
					listData.add(new MarketReplayVO().generateBuySideData(record.toArray()));
				}
			}

			if(listData != null && !listData.isEmpty()) {
				ResponseSetter.getResponseString(responseVO, 
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, listData.size());
			}else {
				ResponseSetter.getResponseString(responseVO, 
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND, null);
			}
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
	}
	
	@Transactional(readOnly = true)
	public void marketReplayPopupGridData(String flag, Long runId, Integer mrSeqNmbr, Double limitPrice,Integer thresholdQty,Integer thresholdCxlQty ,Integer mrStartSeqNmbr,Integer pageSize ,Integer from, ResponseVO responseVO ) throws ServiceException {
		try {
			IgniteCache<?, ?> igniteCache = CacheManager.igniteCache;
			String query = "";
			Map<String, Object> map = new HashMap<>();
			if(igniteCache == null) {
				ResponseSetter.getResponseString(responseVO, 
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERROR_IGNITE_CACHE_NULL, null);
				return;
			}
			
			map.put("RECCOUNT", pageSize);
			map.put("FROM", from);

			if(flag.equalsIgnoreCase("B")){
				query = this.sqlConfig.getCacheQuery("BUYSIDEGRIDDATA1");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);
				map.put("LIMITPRICE", limitPrice);
			}
			if(flag.equalsIgnoreCase("S")){
				query = this.sqlConfig.getCacheQuery("SELLSIDEGRIDDATA1");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);
				map.put("LIMITPRICE", limitPrice);
			}
			if(flag.equalsIgnoreCase("BU")){
				query = this.sqlConfig.getCacheQuery("BUYSIDEUNEXECUTEDGRIDDATA1");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);
				map.put("THRESHOLDQTY", thresholdQty);
				map.put("MRSTARTSEQNMBR", mrStartSeqNmbr);
				
			}
			if(flag.equalsIgnoreCase("SU")){
				query = this.sqlConfig.getCacheQuery("SELLSIDEUNEXECUTEDGRIDDATA1");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);
				map.put("THRESHOLDQTY", thresholdQty);
				map.put("MRSTARTSEQNMBR", mrStartSeqNmbr);
			}
			if(flag.equalsIgnoreCase("BC")){
				query = this.sqlConfig.getCacheQuery("BUYSIDECANCELLEDGRIDDATA1");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);
				map.put("MRSTARTSEQNMBR", mrStartSeqNmbr);
				map.put("THRESHOLDCXLQTY", thresholdCxlQty);
			}
			if(flag.equalsIgnoreCase("SC")){
				query = this.sqlConfig.getCacheQuery("SELLSIDECANCELLEDGRIDDATA1");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);
				map.put("MRSTARTSEQNMBR", mrStartSeqNmbr);
				map.put("THRESHOLDCXLQTY", thresholdCxlQty);
			}
			if(flag.equalsIgnoreCase("BLTP")){
				query = this.sqlConfig.getCacheQuery("BUYSIDEAWAYLTPGRIDDATA1");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);	
				map.put("LIMITPRICE", limitPrice);
			}
			if(flag.equalsIgnoreCase("SLTP")){
				query = this.sqlConfig.getCacheQuery("SELLSIDEAWAYLTPGRIDDATA1");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);	
				map.put("LIMITPRICE", limitPrice);
			}
			if(flag.equalsIgnoreCase("BLTPSL")){
				query = this.sqlConfig.getCacheQuery("BUYSIDEAWAYLTPSLGRIDDATA1");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);	
				map.put("LIMITPRICE", limitPrice);
			}
			if(flag.equalsIgnoreCase("SLTPSL")){
				query = this.sqlConfig.getCacheQuery("SELLSIDEAWAYLTPSLGRIDDATA1");
				map.put("RUNID", runId);
				map.put("MRSEQNMBR", mrSeqNmbr);	
				map.put("LIMITPRICE", limitPrice);
			}

			SqlFieldsQuery sqlFieldsQueryBuy = new SqlFieldsQuery(MasterUtil.queryGenerater(query, map));

			List<MarketReplayVO> listData = new ArrayList<>();
			try (QueryCursor<List<?>> cursor = igniteCache.query(sqlFieldsQueryBuy)) {
				for (List<?> record : cursor) {
					listData.add(new MarketReplayVO().generateBuySideData(record.toArray()));
				}
			}

			if(listData != null && !listData.isEmpty()) {
				ResponseSetter.getResponseString(responseVO, 
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, listData);
			}else {
				ResponseSetter.getResponseString(responseVO, 
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND, null);
			}
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
	}


	@Transactional(readOnly = true)
		public void getHighlightCondition(MktwtchHighlightVO mktwtchHighlightVO, ResponseVO responseVO) throws ServiceException {
			try{
				MktwtchHighlightVO highlightVO = this.marketReplayDAO.getHighlightCondition(mktwtchHighlightVO);
				
				if(highlightVO != null) {
					ResponseSetter.getResponseString(responseVO, 
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, highlightVO);
				}else {
					ResponseSetter.getResponseString(responseVO, 
						StaticConstants.FAILURE_CODE, StaticConstants.FAILURE, null);
				}
			}catch (RepositoryException e) {
				Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
				throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR);
			}
		}

	@Transactional
	public void submitHighlightCondition(MktwtchHighlightVO mktwtchHighlightVO, ResponseVO responseVO) throws ServiceException {
		try {
			super.validate(mktwtchHighlightVO);
			this.marketReplayDAO.submitHighlightCondition(mktwtchHighlightVO);
			ResponseSetter.getResponseString(responseVO, 
					StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS);
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
	}
	
	public Map<String, Object> playMarketReplaySocket(Integer runId, Integer mrSeqNmbr, Integer lastSeqNmbr, Integer prevForwardFlag,Integer gotoStartSeqNmbr) throws ServiceException {
		Map<String, Object> map = new HashMap<>();
		try {
			map =  marketReplayDAO.playMarketReplaySocket(runId, mrSeqNmbr, lastSeqNmbr, prevForwardFlag,gotoStartSeqNmbr);
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return map;
	}
	
	public void goToMarketReplay(Integer mrSeqNmbr, String mrRecordTimeString, String mrPan, Long mrOrderNmbr, Long mrFillNmbr, Integer runId, ResponseVO responseVO) throws ServiceException {
		try {
			Integer seqNum =  marketReplayDAO.goToMarketReplay(mrSeqNmbr,mrRecordTimeString,mrPan,mrOrderNmbr,mrFillNmbr,runId);
			if(seqNum != null) {
				ResponseSetter.getResponseString(responseVO, 
					StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, seqNum);
			}else {
				ResponseSetter.getResponseString(responseVO, 
					StaticConstants.FAILURE_CODE, StaticConstants.FAILURE, -1);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
	}
}