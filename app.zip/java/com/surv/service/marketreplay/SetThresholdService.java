package com.surv.service.marketreplay;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.surv.constant.StaticConstants;
import com.surv.constant.StaticMsgConstants;
import com.surv.dao.marketreplay.SetThresholdDAO;
import com.surv.entity.marketreplay.AlertDetailsVO;
import com.surv.entity.marketreplay.AlertRuleThresholdDetailVO;
import com.surv.entity.marketreplay.AlertRuleVO;
import com.surv.exception.RepositoryException;
import com.surv.exception.ServiceException;
import com.surv.json.ResponseSetter;
import com.surv.json.ResponseVO;
import com.surv.service.common.GenericService;
import com.surv.utility.Logger;
import com.surv.utility.Util;

@Service("setThresholdService")
public class SetThresholdService extends GenericService {

	@Autowired
	@Qualifier("setThresholdDAO")
	private SetThresholdDAO setThresholdDAO;

	@Transactional(readOnly = true)
	public void getAllAlerts(ResponseVO responseVO) throws ServiceException {
		try {
			List<String> list = this.setThresholdDAO.getAllAlerts();
			if(list != null) {
				ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE, 
					StaticConstants.SUCCESS, Util.toJSONStringFromListNew(list));
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	public void searchAlertCountData(List<String> ruleName, ResponseVO responseVO)throws ServiceException {
		try {
			int count = this.setThresholdDAO.searchAlertCountData(ruleName);
			if(count > 0) {
				ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, count);
			}else {
				ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}

	}

	@Transactional(readOnly = true)
	public void searchAlertData(List<String> ruleName, int from, int recCount, ResponseVO responseVO) throws ServiceException {
		try {
			List<AlertRuleVO> list = this.setThresholdDAO.searchAlertData(ruleName, from, recCount);
			if(list != null) {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, list);
			}else {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	public void searchSelectedCountData(List<AlertRuleVO> listAlertDetails, ResponseVO responseVO)throws ServiceException {
		try {
			int count = this.setThresholdDAO.searchSelectedCountData(listAlertDetails);
			if(count > 0) {
				ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, count);
			}else {
				ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional(readOnly = true)
	public void searchSelectedData(List<AlertRuleVO> listAlertDetails, int from, int recCount, ResponseVO responseVO) throws ServiceException {
		try {
			List<AlertDetailsVO> list = this.setThresholdDAO.searchSelectedData(listAlertDetails, from, recCount);

			if(list != null) {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, list);
			}else {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional()
	public void updateData(List<AlertRuleThresholdDetailVO> listUpdateDetails, ResponseVO responseVO) throws ServiceException {
		try {
			for (AlertRuleThresholdDetailVO alertRuleThresholdDetailVO : listUpdateDetails) {
				super.validate(alertRuleThresholdDetailVO);
			}
			this.setThresholdDAO.updateData(listUpdateDetails);
			ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE, 
					StaticConstants.SUCCESS, null);
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

}