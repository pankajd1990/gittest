package com.surv.service.marketreplay;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.surv.dao.marketreplay.BusinessDateDAO;
import com.surv.entity.marketreplay.BusinessDateVO;
import com.surv.exception.RepositoryException;
import com.surv.exception.ServiceException;
import com.surv.json.ResponseVO;
import com.surv.service.common.GenericService;
import com.surv.utility.Logger;

@Service("businessDateService")
public class BusinessDateService extends GenericService {

	@Autowired
	@Qualifier(value = "responseVO")
	private ResponseVO responseVO;

	@Autowired
	@Qualifier(value = "businessDateDAO")
	private BusinessDateDAO businessDateDAO;

	@Transactional(readOnly = true)
	public BusinessDateVO getBusinessDateDetails() throws ServiceException {
		try {
			return this.businessDateDAO.getBusinessDateDetails();
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error(e.getMessage());
			throw new ServiceException(e.getMessage());	
		}
	}

}