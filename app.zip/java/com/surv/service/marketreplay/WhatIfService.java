package com.surv.service.marketreplay;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.surv.cache.CacheManager;
import com.surv.constant.StaticConstants;
import com.surv.constant.StaticMsgConstants;
import com.surv.constraints.group.addWhatifOrderFiltersVO;
import com.surv.constraints.group.modifyWhatifOrderFiltersVO;
import com.surv.dao.marketreplay.WhatIfDAO;
import com.surv.entity.marketreplay.SetOrderFilterVO;
import com.surv.entity.marketreplay.WhatifOrderFilterVO;
import com.surv.entity.marketreplay.WhatifSelectCriteria;
import com.surv.exception.RepositoryException;
import com.surv.exception.ServiceException;
import com.surv.exception.ValidationException;
import com.surv.json.ResponseSetter;
import com.surv.json.ResponseVO;
import com.surv.service.common.GenericService;
import com.surv.utility.Logger;
import com.surv.utility.Util;

@Service("whatIfService")
public class WhatIfService extends GenericService{

	@Autowired
	@Qualifier(value = "whatIfDAO")
	private WhatIfDAO whatIfDAO;

	@Transactional(readOnly = true)
	public void getAllRunId(ResponseVO responseVO) throws ServiceException {
		try {
			List<String> list = this.whatIfDAO.getAllRunId();
			if(list != null) {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, Util.toJSONStringFromListNew(list));
			}
		} catch (RepositoryException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional(readOnly = true)
	public void searchRunCount(String runId, ResponseVO responseVO)throws ServiceException {
		try {
			int count = this.whatIfDAO.searchRunCount(runId);
			if(count > 0) {
				ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, count);
			}else {
				ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}

	}

	@Transactional(readOnly = true)
	public void searchRunIdData(String runId, int from, int recCount, ResponseVO responseVO) throws ServiceException {
		try {
			List<SetOrderFilterVO> list = this.whatIfDAO.searchRunIdData(runId, from, recCount);
			if(list != null) {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, list);
			}else {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	public void getAddLOV(ResponseVO responseVO) throws ServiceException {
		try {
			String bs = Util.toJSONStringFromMap(CacheManager.staticReferenceLOV.get("LOV_BUY_SELL"));
			String market = Util.toJSONStringFromMap(CacheManager.staticReferenceLOV.get("LOV_MARKET"));
			String orderType = Util.toJSONStringFromMap(CacheManager.staticReferenceLOV.get("LOV_ORDER_TYPE"));
			String orderValidity = Util.toJSONStringFromMap(CacheManager.staticReferenceLOV.get("LOV_ORDER_VALIDITY"));
			String proCli = Util.toJSONStringFromMap(CacheManager.staticReferenceLOV.get("LOV_PRO_CLI"));
			String priceAdjust = Util.toJSONStringFromMap(CacheManager.staticReferenceLOV.get("LOV_PRICE_ADJUST"));
			String preopen = Util.toJSONStringFromMap(CacheManager.staticReferenceLOV.get("LOV_PREOPEN"));

			Map<String, String> map = new HashMap<>();
			map.put("bs", bs);
			map.put("market", market);
			map.put("orderType", orderType);
			map.put("orderValidity", orderValidity);
			map.put("proCli", proCli);
			map.put("priceAdjust", priceAdjust);
			map.put("preopen", preopen);
			ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, map);
		} catch (Exception e) {
			throw new ServiceException(e.getMessage());
		}
	}	

	public void getActionLOV(ResponseVO responseVO) throws ServiceException {
		try {
			String action = Util.toJSONStringFromMap(CacheManager.staticReferenceLOV.get("LOV_ACTION"));

			Map<String, String> map = new HashMap<>();
			map.put("action", action);

			ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, map);
		} catch (Exception e) {
			throw new ServiceException(e.getMessage());
		}
	}



	@Transactional
	public void addNewOrd(WhatifOrderFilterVO whatifOrderFilterVO, ResponseVO responseVO) throws ServiceException {
		try {
			super.validate(whatifOrderFilterVO,addWhatifOrderFiltersVO.class);
			this.whatIfDAO.addNewOrd(whatifOrderFilterVO);

			ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE,
					StaticMsgConstants.RECORD_ADD_SUCCESS, null);
		}catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional
	public void addModOrd(WhatifOrderFilterVO whatifOrderFilterVO, ResponseVO responseVO) throws ServiceException {
		try {
			super.validate(whatifOrderFilterVO,modifyWhatifOrderFiltersVO.class);
			this.whatIfDAO.addModOrd(whatifOrderFilterVO);

			ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE,
					StaticMsgConstants.RECORD_ADD_SUCCESS, null);
		}catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}
	}


	@Transactional
	public void addRemoveOrd(WhatifOrderFilterVO whatifOrderFilterVO, ResponseVO responseVO) throws ServiceException {
		try {
			super.validate(whatifOrderFilterVO);
			this.whatIfDAO.addRemoveOrd(whatifOrderFilterVO);

			ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE,
					StaticMsgConstants.RECORD_ADD_SUCCESS, null);
		}catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}
	}

	public void ModNewOrd(WhatifOrderFilterVO whatifOrderFilterVO, ResponseVO responseVO) throws ServiceException {
		try {
			super.validate(whatifOrderFilterVO,addWhatifOrderFiltersVO.class);
			this.whatIfDAO.ModNewOrd(whatifOrderFilterVO);
			ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE,
					StaticMsgConstants.RECORD_MOD_SUCCESS, null);
		} catch (RepositoryException | ValidationException e) {
			Logger.EXCEPTION.error(e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	public void ModModOrd(WhatifOrderFilterVO whatifOrderFilterVO, ResponseVO responseVO) throws ServiceException {
		try {
			super.validate(whatifOrderFilterVO,modifyWhatifOrderFiltersVO.class);
			this.whatIfDAO.ModModOrd(whatifOrderFilterVO);
			ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE,
					StaticMsgConstants.RECORD_MOD_SUCCESS, null);
		} catch (RepositoryException | ValidationException e) {
			Logger.EXCEPTION.error(e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	public void ModRemoveOrd(WhatifOrderFilterVO whatifOrderFilterVO, ResponseVO responseVO) throws ServiceException {
		try {
			super.validate(whatifOrderFilterVO);
			this.whatIfDAO.ModRemoveOrd(whatifOrderFilterVO);
			ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE,
					StaticMsgConstants.RECORD_MOD_SUCCESS, null);
		} catch (RepositoryException | ValidationException e) {
			Logger.EXCEPTION.error(e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	public void deleteOrderFilter(int whatifFilterNumber, int whatifRunId, ResponseVO responseVO) throws ServiceException {
		try {
			this.whatIfDAO.deleteOrderFilter(whatifFilterNumber, whatifRunId);
			ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE,
					StaticMsgConstants.RECORD_DEL_SUCCESS, null);
		} catch (RepositoryException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	/**
	 * START
	 * What-If: What-If Tab
	 * @author Bansari
	 */
	@Transactional(readOnly = true)
	public void getWhatIfRunId(ResponseVO responseVO) throws ServiceException {
		try {
			List<Object[]> list = this.whatIfDAO.getWhatIfRunId();
			if(list != null) {
				ResponseSetter.getResponseString(responseVO,StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, Util.toStringListJSONArray(list));
			}
		}catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional(readOnly = true)
	public void getWhatIfGridCount(String runId, ResponseVO responseVO) throws ServiceException {
		try {
			Long count = this.whatIfDAO.getWhatIfGridCount(runId);
			if(count > 0) {
				ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, count);
			}else {
				ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional(readOnly = true)
	public void getWhatIfGridData(String runId, int from, int recCount, ResponseVO responseVO) throws ServiceException {
		try {
			List<WhatifSelectCriteria> list = this.whatIfDAO.getWhatIfGridData(runId, from,recCount);
			if(list != null) {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, list);
			}else {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional
	public void addWhatIfData(WhatifSelectCriteria whatifSelectCriteria, ResponseVO responseVO) throws ServiceException, ValidationException {
		try {
			boolean valFlag;
			valFlag = super.validate(whatifSelectCriteria, "replayCriteria", responseVO);
			if(!valFlag)
				return;
//			List<WhatifSelectCriteria> dbRecordsList = this.whatIfDAO.getWhatIfDataFromDb(whatifSelectCriteria);
//			if(dbRecordsList != null) {
//				throw new ServiceException(StaticMsgConstants.ERR_DATA_INTEGRITY);
//			}
			this.whatIfDAO.addWhatIfData(whatifSelectCriteria);
			ResponseSetter.getResponseString(responseVO,StaticConstants.SUCCESS_CODE, StaticMsgConstants.RECORD_ADD_SUCCESS, null);

		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}catch (Exception e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
	
	public void modifyWhatIfData(WhatifSelectCriteria whatifSelectCriteria, ResponseVO responseVO) throws ServiceException {
		try {
			List<WhatifSelectCriteria> objList = this.whatIfDAO.getDataFromDbForUpdate(whatifSelectCriteria);
			if(objList != null && objList.get(0).equals(whatifSelectCriteria)) {
				throw new ServiceException(StaticMsgConstants.NO_CHANGE_TO_SAVE);
			}
			this.whatIfDAO.modifyWhatIfData(whatifSelectCriteria);
			ResponseSetter.getResponseString(responseVO,StaticConstants.SUCCESS_CODE, StaticMsgConstants.RECORD_MOD_SUCCESS, null);
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * END
	 * What-If: What-If Tab
	 * @author Bansari
	 */
}
