package com.surv.service.marketreplay;

import java.util.Date;
import java.util.List;

import org.apache.ignite.IgniteCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nse.ngs.domain.mr.MRRequestCache;
import com.surv.cache.CacheManager;
import com.surv.constant.StaticConstants;
import com.surv.constant.StaticMsgConstants;
import com.surv.constraints.group.initiateMktwtchSelectCriteriaVO;
import com.surv.dao.marketreplay.ReplayCriteriaDAO;
import com.surv.entity.admin.UadUserGroupVO;
import com.surv.entity.marketreplay.MktwtchSelectCriteriaVO;
import com.surv.entity.marketreplay.SCmSecurityMasterVO;
import com.surv.exception.RepositoryException;
import com.surv.exception.ServiceException;
import com.surv.exception.ValidationException;
import com.surv.json.ResponseSetter;
import com.surv.json.ResponseVO;
import com.surv.service.common.GenericService;
import com.surv.utility.Logger;
import com.surv.utility.Util;

@Service("replayCriteriaService")
public class ReplayCriteriaService extends GenericService {

	@Autowired
	@Qualifier("replayCriteriaDAO")
	private ReplayCriteriaDAO replayCriteriaDAO;

	@Autowired
	@Qualifier(value = "responseVO")
	private ResponseVO response;

	@Transactional(readOnly = true)
	public void getIndexLovdata(Date runDate, ResponseVO responseVO) throws ServiceException {
		try {
			List<Object[]> list = this.replayCriteriaDAO.getIndexLovdata(runDate);
			if(list != null) {
				ResponseSetter.getResponseString(responseVO,StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, Util.toStringListJSONArray(list));
			}else {
				ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		}catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional(readOnly = true)
	public void getRunId(ResponseVO responseVO) throws ServiceException {
		try {
			List<Object[]> list = this.replayCriteriaDAO.getRunId();
			if(list != null) {
				ResponseSetter.getResponseString(responseVO,StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, Util.toStringListJSONArray(list));
			}
		}catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional(readOnly = true)
	public void getMarketWatchGridCount(String runId, ResponseVO responseVO) throws ServiceException {
		try {
			Long count = this.replayCriteriaDAO.getMarketWatchGridCount(runId);
			if(count > 0) {
				ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, count);
			}else {
				ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional(readOnly = true)
	public void getMarketWatchGridData(String runId, int from, int recCount, ResponseVO responseVO) throws ServiceException {
		try {
			List<MktwtchSelectCriteriaVO> list = this.replayCriteriaDAO.getMarketWatchGridData(runId, from,recCount);
			if(list != null) {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, list);
			}else {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional(readOnly = true)
	public void getReplyCriteria(ResponseVO responseVO) throws ServiceException {
		try {
			List<MktwtchSelectCriteriaVO> list = this.replayCriteriaDAO.getReplyCriteria();
			if(list != null) {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, list);
			}else {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		}catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}


	@Transactional(readOnly = true)
	public void getSymbolSeriesCount(SCmSecurityMasterVO  sCmSecurityMasterVO, ResponseVO responseVO) throws ServiceException {
		try {
			Long count = this.replayCriteriaDAO.getSymbolSeriesCount(sCmSecurityMasterVO);
			if(count > 0) {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, count);
			}else {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional(readOnly = true)
	public void getSymbolSeriesData(SCmSecurityMasterVO  sCmSecurityMasterVO, ResponseVO responseVO) throws ServiceException {
		try {
			List<SCmSecurityMasterVO> list = this.replayCriteriaDAO.getSymbolSeriesData(sCmSecurityMasterVO);
			if(list != null) {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, list);
			}else {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	public void modifyReplayCriteria(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO, ResponseVO responseVO) throws ServiceException {
		try {

			boolean valFlag;
			valFlag = super.validate(mktwtchSelectCriteriaVO, "replayCriteria", responseVO);
			if(!valFlag)
				return;

			List<MktwtchSelectCriteriaVO> objList = this.replayCriteriaDAO.getDataFromDbForUpdate(mktwtchSelectCriteriaVO);
			if(objList != null && objList.get(0).equals(mktwtchSelectCriteriaVO)) {
				throw new ServiceException(StaticMsgConstants.NO_CHANGE_TO_SAVE);
			}
			this.replayCriteriaDAO.modifyReplayCriteria(mktwtchSelectCriteriaVO);
			ResponseSetter.getResponseString(responseVO,StaticConstants.SUCCESS_CODE, StaticMsgConstants.RECORD_MOD_SUCCESS, null);
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}


	public void modifyStatus(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO, ResponseVO responseVO) throws ServiceException {
		try {

			this.replayCriteriaDAO.modifyStatus(mktwtchSelectCriteriaVO);

			ResponseSetter.getResponseString(responseVO,StaticConstants.SUCCESS_CODE, StaticMsgConstants.STATUS_MOD_SUCCESS, null);
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}


	@SuppressWarnings("unchecked")
	@Transactional()
	public void pushMrRequestCache(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO, ResponseVO responseVO) throws ServiceException,ValidationException  {
		try{

			super.validate(mktwtchSelectCriteriaVO, initiateMktwtchSelectCriteriaVO.class);

			IgniteCache<Integer, MRRequestCache> igniteCache = (IgniteCache<Integer, MRRequestCache>) CacheManager.igniteMrRequest;
			if(igniteCache==null){
				ResponseSetter.getResponseString(responseVO,StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_CACHE_NOT_AVAILABLE);
			}else{				
				Integer mrKey = new Integer(mktwtchSelectCriteriaVO.getMwscrRunId());
				MRRequestCache mr = new MRRequestCache();
				mr.setMrReqRunId(mktwtchSelectCriteriaVO.getMwscrRunId());
				mr.setMrReqSymbol(mktwtchSelectCriteriaVO.getMwscrSymbol());
				mr.setMrReqSeries(mktwtchSelectCriteriaVO.getMwscrSeries());
				mr.setMrReqFromTime(mktwtchSelectCriteriaVO.getMwscrFromTime());
				mr.setMrReqToTime(mktwtchSelectCriteriaVO.getMwscrToTime());
				mr.setMrReqIndexName(mktwtchSelectCriteriaVO.getMwscrIndexName());
				//				mr.setMrReqStatus(StaticConstants.STRING_I);
				mktwtchSelectCriteriaVO.setMwscrStatus(StaticConstants.STRING_I);
				mr.setMrReqStatus(mktwtchSelectCriteriaVO.getMwscrStatus());
				mr.setMrReqPectAwayLTP(mktwtchSelectCriteriaVO.getMwscrPectAwayLtp());
				mr.setMrReqSLPectAwayLTP(mktwtchSelectCriteriaVO.getMwscrSlPectAwayLtp());
				mr.setMrReqLargeCxlQty(mktwtchSelectCriteriaVO.getMwscrLargeCxlQty());
				mr.setMrReqLargeUnexecutedQty(mktwtchSelectCriteriaVO.getMwscrLargeUnexecutedQty());
				mr.setMrReqStartSeqNum(StaticConstants.NUMBER_0);
				mr.setMrReqSegInd(StaticConstants.STRING_C);
				mr.setMrReqRunDate(Util.utilToSqlDate(mktwtchSelectCriteriaVO.getMwscrBussDate()));
				//mr.setMrReqUserNum(mktwtchSelectCriteriaVO.getMwscrUserNum());
				mr.setMrReqRequestDate(Util.utilToSqlDate(mktwtchSelectCriteriaVO.getMwscrRequestDate()));

				if(mktwtchSelectCriteriaVO.getMwscrBussDate().equals(CacheManager.businessDateVO.getBsdtCurrBussDate()))
					mktwtchSelectCriteriaVO.setMwscrCurrDayFlag(StaticConstants.STRING_Y);
				else
					mktwtchSelectCriteriaVO.setMwscrCurrDayFlag(StaticConstants.STRING_N);
				//mr.setMrReqCurrDayFlag(StaticConstants.STRING_N);
				mr.setMrReqCurrDayFlag(mktwtchSelectCriteriaVO.getMwscrCurrDayFlag());
				if(igniteCache.get(mrKey) == null ){
					igniteCache.put(mrKey, mr);
					ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS);
					this.modifyStatus(mktwtchSelectCriteriaVO, responseVO);
				}
			}
		}catch (Exception e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public void getStatusCache(Integer mwscrRunId, ResponseVO responseVO) throws ServiceException {
		try {
			IgniteCache<Integer, MRRequestCache> igniteCache = (IgniteCache<Integer, MRRequestCache>) CacheManager.igniteMrRequest;
			if(igniteCache==null){
				ResponseSetter.getResponseString(responseVO,StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_CACHE_NOT_AVAILABLE);
			}else{
				if( igniteCache.get(mwscrRunId)==null){
					ResponseSetter.getResponseString(responseVO,StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_CACHE_DATA_NOT_AVAILABLE);
				}else{
					MRRequestCache mrRequestCache =   igniteCache.get(mwscrRunId);
					ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE,StaticConstants.SUCCESS,mrRequestCache);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
	}
	/*public void modifyDeleteStatus(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) throws ServiceException {
		try {
			this.replayCriteriaDAO.modifyDeleteStatus(mktwtchSelectCriteriaVO);
			ResponseSetter.getResponseString(responseVO,StaticConstants.SUCCESS_CODE, StaticMsgConstants.STATUS_MOD_SUCCESS, null);
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}*/


	@Transactional
	public void addReplayCriteria(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO, ResponseVO responseVO) throws ServiceException, ValidationException {
		try {
			boolean valFlag;
			valFlag = super.validate(mktwtchSelectCriteriaVO, "replayCriteria", responseVO);
			if(!valFlag)
				return;
			//				List<MktwtchSelectCriteriaVO> dbRecordsList = this.replayCriteriaDAO.getDataFromDb(mktwtchSelectCriteriaVO);
			//				if(dbRecordsList != null) {
			//					throw new ServiceException(StaticMsgConstants.ERR_DATA_INTEGRITY);
			//				}
			this.replayCriteriaDAO.addReplayCriteria(mktwtchSelectCriteriaVO);
			ResponseSetter.getResponseString(responseVO,StaticConstants.SUCCESS_CODE, StaticMsgConstants.RECORD_ADD_SUCCESS, null);

		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}catch (Exception e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	public void getMinRunDate(ResponseVO responseVO) throws ServiceException {
		try {
			UadUserGroupVO uadUserGroup = this.replayCriteriaDAO.getUadUserGroup();
			if(uadUserGroup != null) {
				Date notallwdWrkngDays = this.replayCriteriaDAO.getWorkingDate(uadUserGroup);
				uadUserGroup.setFuncWorkingdate(notallwdWrkngDays);
			}
			ResponseSetter.getResponseString(responseVO,
					StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, uadUserGroup);
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	public boolean ValidateMaxRunDate(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) throws ServiceException {
		try {
			UadUserGroupVO uadUserGroup = this.replayCriteriaDAO.getUadUserGroup();
			if( uadUserGroup != null ) {
				Date notallwdWrkngDays = this.replayCriteriaDAO.getWorkingDate(uadUserGroup);
				uadUserGroup.setFuncWorkingdate(notallwdWrkngDays);

				Date bussDate = Util.getStringDate(Util.getDateString(mktwtchSelectCriteriaVO.getMwscrBussDate()));
				if(uadUserGroup.getFuncWorkingdate().after(bussDate) ){
					return true;
				}else if(uadUserGroup.getFuncWorkingdate().equals(bussDate)){
					return true;
				}else if(uadUserGroup.getFuncWorkingdate().before(bussDate) ){
					return false;
				}
			}
			ResponseSetter.getResponseString(response,
					StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, uadUserGroup);
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return true;
	}


	public List<SCmSecurityMasterVO> validateSymbolSeries(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) throws ServiceException{
		try {
			return this.replayCriteriaDAO.checkSeriesSymbol(mktwtchSelectCriteriaVO);
		} catch (RepositoryException ed) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, ed);
			throw new ServiceException(StaticMsgConstants.ERR_DATA_ACCESS, ed);
		}
	}

	public boolean validationHoliday(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) throws ServiceException{
		try {
			return this.replayCriteriaDAO.validationHoliday(mktwtchSelectCriteriaVO);
		} catch (RepositoryException ed) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, ed);
			throw new ServiceException(StaticMsgConstants.ERR_DATA_ACCESS, ed);
		}
	}

	public int checkLimit(Date bussDate) throws ServiceException{
		try {
			return this.replayCriteriaDAO.checkLimit(bussDate);
		} catch (RepositoryException ed) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, ed);
			throw new ServiceException(StaticMsgConstants.ERR_DATA_ACCESS, ed);
		}
	}

	@Transactional(readOnly = true)
	public void getQueryGridCount(Date mwscrBussDate, ResponseVO responseVO) throws ServiceException {
		try {
			Long count = this.replayCriteriaDAO.getQueryGridCount(mwscrBussDate);
			if(count > 0) {
				ResponseSetter.getResponseString(responseVO, StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, count);
			}else {
				ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Transactional(readOnly = true)
	public void getQueryGridData(Date mwscrBussDate, int from, int recCount, ResponseVO responseVO) throws ServiceException {
		try {
			List<MktwtchSelectCriteriaVO> list = this.replayCriteriaDAO.getQueryGridData(mwscrBussDate, from,recCount);
			if(list != null) {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, list);
			}else {
				ResponseSetter.getResponseString(responseVO,
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_NO_DATA_FOUND);
			}
		} catch (RepositoryException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}


}