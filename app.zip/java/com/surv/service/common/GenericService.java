package com.surv.service.common;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ValidationException;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;

import com.surv.constant.StaticConstants;
import com.surv.constant.StaticMsgConstants;
import com.surv.exception.ServiceException;
import com.surv.json.ResponseSetter;
import com.surv.json.ResponseVO;
import com.surv.utility.Logger;

public abstract class GenericService {

	@Autowired
	private Validator validator;

	public <T> void validate(T object) throws ServiceException {
		try {
			Set<ConstraintViolation<T>> violations = validator.validate(object);
			if (violations.iterator().hasNext()) {
				ConstraintViolation<T> constraintViolation = violations.iterator().next();
				throw new ServiceException(constraintViolation.getMessage());
			}
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			throw new ServiceException(e.getLocalizedMessage());
		} catch (ValidationException e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_TECHNICAL, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_TECHNICAL, e);
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR, e);
		}
	}

	public <T> void validate(T object, Class<?> group) throws ServiceException {
		try {
			Set<ConstraintViolation<T>> violations = validator.validate(object, group);
			if (violations.iterator().hasNext()) {
				ConstraintViolation<T> constraintViolation = violations.iterator().next();
				throw new ServiceException(constraintViolation.getMessage());
			}
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			throw new ServiceException(e.getLocalizedMessage());
		} catch (ValidationException e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_TECHNICAL, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_TECHNICAL, e);
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR, e);
		}
	}
	
	public <T> boolean validate(T obj, String modName, ResponseVO responseVO) throws ServiceException {

		try {

			//Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
			Set<ConstraintViolation<T>> violations = validator.validate(obj);

			if (violations.iterator().hasNext()) {

				ConstraintViolation<T> constraintViolation = violations.iterator().next();
				String errMsg = constraintViolation.getMessage();
				ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, errMsg);
				return false;
			}
		} catch (ValidationException e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_TECHNICAL, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_TECHNICAL, e);
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR, e);
		}
		
		return true;

	}

}