package com.surv.dao.common;

import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.sql.DataSource;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import com.surv.constant.StaticMsgConstants;
import com.surv.exception.RepositoryException;
import com.surv.utility.Logger;

@SuppressWarnings({ "unchecked", "rawtypes" })
public abstract class GenericRepository {

	@Autowired 
	private DataSource dataSource;

	private NamedParameterJdbcTemplate jdbcTemplate;

	@PostConstruct
	private void initialize() {
		jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	public <T> T find(String sql, Class className) throws RepositoryException {
		try {
			return (T) jdbcTemplate.query(sql, getClassResultSetExtractor(className));
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	public <T> T find(String sql, Map<String, Object> criteriaMap) throws RepositoryException {
		try {
			return (T) jdbcTemplate.query(sql, new MapSqlParameterSource().addValues(criteriaMap), getObjectResultSetExtractor());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	public <T> T find(String sql, Map<String, Object> criteriaMap, Class className) throws RepositoryException {
		try {
			return (T) jdbcTemplate.query(sql, new MapSqlParameterSource().addValues(criteriaMap), getClassResultSetExtractor(className));
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}
	
	public <T> T find(String sql) throws RepositoryException {
		try {
			return (T) jdbcTemplate.query(sql, getObjectResultSetExtractor());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}
	
	public <T> T findByQueryPaged(String sql, Map<String, Object> criteriaMap) throws RepositoryException {
		try {
			sql += " LIMIT :RECCOUNT OFFSET :FROM";
			return (T) jdbcTemplate.query(sql, new MapSqlParameterSource().addValues(criteriaMap), getObjectResultSetExtractor());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	public <T> T findByQueryPaged(String sql) throws RepositoryException {
		try {
			sql += " LIMIT :RECCOUNT OFFSET :FROM";
			return (T) jdbcTemplate.query(sql, getObjectResultSetExtractor());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}
	
	public <T> T findByQueryPaged(String sql, Map<String, Object> criteriaMap, Class className) throws RepositoryException {
		try {
			sql += " LIMIT :RECCOUNT OFFSET :FROM";
			return (T) jdbcTemplate.query(sql, new MapSqlParameterSource().addValues(criteriaMap), getClassResultSetExtractor(className));
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	public void add(Object object) throws RepositoryException {
		try {

			Assert.notNull(object, "Entity can't be null.");

			Class className = object.getClass();

			String tableName = null;
			if (className.isAnnotationPresent(Table.class)) {
				Table table = object.getClass().getAnnotation(Table.class);
				tableName = table.name().toUpperCase();
			}

			StringBuilder valueField = new StringBuilder();
			StringBuilder columnField = new StringBuilder();

			MapSqlParameterSource params = new MapSqlParameterSource();

			Field[] fields = object.getClass().getDeclaredFields();
			for (Field field : fields) {
				if (field.isAnnotationPresent(Column.class)) {
					Column column = field.getAnnotation(Column.class);
					columnField.append(column.name().toUpperCase() + ", ");
					valueField.append(":" + field.getName().toUpperCase() + ", ");
					params.addValue(field.getName().toUpperCase(), BeanUtils.getProperty(object, field.getName()), getSqlType(field));
				}
			}

			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO ");
			sql.append(tableName + " (");
			sql.append(columnField.toString().substring(0, columnField.length() - 2));
			sql.append(") VALUES (");
			sql.append(valueField.toString().substring(0, valueField.length() - 2));
			sql.append(")");

			jdbcTemplate.update(sql.toString(), params);

		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	public void batchAdd(List<?> dataList) throws Exception {
		try {
			Assert.notNull(dataList, "Entity can't be null.");

			Object object = dataList.get(0);
			Class className = dataList.get(0).getClass();

			String tableName = null;
			if (className.isAnnotationPresent(Table.class)) {
				Table table = object.getClass().getAnnotation(Table.class);
				tableName = table.name().toUpperCase();
			}

			StringBuilder valueField = new StringBuilder();
			StringBuilder columnField = new StringBuilder();

			Field[] fields = object.getClass().getDeclaredFields();
			for (Field field : fields) {
				if (field.isAnnotationPresent(Column.class)) {
					Column column = field.getAnnotation(Column.class);
					columnField.append(column.name().toUpperCase() + ", ");
					valueField.append(":" + field.getName().toUpperCase() + ", ");
				}
			}

			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO ");
			sql.append(tableName + " (");
			sql.append(columnField.toString().substring(0, columnField.length() - 2));
			sql.append(") VALUES (");
			sql.append(valueField.toString().substring(0, valueField.length() - 2));
			sql.append(")");

			List<MapSqlParameterSource> parameterList = new ArrayList<>();
			for (Object data : dataList) {
				Field[] field = data.getClass().getDeclaredFields();
				MapSqlParameterSource params = new MapSqlParameterSource();
				for (Field fld : field) {
					if (fld.isAnnotationPresent(Column.class)) {
						params.addValue(fld.getName().toUpperCase(), BeanUtils.getProperty(data, fld.getName()), getSqlType(fld));
					}
				}
				parameterList.add(params);
			}

			jdbcTemplate.batchUpdate(sql.toString(), parameterList.toArray(new MapSqlParameterSource[dataList.size()]));

		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	public int update(String sql, Map<String, Object> criteriaMap) throws RepositoryException {
		try {
			return jdbcTemplate.update(sql, new MapSqlParameterSource().addValues(criteriaMap));
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	public int batchUpdate(String sql, List<Map<String, Object>> dataList) throws Exception {
		try {
			Assert.notNull(dataList, StaticMsgConstants.ERR_TECHNICAL);

			List<MapSqlParameterSource> list = new ArrayList<>();
			for (Map<String, Object> map : dataList) {
				MapSqlParameterSource params = new MapSqlParameterSource();
				for(Entry<String, Object> entry : map.entrySet()) {
					params.addValue(entry.getKey(), entry.getValue());
				}
				list.add(params);
			}

			int[] count = jdbcTemplate.batchUpdate(sql, list.toArray(new MapSqlParameterSource[dataList.size()]));

			int counter = 0;
			if(count != null && count.length > 0) {
				for(int i = 0; i < count.length; i++) {
					counter += count[i];
				}
			}

			return counter;

		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	public int batchUpdateByObject(String sql, List<?> dataList) throws RepositoryException {
		try {

			return 0;
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	public int delete(String sql, Map<String, Object> criteriaMap) throws RepositoryException {
		try {
			return jdbcTemplate.update(sql, new MapSqlParameterSource().addValues(criteriaMap));
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	public int batchDelete(String sql, List<Map<String, Object>> dataList) throws RepositoryException {
		try {
			Assert.notNull(dataList, StaticMsgConstants.ERR_TECHNICAL);

			List<MapSqlParameterSource> list = new ArrayList<>();
			for (Map<String, Object> map : dataList) {
				MapSqlParameterSource params = new MapSqlParameterSource();
				for(Entry<String, Object> entry : map.entrySet()) {
					params.addValue(entry.getKey(), entry.getValue());
				}
				list.add(params);
			}

			int[] count = jdbcTemplate.batchUpdate(sql, list.toArray(new MapSqlParameterSource[dataList.size()]));

			int counter = 0;
			if(count != null && count.length > 0) {
				for(int i = 0; i < count.length; i++) {
					counter += count[i];
				}
			}

			return counter;

		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	private static synchronized<T> ResultSetExtractor<List<T>> getClassResultSetExtractor(final Class className){
		ResultSetExtractor<List<T>> resultSetExtractor = new ResultSetExtractor<List<T>>() {
			@Override
			public List<T> extractData(ResultSet rs){
				List<T> list = null;
				try {
					list =  mapRersultSetToObject(rs, className);
				} catch (Exception e) {
					Logger.EXCEPTION.error("", e.getMessage());
				}
				return list;
			}
		};
		return resultSetExtractor;
	}

	private static synchronized<T> List<T> mapRersultSetToObject(ResultSet rs, Class outputClass) throws RepositoryException  {
		try {
			Assert.notNull(rs, StaticMsgConstants.ERR_TECHNICAL);
			if (!outputClass.isAnnotationPresent(Entity.class)) {
				throw new RepositoryException(StaticMsgConstants.ERR_TECHNICAL);
			}
			List<T> outputList = null;
			ResultSetMetaData rsmd = rs.getMetaData();
			Field[] fields = outputClass.getDeclaredFields();
			while (rs.next()) {
				T bean = (T) outputClass.newInstance();
				for (int iterator = 0; iterator < rsmd.getColumnCount(); iterator++) {
					String columnName = rsmd.getColumnName(iterator + 1);
					Object columnValue = rs.getObject(iterator + 1);
					for (Field field : fields) {
						if (field.isAnnotationPresent(Column.class)) {
							Column column = field.getAnnotation(Column.class);
							if (column.name().equalsIgnoreCase(columnName) && columnValue != null) {
								BeanUtils.setProperty(bean, field.getName(), columnValue);
								break;
							}
						}else if (field.isAnnotationPresent(Transient.class)) {
							if (field.getName().equalsIgnoreCase(columnName) && columnValue != null) {
								BeanUtils.setProperty(bean, field.getName(), columnValue);
								break;
							}
						}
					}
				}
				if (outputList == null) {
					outputList = new ArrayList<T>();
				}
				outputList.add(bean);
			}
			return outputList;
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	private static synchronized<T> ResultSetExtractor<List<T>> getObjectResultSetExtractor(){
		ResultSetExtractor<List<T>> resultSetExtractor = new ResultSetExtractor<List<T>>() {

			@Override
			public List<T> extractData(ResultSet rs) throws SQLException, DataAccessException {
				List<T> outputList = new ArrayList<>();

				if(rs != null) {
					ResultSetMetaData rsmd = rs.getMetaData();
					Object[] objectArray = null;
					while(rs.next()){
						objectArray = new Object[rsmd.getColumnCount()];
						for (int iterator = 0; iterator < rsmd.getColumnCount(); iterator++) {
							objectArray[iterator] = rs.getObject(iterator + 1);
						}
						outputList.add((T) objectArray);
					}
				}
				return outputList;
			}

		};
		return resultSetExtractor;
	}

	private static synchronized int getSqlType(Field field) throws RepositoryException{
		try {
			int sqlType = 0;
			switch (field.getType().getSimpleName().toUpperCase()) {
			case "LONG":
				sqlType = Types.NUMERIC;
				break;
			case "STRING":
				sqlType = Types.VARCHAR;
				break;
			case "DATE":
				sqlType = Types.DATE;
				break;
			case "INT":
				sqlType = Types.NUMERIC;
				break;	
			case "INTEGER":
				sqlType = Types.NUMERIC;
				break;		
//			case "DOUBLE":
//				sqlType=Types.NUMERIC;
//				break;
			case "TIME":
				sqlType = Types.TIME;
				break;
			case "TIMESTAMP":
				sqlType = Types.TIMESTAMP;
				break;
			case "DOUBLE":
				sqlType = Types.DOUBLE;
				break;
			}
			return sqlType;
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_DATA_ACCESS, e.getMessage());
			throw new RepositoryException(StaticMsgConstants.ERR_DATA_ACCESS, e);
		}
	}

	public Date callFunctionWithParamater(String functionName,Map<String, Object> criteriaMap) throws RepositoryException {
		//		EntityManager entityManager = emf.createEntityManager();
		try {
			functionName = functionName+"(";
			if (criteriaMap != null) {
				Iterator<?> entries = criteriaMap.entrySet().iterator();
				while (entries.hasNext()) {
					Entry<?, ?> thisEntry = (Entry<?, ?>) entries.next();
					Object value = thisEntry.getValue();
					functionName = 	functionName.concat(value.toString());
					functionName =	functionName.concat(",");
				}
			}
			functionName = functionName.substring(0,functionName.length()-1);
			functionName =  functionName.concat(")");
			//Query query = entityManager.createNativeQuery(sql);
			//return (Date) query.getSingleResult();
			return null;
		} catch (Exception e) {
			Logger.EXCEPTION.error("", e.getMessage());
			throw new RepositoryException(e);
		} finally {
			//			if (entityManager.isOpen())
			//				entityManager.close();
		}
	}

}