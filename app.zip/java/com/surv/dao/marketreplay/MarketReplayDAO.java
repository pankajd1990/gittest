package com.surv.dao.marketreplay;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.query.QueryCursor;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.surv.cache.CacheManager;
import com.surv.config.SqlConfig;
import com.surv.constant.StaticConstants;
import com.surv.constant.StaticMsgConstants;
import com.surv.dao.common.GenericRepository;
import com.surv.entity.marketreplay.EventVO;
import com.surv.entity.marketreplay.MarketReplayVO;
import com.surv.entity.marketreplay.MktwtchHighlightVO;
import com.surv.exception.RepositoryException;
import com.surv.exception.ServiceException;
import com.surv.json.ResponseSetter;
import com.surv.json.ResponseVO;
import com.surv.utility.Logger;
import com.surv.utility.MasterUtil;
import com.surv.utility.Util;

@Repository("marketReplayDAO")
public class MarketReplayDAO extends GenericRepository {

	@Autowired
	private SqlConfig sqlConfig;
	
	@Autowired
	@Qualifier(value = "responseVO")
	private ResponseVO responseVO;

	public MktwtchHighlightVO getHighlightCondition(MktwtchHighlightVO mktwtchHighlightVO) throws RepositoryException {
		String hql = this.sqlConfig.getQuery("GETHIGHLIGHTCONDITION");

		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MKWHG_RUN_ID", mktwtchHighlightVO.getMkwhgRunId());

		List<MktwtchHighlightVO> list = this.find(hql, criteriaMap, MktwtchHighlightVO.class);
		return list != null && !list.isEmpty() ? list.get(0) : null;
	}

	public void submitHighlightCondition(MktwtchHighlightVO mktwtchHighlightVO) throws RepositoryException {
		Date date = new Date();

		MktwtchHighlightVO highlightVO = this.getHighlightCondition(mktwtchHighlightVO);
		if(highlightVO == null) {
			mktwtchHighlightVO.setMkwhgCrtBy(Util.getLogonUserId());
			mktwtchHighlightVO.setMkwhgCrtDate(Util.dateToSqlDateOnly(date));
			mktwtchHighlightVO.setMkwhgUpdtBy(Util.getLogonUserId());
			mktwtchHighlightVO.setMkwhgUpdtDate(Util.dateToSqlDateOnly(date));
			mktwtchHighlightVO.setMkwhgRunDate(Util.dateToSqlDateOnly(mktwtchHighlightVO.getMkwhgRunDate()));
			super.add(mktwtchHighlightVO);
			return;
		}

		String hql = this.sqlConfig.getQuery("SUBMITHIGHLIGHTCONDITION");

		Map<String,Object> criteriaMap= new HashMap<>();
		criteriaMap.put("MKWHG_BROKER", mktwtchHighlightVO.getMkwhgBroker());
		criteriaMap.put("MKWHG_DEALER", mktwtchHighlightVO.getMkwhgDealer());
		criteriaMap.put("MKWHG_ACC_NO", mktwtchHighlightVO.getMkwhgAccNo());
		criteriaMap.put("MKWHG_PAN", mktwtchHighlightVO.getMkwhgPan());
		criteriaMap.put("MKWHG_NNF_ID", mktwtchHighlightVO.getMkwhgNnfId());
		criteriaMap.put("MKWHG_ORDER_NO", mktwtchHighlightVO.getMkwhgOrderNo()); 
		criteriaMap.put("MKWHG_LST_UNEXEC_QTY", mktwtchHighlightVO.getMkwhgLstUnexecQty());
		criteriaMap.put("MKWHG_LST_CANCELLED_QTY", mktwtchHighlightVO.getMkwhgLstCancelledQty());
		criteriaMap.put("MKWHG_PRCNTG_AWAY_LTP", mktwtchHighlightVO.getMkwhgPrcntgAwayLtp());
		criteriaMap.put("MKWHG_PRCNTG_AWAY_LTP_SL", mktwtchHighlightVO.getMkwhgPrcntgAwayLtpSl());
		criteriaMap.put("MKWHG_UPDT_BY", Util.getLogonUserId());
		criteriaMap.put("MKWHG_UPDT_DATE", date);
		criteriaMap.put("MKWHG_RUN_ID", mktwtchHighlightVO.getMkwhgRunId());
		criteriaMap.put("MKWHG_USER_NUM", mktwtchHighlightVO.getMkwhgUserNum());

		super.update(hql, criteriaMap);
	}
	
	public Map<String, Object> playMarketReplaySocket(Integer runId,Integer mrSeqNmbr,Integer lastSeqNmbr,Integer prevForwardFlag,Integer gotoStartSeqNmbr) throws ServiceException {
		try {
			
			String activityQuery;
			IgniteCache<?, ?> activityCache = CacheManager.igniteCache;

			if(activityCache == null) {
				ResponseSetter.getResponseString(responseVO, 
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERROR_IGNITE_CACHE_NULL, null);
				return null;
			}
			if(prevForwardFlag < 0) {
				activityQuery = this.sqlConfig.getCacheQuery("PREPLAYMARKETREPLAY");
			}else {
				activityQuery = this.sqlConfig.getCacheQuery("PLAYMARKETREPLAY");
			}
			Map<String, Object> activityMap = new HashMap<>();
			activityMap.put("MREVENTRUNID", runId);
			activityMap.put("MRSEQNMBR", mrSeqNmbr);
			activityMap.put("LASTSEQNMBR", lastSeqNmbr);
			activityMap.put("GOTOSTARTSEQNMBR", gotoStartSeqNmbr);

			SqlFieldsQuery activitySqlQuery = new SqlFieldsQuery(MasterUtil.queryGenerater(activityQuery, activityMap));
			List<MarketReplayVO> listMarketData = new ArrayList<>();

		
			try (QueryCursor<List<?>> cursor = activityCache.query(activitySqlQuery)) {
				for (List<?> record : cursor) {
					listMarketData.add(new MarketReplayVO().generateMarketReplayData(record.toArray()));
				}
			}
			IgniteCache<?, ?> eventCache = CacheManager.igniteEventCache;

			if(eventCache == null) {
				ResponseSetter.getResponseString(responseVO, 
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERROR_IGNITE_CACHE_NULL, null);
				return null;
			}
			List<EventVO> listEventData = new ArrayList<>();
			if(listMarketData.size() > 0){
				String eventQuery = this.sqlConfig.getCacheQuery("GETDATAFROMEVENTCACHE");

				Map<String, Object> eventMap = new HashMap<>();

				eventMap.put("MREVENTRUNID", runId);
				eventMap.put("FROMTIME", Util.dateToSqlDate(listMarketData.get(0).getMrRecordTime()));
				eventMap.put("TOTIME", Util.dateToSqlDate(listMarketData.get(listMarketData.size()-1).getMrRecordTime()));
				
				SqlFieldsQuery eventSqlQuery = new SqlFieldsQuery(MasterUtil.queryGenerater(eventQuery, eventMap));
				try (QueryCursor<List<?>> cursor = eventCache.query(eventSqlQuery)) {
					for (List<?> record : cursor) {
						listEventData.add(new EventVO(record.toArray()));
					}
				}
			}

			Map<String, Object> map = new HashMap<>();
			map.put("Event", listEventData);
			map.put("Activity", listMarketData);
			Logger.REQ_RES.info("Response : listMarketData size :"+listMarketData.size()+ "listEventData size :"+listEventData.size());
			return map;
		} catch (Exception e) {
			e.printStackTrace();
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
	}
	
	public Integer goToMarketReplay(Integer mrSeqNmbr, String mrRecordTimeString, String mrPan, Long mrOrderNmbr, Long mrFillNmbr, Integer runId) throws ServiceException {
		String goToMarketReplayQuery = null;
		Integer goToMarketReplay = null;
		try {
			IgniteCache<?, ?> activityCache = CacheManager.igniteCache;
			if(activityCache == null) {
				ResponseSetter.getResponseString(responseVO, 
						StaticConstants.FAILURE_CODE, StaticMsgConstants.ERROR_IGNITE_CACHE_NULL, null);
				return null;
			}
			Map<String, Object> map = new HashMap<>();
			map.put("MRSEQNMBR", mrSeqNmbr);
			map.put("MRRUNID", runId);
			
			if (mrRecordTimeString != null && mrRecordTimeString.length() > 0 ) {
				goToMarketReplayQuery = this.sqlConfig.getCacheQuery("GOTOMRRECORDTIME");	
				map.put("MRRECORDTIME", mrRecordTimeString);
			}
			
			if (mrPan != null && mrPan.length() > 0 ) {
				goToMarketReplayQuery = this.sqlConfig.getCacheQuery("GOTOMRPAN");	
				map.put("MRPAN", mrPan);
			}
			
			if (mrOrderNmbr != null) {
				goToMarketReplayQuery = this.sqlConfig.getCacheQuery("GOTOMRORDERNMBR");	
				map.put("MRORDERNMBR", mrOrderNmbr);
			}
			
			if (mrFillNmbr != null) {
				goToMarketReplayQuery = this.sqlConfig.getCacheQuery("GOTOMRFILLNMBR");	
				map.put("MRFILLNMBR", mrFillNmbr);
			}

			SqlFieldsQuery gotoSqlQuery = new SqlFieldsQuery(MasterUtil.queryGenerater(goToMarketReplayQuery, map));

			try (QueryCursor<List<?>> cursor = activityCache.query(gotoSqlQuery)) {
				for (List<?> record : cursor) {
					if(!record.isEmpty())
						goToMarketReplay = (Integer)record.get(0);
				}
			}
			return goToMarketReplay;
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			throw new ServiceException(StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
	}
}