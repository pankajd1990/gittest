package com.surv.dao.marketreplay;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.surv.config.SqlConfig;
import com.surv.dao.common.GenericRepository;
import com.surv.entity.marketreplay.BusinessDateVO;
import com.surv.exception.RepositoryException;

@Repository("businessDateDAO")
public class BusinessDateDAO extends GenericRepository {

	@Autowired
	private SqlConfig sqlConfig;

	public BusinessDateVO getBusinessDateDetails() throws RepositoryException {
		String sql = sqlConfig.getQuery("GETBUSINESSPARAMETERS1");
		List<BusinessDateVO> list = super.find(sql, BusinessDateVO.class);
		return !list.isEmpty() ? list.get(0) : null;
	}

}