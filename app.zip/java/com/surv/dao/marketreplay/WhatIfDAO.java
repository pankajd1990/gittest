package com.surv.dao.marketreplay;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.surv.cache.CacheManager;
import com.surv.config.SqlConfig;
import com.surv.constant.StaticConstants;
import com.surv.constant.StaticMsgConstants;
import com.surv.dao.common.GenericRepository;
import com.surv.entity.marketreplay.SetOrderFilterVO;
import com.surv.entity.marketreplay.WhatifOrderFilterVO;
import com.surv.entity.marketreplay.WhatifSelectCriteria;
import com.surv.exception.RepositoryException;
import com.surv.exception.ServiceException;
import com.surv.exception.ValidationException;
import com.surv.utility.Util;

@Repository("whatIfDAO")
public class WhatIfDAO extends GenericRepository {

	@Autowired
	private SqlConfig sqlConfig;

	public List<String> getAllRunId() throws RepositoryException {
		String sql = sqlConfig.getQuery("GETALLRUNID");


		List<String> list = super.find(sql);
		return list != null && !list.isEmpty() ? list : null;
	}

	public int searchRunCount(String runId) throws RepositoryException{

		List<Object[]> listObject = new ArrayList<>();
		if (runId != null) {
			String hql = this.sqlConfig.getQuery("SEARCHRUNIDDATA");

			Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("WHSCR_RUN_ID", runId);

			listObject = this.find(hql, criteriaMap);
		}
		return listObject.size();
	}

	public List<SetOrderFilterVO> searchRunIdData(String runId, int from, int recCount) throws RepositoryException {
		try{
			Map<String, Object> criteriaMap = new HashMap<>();


			if(runId!=null){
				String hql = sqlConfig.getQuery("SEARCHRUNIDDATA");
				hql += " LIMIT :RECCOUNT OFFSET :FROM";


				criteriaMap.put("WHSCR_RUN_ID", runId);
				criteriaMap.put("FROM", from);
				criteriaMap.put("RECCOUNT", recCount);

				List<Object[]> list = super.find(hql, criteriaMap);

				if (list != null && !list.isEmpty()) {
					List<SetOrderFilterVO> listOut = new ArrayList<>();
					for (Object[] object : list) {
						listOut.add(new SetOrderFilterVO(object));
					}
					return listOut;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}

	public void addNewOrd(WhatifOrderFilterVO whatifOrderFilterVO) throws RepositoryException, ServiceException {


		Date date = new Date();

		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT nextval('ordfilters_seq')");
		List<Object[]> filterNo = super.find(sql.toString());

		whatifOrderFilterVO.setWhatifFilterNumber(Integer.parseInt((filterNo.get(0)[0]).toString()));
		whatifOrderFilterVO.setWhatifRunId(whatifOrderFilterVO.getWhatifRunId());
		whatifOrderFilterVO.setWhatifFilterType(whatifOrderFilterVO.getWhatifFilterType());
		whatifOrderFilterVO.setWhatifSeqNumber(whatifOrderFilterVO.getWhatifSeqNumber());
		whatifOrderFilterVO.setWhatifOrderNumber(Long.parseLong(StaticConstants.NUMBER_0+""));
		whatifOrderFilterVO.setWhatifPriceadjSign(whatifOrderFilterVO.getWhatifPriceadjSign());
		whatifOrderFilterVO.setWhatifPriceadjVal(whatifOrderFilterVO.getWhatifPriceadjVal());
		whatifOrderFilterVO.setWhatifMktType(whatifOrderFilterVO.getWhatifMktType());
		whatifOrderFilterVO.setWhatifBuysell(whatifOrderFilterVO.getWhatifBuysell());
		whatifOrderFilterVO.setWhatifOrdType(whatifOrderFilterVO.getWhatifOrdType());
		whatifOrderFilterVO.setWhatifLimitPrice(whatifOrderFilterVO.getWhatifLimitPrice());
		whatifOrderFilterVO.setWhatifTriggerPrice(whatifOrderFilterVO.getWhatifTriggerPrice());
		whatifOrderFilterVO.setWhatifOrdValidity(whatifOrderFilterVO.getWhatifOrdValidity());
		whatifOrderFilterVO.setWhatifOrdQty(whatifOrderFilterVO.getWhatifOrdQty());
		whatifOrderFilterVO.setWhatifOrdDisclosedQty(whatifOrderFilterVO.getWhatifOrdDisclosedQty());
		whatifOrderFilterVO.setWhatifProcliType(whatifOrderFilterVO.getWhatifProcliType());
		whatifOrderFilterVO.setWhatifAccountCode(whatifOrderFilterVO.getWhatifAccountCode());
		whatifOrderFilterVO.setWhatifClientPanid(whatifOrderFilterVO.getWhatifClientPanid());
		whatifOrderFilterVO.setWhatifTmCode(whatifOrderFilterVO.getWhatifTmCode());
		whatifOrderFilterVO.setWhatifBranchId(whatifOrderFilterVO.getWhatifBranchId());
		whatifOrderFilterVO.setWhatifDealerId(whatifOrderFilterVO.getWhatifDealerId());
		whatifOrderFilterVO.setWhatifNnfId(whatifOrderFilterVO.getWhatifNnfId());
		whatifOrderFilterVO.setWhatifAlgoId(whatifOrderFilterVO.getWhatifAlgoId());
		whatifOrderFilterVO.setWhatifAlgoCategory(whatifOrderFilterVO.getWhatifAlgoCategory());
		whatifOrderFilterVO.setWhatifCrtBy(Util.getLogonUserId());
		whatifOrderFilterVO.setWhatifCrtDate(Util.dateToSqlDate(date));
		whatifOrderFilterVO.setWhatifUpdBy(Util.getLogonUserId());
		whatifOrderFilterVO.setWhatifUpdDate(Util.dateToSqlDate(date));
		whatifOrderFilterVO.setWhatifPreopenInd(whatifOrderFilterVO.getWhatifPreopenInd());
		whatifOrderFilterVO.setWhatifRunSeqNumber(whatifOrderFilterVO.getWhatifRunSeqNumber());

		super.add(whatifOrderFilterVO);
	}

	public void addModOrd(WhatifOrderFilterVO whatifOrderFilterVO) throws RepositoryException, ServiceException {

		Date date = new Date();

		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT nextval('ordfilters_seq')");
		List<Object[]> filterNo = super.find(sql.toString());

		whatifOrderFilterVO.setWhatifFilterNumber(Integer.parseInt((filterNo.get(0)[0]).toString()));
		whatifOrderFilterVO.setWhatifRunId(whatifOrderFilterVO.getWhatifRunId());
		whatifOrderFilterVO.setWhatifFilterType(whatifOrderFilterVO.getWhatifFilterType());
		whatifOrderFilterVO.setWhatifSeqNumber(whatifOrderFilterVO.getWhatifSeqNumber());
		whatifOrderFilterVO.setWhatifOrderNumber(whatifOrderFilterVO.getWhatifOrderNumber());
		whatifOrderFilterVO.setWhatifPriceadjSign(whatifOrderFilterVO.getWhatifPriceadjSign());
		whatifOrderFilterVO.setWhatifPriceadjVal(whatifOrderFilterVO.getWhatifPriceadjVal());
		whatifOrderFilterVO.setWhatifOrdType(whatifOrderFilterVO.getWhatifOrdType());
		whatifOrderFilterVO.setWhatifLimitPrice(whatifOrderFilterVO.getWhatifLimitPrice());
		whatifOrderFilterVO.setWhatifTriggerPrice(whatifOrderFilterVO.getWhatifTriggerPrice());
		whatifOrderFilterVO.setWhatifOrdValidity(whatifOrderFilterVO.getWhatifOrdValidity());
		whatifOrderFilterVO.setWhatifOrdQty(whatifOrderFilterVO.getWhatifOrdQty());
		whatifOrderFilterVO.setWhatifOrdDisclosedQty(whatifOrderFilterVO.getWhatifOrdDisclosedQty());
		whatifOrderFilterVO.setWhatifProcliType(whatifOrderFilterVO.getWhatifProcliType());
		whatifOrderFilterVO.setWhatifAccountCode(whatifOrderFilterVO.getWhatifAccountCode());
		whatifOrderFilterVO.setWhatifClientPanid(whatifOrderFilterVO.getWhatifClientPanid());
		whatifOrderFilterVO.setWhatifBranchId(whatifOrderFilterVO.getWhatifBranchId());
		whatifOrderFilterVO.setWhatifNnfId(whatifOrderFilterVO.getWhatifNnfId());
		whatifOrderFilterVO.setWhatifAlgoId(whatifOrderFilterVO.getWhatifAlgoId());
		whatifOrderFilterVO.setWhatifAlgoCategory(whatifOrderFilterVO.getWhatifAlgoCategory());
		whatifOrderFilterVO.setWhatifCrtBy(Util.getLogonUserId());
		whatifOrderFilterVO.setWhatifCrtDate(Util.dateToSqlDate(date));
		whatifOrderFilterVO.setWhatifUpdBy(Util.getLogonUserId());
		whatifOrderFilterVO.setWhatifUpdDate(Util.dateToSqlDate(date));
		super.add(whatifOrderFilterVO);
	}

	public void addRemoveOrd(WhatifOrderFilterVO whatifOrderFilterVO) throws RepositoryException, ServiceException {


		Date date = new Date();

		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT nextval('ordfilters_seq')");
		List<Object[]> filterNo = super.find(sql.toString());

		whatifOrderFilterVO.setWhatifFilterNumber(Integer.parseInt((filterNo.get(0)[0]).toString()));
		whatifOrderFilterVO.setWhatifRunId(whatifOrderFilterVO.getWhatifRunId());
		whatifOrderFilterVO.setWhatifFilterType(whatifOrderFilterVO.getWhatifFilterType());
		whatifOrderFilterVO.setWhatifSeqNumber(whatifOrderFilterVO.getWhatifSeqNumber());
		whatifOrderFilterVO.setWhatifPriceadjSign(whatifOrderFilterVO.getWhatifPriceadjSign());
		whatifOrderFilterVO.setWhatifPriceadjVal(whatifOrderFilterVO.getWhatifPriceadjVal());
		whatifOrderFilterVO.setWhatifCrtBy(Util.getLogonUserId());
		whatifOrderFilterVO.setWhatifCrtDate(Util.dateToSqlDate(date));
		whatifOrderFilterVO.setWhatifUpdBy(Util.getLogonUserId());
		whatifOrderFilterVO.setWhatifUpdDate(Util.dateToSqlDate(date));
		super.add(whatifOrderFilterVO);
	}

	public WhatifOrderFilterVO getFilterDetailsByFilterNum(Integer filterNum) throws RepositoryException {
		String hql = this.sqlConfig.getQuery("GETFILTERDETAILSBYFILTERNUM");

		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("WHATIF_FILTER_NUMBER", filterNum);

		List<WhatifOrderFilterVO> list = this.find(hql, criteriaMap,WhatifOrderFilterVO.class);
		return list != null && !list.isEmpty() ? list.get(0) : null;
	}

	public void ModNewOrd(WhatifOrderFilterVO whatifOrderFilterVO) throws RepositoryException, ValidationException {

		WhatifOrderFilterVO oldOrderFilterVO = this.getFilterDetailsByFilterNum(whatifOrderFilterVO.getWhatifFilterNumber());
		if(oldOrderFilterVO == null) {
			throw new ValidationException(StaticMsgConstants.OLD_RECORD_NOT_FOUND);
		}

		if(oldOrderFilterVO.equals(whatifOrderFilterVO)) {
			throw new ValidationException(StaticMsgConstants.NO_CHANGE_TO_SAVE);
		}

		String hql = this.sqlConfig.getQuery("MODIFYNEWORDFILTERDETAIL");

		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("WHATIF_FILTER_NUMBER", whatifOrderFilterVO.getWhatifFilterNumber());
		criteriaMap.put("WHATIF_SEQ_NUMBER", whatifOrderFilterVO.getWhatifSeqNumber());
		//	criteriaMap.put("whatif_order_number", whatifOrderFilterVO.getWhatifOrderNumber());
		criteriaMap.put("WHATIF_PRICEADJ_SIGN", whatifOrderFilterVO.getWhatifPriceadjSign());
		criteriaMap.put("WHATIF_PRICEADJ_VAL", whatifOrderFilterVO.getWhatifPriceadjVal());
		criteriaMap.put("WHATIF_MKT_TYPE", whatifOrderFilterVO.getWhatifMktType());
		criteriaMap.put("WHATIF_BUYSELL", whatifOrderFilterVO.getWhatifBuysell());
		criteriaMap.put("WHATIF_ORD_TYPE", whatifOrderFilterVO.getWhatifOrdType());
		criteriaMap.put("WHATIF_LIMIT_PRICE", whatifOrderFilterVO.getWhatifLimitPrice());
		criteriaMap.put("WHATIF_TRIGGER_PRICE", whatifOrderFilterVO.getWhatifTriggerPrice());
		criteriaMap.put("WHATIF_ORD_VALIDITY", whatifOrderFilterVO.getWhatifOrdValidity());
		criteriaMap.put("WHATIF_ORD_QTY", whatifOrderFilterVO.getWhatifOrdQty());
		criteriaMap.put("WHATIF_ORD_DISCLOSED_QTY", whatifOrderFilterVO.getWhatifOrdDisclosedQty());
		criteriaMap.put("WHATIF_PROCLI_TYPE", whatifOrderFilterVO.getWhatifProcliType());
		criteriaMap.put("WHATIF_ACCOUNT_CODE", whatifOrderFilterVO.getWhatifAccountCode());
		criteriaMap.put("WHATIF_CLIENT_PANID", whatifOrderFilterVO.getWhatifClientPanid());
		criteriaMap.put("WHATIF_TM_CODE", whatifOrderFilterVO.getWhatifTmCode());
		criteriaMap.put("WHATIF_DEALER_ID", whatifOrderFilterVO.getWhatifDealerId());
		criteriaMap.put("WHATIF_BRANCH_ID", whatifOrderFilterVO.getWhatifBranchId());
		criteriaMap.put("WHATIF_NNF_ID", whatifOrderFilterVO.getWhatifNnfId());
		criteriaMap.put("WHATIF_ALGO_ID", whatifOrderFilterVO.getWhatifAlgoId());
		criteriaMap.put("WHATIF_ALGO_CATEGORY", whatifOrderFilterVO.getWhatifAlgoCategory());
		criteriaMap.put("WHATIF_RUN_SEQ_NUMBER", whatifOrderFilterVO.getWhatifRunSeqNumber());
		criteriaMap.put("WHATIF_PREOPEN_IND", whatifOrderFilterVO.getWhatifPreopenInd());
		criteriaMap.put("WHATIF_UPD_DATE", new Date());
		criteriaMap.put("WHATIF_UPD_BY",Util.getLogonUserId());

		super.update(hql, criteriaMap);

	}

	public void ModModOrd(WhatifOrderFilterVO whatifOrderFilterVO) throws RepositoryException, ValidationException {
		WhatifOrderFilterVO oldOrderFilterVO = this.getFilterDetailsByFilterNum(whatifOrderFilterVO.getWhatifFilterNumber());
		if(oldOrderFilterVO == null) {
			throw new ValidationException(StaticMsgConstants.OLD_RECORD_NOT_FOUND);
		}

		if(oldOrderFilterVO.equals(whatifOrderFilterVO)) {
			throw new ValidationException(StaticMsgConstants.NO_CHANGE_TO_SAVE);
		}

		String hql = this.sqlConfig.getQuery("MODIFYMODORDFILTERDETAIL");

		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("WHATIF_FILTER_NUMBER", whatifOrderFilterVO.getWhatifFilterNumber());
		criteriaMap.put("WHATIF_SEQ_NUMBER", whatifOrderFilterVO.getWhatifSeqNumber());
		criteriaMap.put("WHATIF_ORDER_NUMBER", whatifOrderFilterVO.getWhatifOrderNumber());
		criteriaMap.put("WHATIF_PRICEADJ_SIGN", whatifOrderFilterVO.getWhatifPriceadjSign());
		criteriaMap.put("WHATIF_PRICEADJ_VAL", whatifOrderFilterVO.getWhatifPriceadjVal());
		criteriaMap.put("WHATIF_ORD_TYPE", whatifOrderFilterVO.getWhatifOrdType());
		criteriaMap.put("WHATIF_LIMIT_PRICE", whatifOrderFilterVO.getWhatifLimitPrice());
		criteriaMap.put("WHATIF_TRIGGER_PRICE", whatifOrderFilterVO.getWhatifTriggerPrice());
		criteriaMap.put("WHATIF_ORD_VALIDITY", whatifOrderFilterVO.getWhatifOrdValidity());
		criteriaMap.put("WHATIF_ORD_QTY", whatifOrderFilterVO.getWhatifOrdQty());
		criteriaMap.put("WHATIF_ORD_DISCLOSED_QTY", whatifOrderFilterVO.getWhatifOrdDisclosedQty());
		criteriaMap.put("WHATIF_PROCLI_TYPE", whatifOrderFilterVO.getWhatifProcliType());
		criteriaMap.put("WHATIF_ACCOUNT_CODE", whatifOrderFilterVO.getWhatifAccountCode());
		criteriaMap.put("WHATIF_CLIENT_PANID", whatifOrderFilterVO.getWhatifClientPanid());
		criteriaMap.put("WHATIF_NNF_ID", whatifOrderFilterVO.getWhatifNnfId());
		criteriaMap.put("WHATIF_ALGO_ID", whatifOrderFilterVO.getWhatifAlgoId());
		criteriaMap.put("WHATIF_ALGO_CATEGORY", whatifOrderFilterVO.getWhatifAlgoCategory());
		criteriaMap.put("WHATIF_UPD_DATE", new Date());
		criteriaMap.put("WHATIF_UPD_BY",Util.getLogonUserId());

		super.update(hql, criteriaMap);
	}

	public void ModRemoveOrd(WhatifOrderFilterVO whatifOrderFilterVO) throws RepositoryException, ValidationException {
		WhatifOrderFilterVO oldOrderFilterVO = this.getFilterDetailsByFilterNum(whatifOrderFilterVO.getWhatifFilterNumber());

		if(oldOrderFilterVO == null) {
			throw new ValidationException(StaticMsgConstants.OLD_RECORD_NOT_FOUND);
		}

		if(oldOrderFilterVO.equals(whatifOrderFilterVO)) {
			throw new ValidationException(StaticMsgConstants.NO_CHANGE_TO_SAVE);
		}

		String hql = this.sqlConfig.getQuery("MODIFYREMOVEORDFILTERDETAIL");

		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("WHATIF_FILTER_NUMBER", whatifOrderFilterVO.getWhatifFilterNumber());
		criteriaMap.put("WHATIF_SEQ_NUMBER", whatifOrderFilterVO.getWhatifSeqNumber());
		criteriaMap.put("WHATIF_PRICEADJ_SIGN", whatifOrderFilterVO.getWhatifPriceadjSign());
		criteriaMap.put("WHATIF_PRICEADJ_VAL", whatifOrderFilterVO.getWhatifPriceadjVal());
		criteriaMap.put("WHATIF_UPD_DATE", new Date());
		criteriaMap.put("WHATIF_UPD_BY",Util.getLogonUserId());

		super.update(hql, criteriaMap);
	}

	public void deleteOrderFilter(int whatifFilterNumber, int whatifRunId) throws RepositoryException {
		try{
			String hql = this.sqlConfig.getQuery("DELETEORDERFILTER");

			Map<String, Object> criteriaMap = new HashMap<>();

			criteriaMap.put("WHATIF_FILTER_NUMBER", whatifFilterNumber);
			criteriaMap.put("WHATIF_RUN_ID", whatifRunId);
			super.delete(hql.toString(), criteriaMap);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	/**
	 * START
	 * What-If: What-If Tab
	 * @author Bansari
	 */
	public List<Object[]> getWhatIfRunId() throws RepositoryException {
		String hql = sqlConfig.getQuery("GETWHATIFRUNID");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("WHSCR_REQUEST_DATE", CacheManager.businessDateVO.getBsdtCurrBussDate());

		List<Object[]> list = super.find(hql,criteriaMap);
		return list != null && !list.isEmpty() ? list : null;
	}

	public Long getWhatIfGridCount(String runId) throws RepositoryException {
		String hql = sqlConfig.getQuery("GETWHATIFGRIDDETAILCOUNT");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("WHSCR_REQUEST_DATE", CacheManager.businessDateVO.getBsdtCurrBussDate());
		criteriaMap.put("WHSCR_SEG_IND", StaticConstants.STRING_A);
		criteriaMap.put("WHSCR_RUN_ID", runId!=null?Integer.parseInt(runId):null);

		List<Object[]> count = super.find(hql,criteriaMap);
		return (Long)count.get(0)[0];
	}

	public List<WhatifSelectCriteria> getWhatIfGridData(String runId, int from, int recCount)throws RepositoryException{
		String hql = sqlConfig.getQuery("GETWHATIFGRIDDETAILS");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("WHSCR_RUN_ID", runId!=null?Integer.parseInt(runId):null);
		criteriaMap.put("WHSCR_REQUEST_DATE", CacheManager.businessDateVO.getBsdtCurrBussDate());
		criteriaMap.put("WHSCR_SEG_IND", StaticConstants.STRING_A);
		criteriaMap.put("FROM", from);
		criteriaMap.put("RECCOUNT", recCount);
		List<WhatifSelectCriteria> list = super.findByQueryPaged(hql,criteriaMap,WhatifSelectCriteria.class);
		return !list.isEmpty() ? list : null;

	}

	public List<WhatifSelectCriteria> getWhatIfDataFromDb(WhatifSelectCriteria whatifSelectCriteria) throws RepositoryException{
		String hql = sqlConfig.getQuery("GETWHATIFDATAFROMDB");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("WHSCR_USER_NUM", 1);
		criteriaMap.put("WHSCR_RUN_DATE", whatifSelectCriteria.getWhscrRunDate());
		criteriaMap.put("WHSCR_REQUEST_DATE", CacheManager.businessDateVO.getBsdtCurrBussDate());
		criteriaMap.put("WHSCR_FROM_TIME", whatifSelectCriteria.getWhscrFromTime());
		criteriaMap.put("WHSCR_SEG_IND", StaticConstants.MW_SCR_SEG_IND);
		criteriaMap.put("WHSCR_SERIES", whatifSelectCriteria.getWhscrSeries());
		criteriaMap.put("WHSCR_SYMBOL", whatifSelectCriteria.getWhscrSymbol());
		criteriaMap.put("WHSCR_TO_TIME", whatifSelectCriteria.getWhscrToTime());
		criteriaMap.put("WHSCR_INDEX_NAME", whatifSelectCriteria.getWhscrIndexName());

		List<WhatifSelectCriteria> list = super.find(hql,criteriaMap);
		return !list.isEmpty() ? list : null;
	}

	public void addWhatIfData(WhatifSelectCriteria whatifSelectCriteria) throws RepositoryException {

		Date currentDate = new Date();

		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT nextval('mktwtch_select_criteria_seq')");
		List<Object[]> runId = super.find(sql.toString());

		whatifSelectCriteria.setWhscrRunId(Integer.parseInt((runId.get(0)[0]).toString()));
		whatifSelectCriteria.setWhscrUserNum(1);
		whatifSelectCriteria.setWhscrSegInd(StaticConstants.STRING_A);
		whatifSelectCriteria.setWhscrStatus(StaticConstants.STRING_P);
		whatifSelectCriteria.setWhscrRunDate(Util.dateToSqlDate(whatifSelectCriteria.getWhscrRunDate()));
		whatifSelectCriteria.setWhscrRequestDate(Util.dateToSqlDate(CacheManager.businessDateVO.getBsdtCurrBussDate()));
		whatifSelectCriteria.setWhscrSymbol(Util.upperCase(whatifSelectCriteria.getWhscrSymbol()));
		whatifSelectCriteria.setWhscrSeries(Util.upperCase(whatifSelectCriteria.getWhscrSeries()));
		whatifSelectCriteria.setWhscrIndexName(whatifSelectCriteria.getWhscrIndexName());
		whatifSelectCriteria.setWhscrCrtBy(Util.getLogonUserId());
		whatifSelectCriteria.setWhscrCrtDate(new Timestamp(currentDate.getTime()));
		whatifSelectCriteria.setWhscrUpdtBy(Util.getLogonUserId());
		whatifSelectCriteria.setWhscrUpdtDate(new Timestamp(currentDate.getTime()));
		
		super.add(whatifSelectCriteria);
	}

	public void modifyWhatIfData(WhatifSelectCriteria whatifSelectCriteria) throws RepositoryException {

		String hql = sqlConfig.getQuery("MODIFYWHATIFDETAILS");
		Map<String, Object> criteriaMap = new HashMap<>();

		Date runDate = whatifSelectCriteria.getWhscrRunDate();
		criteriaMap.put("WHSCR_RUN_ID", whatifSelectCriteria.getWhscrRunId());
		criteriaMap.put("WHSCR_FROM_TIME", whatifSelectCriteria.getWhscrFromTime());
		criteriaMap.put("WHSCR_TO_TIME", whatifSelectCriteria.getWhscrToTime());
		criteriaMap.put("WHSCR_INDEX_NAME", whatifSelectCriteria.getWhscrIndexName());
		criteriaMap.put("WHSCR_SEG_IND", StaticConstants.STRING_A);
		criteriaMap.put("WHSCR_SERIES", whatifSelectCriteria.getWhscrSeries());
		criteriaMap.put("WHSCR_SYMBOL", whatifSelectCriteria.getWhscrSymbol());
		criteriaMap.put("WHSCR_USER_NUM", 1);
		criteriaMap.put("WHSCR_RUN_DATE", runDate);
		criteriaMap.put("WHATIF_PECT_AWAY_LTP", whatifSelectCriteria.getWhatifPectAwayLtp());
		criteriaMap.put("WHATIF_SL_PECT_AWAY_LTP", whatifSelectCriteria.getWhatifSlPectAwayLtp());
		criteriaMap.put("WHATIF_LARGE_CXL_QTY", whatifSelectCriteria.getWhatifLargeCxlQty());
		criteriaMap.put("WHATIF_LARGE_UNEXECUTED_QTY", whatifSelectCriteria.getWhatifLargeUnexecutedQty());
		criteriaMap.put("WHATIF_MKTCLOSE_TIME", whatifSelectCriteria.getWhatifMktcloseTime());
		criteriaMap.put("WHSCR_UPDT_BY", Util.getLogonUserId());
		criteriaMap.put("WHSCR_UPDT_DATE", new Date());
		super.update(hql, criteriaMap);

	}

	public List<WhatifSelectCriteria> getDataFromDbForUpdate(WhatifSelectCriteria whatifSelectCriteria) throws RepositoryException{
		String hql = sqlConfig.getQuery("GETOLDWHATIFDATA");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("WHSCR_RUN_DATE", whatifSelectCriteria.getWhscrRunDate());
		criteriaMap.put("WHSCR_FROM_TIME", whatifSelectCriteria.getWhscrFromTime());
		criteriaMap.put("WHSCR_SEG_IND", StaticConstants.STRING_A);
		criteriaMap.put("WHSCR_SERIES", whatifSelectCriteria.getWhscrSeries());
		criteriaMap.put("WHSCR_SYMBOL", whatifSelectCriteria.getWhscrSymbol());
		criteriaMap.put("WHSCR_TO_TIME", whatifSelectCriteria.getWhscrToTime());
		criteriaMap.put("WHSCR_INDEX_NAME", whatifSelectCriteria.getWhscrIndexName());
		criteriaMap.put("WHATIF_MKTCLOSE_TIME", whatifSelectCriteria.getWhatifMktcloseTime());
		List<WhatifSelectCriteria> list = super.find(hql,criteriaMap,WhatifSelectCriteria.class);
		return list!=null ? list : null;
	}

	/**
	 * END
	 * What-If: What-If Tab
	 * @author Bansari
	 */

}
