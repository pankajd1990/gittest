package com.surv.dao.marketreplay;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.surv.cache.CacheManager;
import com.surv.config.SqlConfig;
import com.surv.constant.StaticConstants;
import com.surv.dao.common.GenericRepository;
import com.surv.entity.admin.UadUserGroupVO;
import com.surv.entity.marketreplay.MktwtchSelectCriteriaVO;
import com.surv.entity.marketreplay.SCmSecurityMasterVO;
import com.surv.entity.marketreplay.SNseCalendarVO;
import com.surv.exception.RepositoryException;
import com.surv.utility.Util;

@Repository("replayCriteriaDAO")
public class ReplayCriteriaDAO extends GenericRepository {

	@Autowired
	private SqlConfig sqlConfig;

	public List<Object[]> getIndexLovdata(Date runDate) throws RepositoryException {
		String hql = sqlConfig.getQuery("GETINDEXDATA");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("IDXRCVDTIMECK", runDate);
		List<Object[]> list = super.find(hql,criteriaMap);
		return list != null && !list.isEmpty() ? list : null;
	}

	public List<Object[]> getRunId() throws RepositoryException {
		String hql = sqlConfig.getQuery("GETRUNID");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MWSCRREQUESTDATE", CacheManager.businessDateVO.getBsdtCurrBussDate());
		List<Object[]> list = super.find(hql,criteriaMap);
		return list != null && !list.isEmpty() ? list : null;
	}

	public List<MktwtchSelectCriteriaVO> getReplyCriteria() throws RepositoryException {
		String hql = sqlConfig.getQuery("GETREPLYCRITERIA");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MWSCRBUSSDATE", CacheManager.businessDateVO.getBsdtCurrBussDate());
		List<MktwtchSelectCriteriaVO> list = super.find(hql,criteriaMap);

		return list != null && !list.isEmpty() ? list : null;
	}

	public Long getSymbolSeriesCount(SCmSecurityMasterVO sCmSecurityMasterVO) throws RepositoryException {
		Map<String, Object> criteriaMap = new HashMap<>();
		String hql = sqlConfig.getQuery("SEARCHSERIESCOUNT");
		criteriaMap.put("SYMBOL", sCmSecurityMasterVO.getSymbol()!=null?sCmSecurityMasterVO.getSymbol().toUpperCase() + StaticConstants.PRCNTG:null);
		criteriaMap.put("SERIES", sCmSecurityMasterVO.getSeries()!=null?sCmSecurityMasterVO.getSeries().toUpperCase() + StaticConstants.PRCNTG:null);
		List<Object[]> count = super.find(hql,criteriaMap);
		return (Long)count.get(0)[0];
	}

	public List<SCmSecurityMasterVO> getSymbolSeriesData(SCmSecurityMasterVO sCmSecurityMasterVO) throws RepositoryException {
		Map<String, Object> criteriaMap = new HashMap<>();
		String hql = sqlConfig.getQuery("SEARCHSERIES");
		criteriaMap.put("SYMBOL", sCmSecurityMasterVO.getSymbol()!=null?sCmSecurityMasterVO.getSymbol().toUpperCase() + StaticConstants.PRCNTG:null);
		criteriaMap.put("SERIES", sCmSecurityMasterVO.getSeries()!=null?sCmSecurityMasterVO.getSeries().toUpperCase() + StaticConstants.PRCNTG:null);
		criteriaMap.put("FROM", sCmSecurityMasterVO.getFrom());
		criteriaMap.put("RECCOUNT", sCmSecurityMasterVO.getPageSize());
		List<Object[]> listObject = super.findByQueryPaged(hql,criteriaMap);
		if (listObject != null && !listObject.isEmpty()) {
			List<SCmSecurityMasterVO> list = new ArrayList<>();
			for (Object[] object : listObject) {
				list.add(new SCmSecurityMasterVO(object));
			}
			return list;
		}
		return null;
	}

	public Long getMarketWatchGridCount(String runId) throws RepositoryException {
		String hql = sqlConfig.getQuery("GETGRIDDETAILCOUNT");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MWSCRREQUESTDATE", CacheManager.businessDateVO.getBsdtCurrBussDate());
		criteriaMap.put("MWSCRSEGIND", StaticConstants.MW_SCR_SEG_IND);
		criteriaMap.put("MWSCRRUNID", runId!=null?Integer.parseInt(runId):null);

		List<Object[]> count = super.find(hql,criteriaMap);
		return (Long)count.get(0)[0];
	}

	public List<MktwtchSelectCriteriaVO> getMarketWatchGridData(String runId, int from, int recCount)throws RepositoryException{
		String hql = sqlConfig.getQuery("GETGRIDDETAILS");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MWSCRRUNID", runId!=null?Integer.parseInt(runId):null);
		criteriaMap.put("MWSCRREQUESTDATE", CacheManager.businessDateVO.getBsdtCurrBussDate());
		criteriaMap.put("MWSCRSEGIND", StaticConstants.MW_SCR_SEG_IND);
		criteriaMap.put("MWSCRSTATUS", StaticConstants.STRING_P);
		criteriaMap.put("FROM", from);
		criteriaMap.put("RECCOUNT", recCount);
		List<MktwtchSelectCriteriaVO> list = super.findByQueryPaged(hql,criteriaMap,MktwtchSelectCriteriaVO.class);
		return !list.isEmpty() ? list : null;
	}

	public Long getQueryGridCount(Date mwscrBussDate) throws RepositoryException {
		String hql = sqlConfig.getQuery("GETQUERYGRIDDETAILCOUNT");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MWSCRREQUESTDATE", mwscrBussDate);

		List<Object[]> count = super.find(hql,criteriaMap);
		return (Long)count.get(0)[0];
	}

	public List<MktwtchSelectCriteriaVO> getQueryGridData(Date mwscrBussDate, int from, int recCount)throws RepositoryException{
		String hql = sqlConfig.getQuery("GETQUERYGRIDDETAILS");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MWSCRREQUESTDATE", mwscrBussDate);
		criteriaMap.put("FROM", from);
		criteriaMap.put("RECCOUNT", recCount);

		List<MktwtchSelectCriteriaVO> list = super.findByQueryPaged(hql,criteriaMap,MktwtchSelectCriteriaVO.class);
		return !list.isEmpty() ? list : null;
	}

	public void addReplayCriteria(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) throws RepositoryException {
		Date currentDate = new Date();

		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT nextval('mktwtch_select_criteria_seq')");
		List<Object[]> runId = super.find(sql.toString());

		mktwtchSelectCriteriaVO.setMwscrRunId(Integer.parseInt((runId.get(0)[0]).toString()));
		mktwtchSelectCriteriaVO.setMwscrUserNum(1);
		mktwtchSelectCriteriaVO.setMwscrSegInd(StaticConstants.MW_SCR_SEG_IND);
		mktwtchSelectCriteriaVO.setMwscrStatus(StaticConstants.STRING_P);
		mktwtchSelectCriteriaVO.setMwscrBussDate(Util.dateToSqlDate(mktwtchSelectCriteriaVO.getMwscrBussDate()));
		mktwtchSelectCriteriaVO.setMwscrRequestDate(Util.dateToSqlDate(CacheManager.businessDateVO.getBsdtCurrBussDate()));
		mktwtchSelectCriteriaVO.setMwscrSymbol(Util.upperCase(mktwtchSelectCriteriaVO.getMwscrSymbol()));
		mktwtchSelectCriteriaVO.setMwscrSeries(Util.upperCase(mktwtchSelectCriteriaVO.getMwscrSeries()));
		mktwtchSelectCriteriaVO.setMwscrCrtBy(Util.getLogonUserId());
		mktwtchSelectCriteriaVO.setMwscrCrtDate(new Timestamp(currentDate.getTime()));
		mktwtchSelectCriteriaVO.setMwscrUpdtBy(Util.getLogonUserId());
		mktwtchSelectCriteriaVO.setMwscrUpdtDate(new Timestamp(currentDate.getTime()));
		super.add(mktwtchSelectCriteriaVO);
	}

	public void modifyReplayCriteria(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) throws RepositoryException {

		String hql = sqlConfig.getQuery("MODIFYSELECTCRITERIADETAILS");
		Map<String, Object> criteriaMap = new HashMap<>();

		Date bussDate = mktwtchSelectCriteriaVO.getMwscrBussDate();
		criteriaMap.put("MWSCRRUNID", mktwtchSelectCriteriaVO.getMwscrRunId());
		criteriaMap.put("MWSCRFROMTIME", mktwtchSelectCriteriaVO.getMwscrFromTime());
		criteriaMap.put("MWSCRTOTIME", mktwtchSelectCriteriaVO.getMwscrToTime());
		criteriaMap.put("MWSCRINDEXNAME", mktwtchSelectCriteriaVO.getMwscrIndexName());
		criteriaMap.put("MWSCRSERIES", mktwtchSelectCriteriaVO.getMwscrSeries());
		criteriaMap.put("MWSCRSYMBOL", mktwtchSelectCriteriaVO.getMwscrSymbol());
		criteriaMap.put("MWSCRBUSSDATE", bussDate);
		criteriaMap.put("MWSCRPECTAWAYLTP", mktwtchSelectCriteriaVO.getMwscrPectAwayLtp());
		criteriaMap.put("MWSCRSLPECTAWAYLTP", mktwtchSelectCriteriaVO.getMwscrSlPectAwayLtp());
		criteriaMap.put("MWSCRLARGECXLQTY", mktwtchSelectCriteriaVO.getMwscrLargeCxlQty());
		criteriaMap.put("MWSCRLARGEUNEXECUTEDQTY", mktwtchSelectCriteriaVO.getMwscrLargeUnexecutedQty());
		criteriaMap.put("MWSCRUPDTBY", Util.getLogonUserId());
		criteriaMap.put("MWSCRUPDTDATE", new Date());
		super.update(hql, criteriaMap);
	}

	public UadUserGroupVO getUadUserGroup() throws RepositoryException {
		String hql = sqlConfig.getQuery("GETUADUSERGROUP");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("UADUSERGROUPNUM", Util.getUserDetails().getUadUserNum());
		List<UadUserGroupVO> list = super.find(hql,criteriaMap, UadUserGroupVO.class);
		return !list.isEmpty() ? list.get(0) : null;
	}

	public Date getWorkingDate(UadUserGroupVO uadUserGroup) throws RepositoryException {
		String sql = sqlConfig.getQuery("GETBUSINESSPARAMETERS");
		List<Object[]> list = super.find(sql);

		Date date = (Date)list.get(0)[0];
		Map<String, Object> criteriaMap = new LinkedHashMap<>();

		String sql1 = "select func_workingdate(:v_date::DATE,:num::INTEGER)";
		criteriaMap.put("v_date",date);
		criteriaMap.put("num", uadUserGroup.getUadQueryNotallwdWrkngDays()*-1);
		List<Object[]> workingDate = super.find(sql1, criteriaMap);
		return (Date)workingDate.get(0)[0]; 
	}

	public int checkLimit(Date mwscrRequestDate) throws RepositoryException {
		String hql = sqlConfig.getQuery("CHECKLIMIT");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MWSCRREQUESTDATE", mwscrRequestDate);
		criteriaMap.put("MWSCRSEGIND", StaticConstants.MW_SCR_SEG_IND);
		criteriaMap.put("MWSCRSTATUSI", StaticConstants.STRING_I);
		criteriaMap.put("MWSCRSTATUSC", StaticConstants.STRING_C);
		List<MktwtchSelectCriteriaVO> list = this.find(hql, criteriaMap);
		return list != null ? list.size() : null;
	}

	public List<SCmSecurityMasterVO> checkSeriesSymbol(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) throws RepositoryException {
		String hql = sqlConfig.getQuery("CHECKSERIESSYMBOL");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MWSCRSYMBOL", mktwtchSelectCriteriaVO.getMwscrSymbol().trim());
		criteriaMap.put("MWSCRSERIES", mktwtchSelectCriteriaVO.getMwscrSeries().trim());
		List<SCmSecurityMasterVO> list = this.find(hql, criteriaMap);
		return list;
	}

	public boolean validationHoliday(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) throws RepositoryException {
		String hql = sqlConfig.getQuery("VALIDATIONHOLIDAY");
		Map<String, Object> criteriaMap = new HashMap<>();
		Date bussDate = Util.getStringDate(mktwtchSelectCriteriaVO.getMwscrBussDateString());
		criteriaMap.put("MWSCRBUSSDATE", bussDate );
		List<SNseCalendarVO> list = this.find(hql,criteriaMap);
		return list != null && !list.isEmpty() ? true : false;
	}

	public List<MktwtchSelectCriteriaVO> getDataFromDb(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) throws RepositoryException{
		String hql = sqlConfig.getQuery("GETDATAFROMDB");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MWSCRUSERNUM", 1);
		criteriaMap.put("MWSCRBUSSDATE", mktwtchSelectCriteriaVO.getMwscrBussDate());
		criteriaMap.put("MWSCRREQUESTDATE", Util.dateToSqlDate(CacheManager.businessDateVO.getBsdtCurrBussDate()));
		criteriaMap.put("MWSCRFROMTIME", mktwtchSelectCriteriaVO.getMwscrFromTime());
		criteriaMap.put("MWSCRSEGIND", StaticConstants.MW_SCR_SEG_IND);
		criteriaMap.put("MWSCRSERIES", mktwtchSelectCriteriaVO.getMwscrSeries());
		criteriaMap.put("MWSCRSYMBOL", mktwtchSelectCriteriaVO.getMwscrSymbol());
		criteriaMap.put("MWSCRTOTIME", mktwtchSelectCriteriaVO.getMwscrToTime());
		criteriaMap.put("MWSCRINDEXNAME", mktwtchSelectCriteriaVO.getMwscrIndexName());

		List<MktwtchSelectCriteriaVO> list = super.find(hql,criteriaMap);
		return !list.isEmpty() ? list : null;
	}

	public List<MktwtchSelectCriteriaVO> getDataFromDbForUpdate(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) throws RepositoryException{
		String hql = sqlConfig.getQuery("GETDATAFROMDBFORUPDATE");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MWSCRBUSSDATE", mktwtchSelectCriteriaVO.getMwscrBussDateString());
		criteriaMap.put("MWSCRFROMTIME", mktwtchSelectCriteriaVO.getMwscrFromTime());
		criteriaMap.put("MWSCRSEGIND", StaticConstants.MW_SCR_SEG_IND);
		criteriaMap.put("MWSCRSERIES", mktwtchSelectCriteriaVO.getMwscrSeries());
		criteriaMap.put("MWSCRSYMBOL", mktwtchSelectCriteriaVO.getMwscrSymbol());
		criteriaMap.put("MWSCRTOTIME", mktwtchSelectCriteriaVO.getMwscrToTime());
		criteriaMap.put("MWSCRINDEXNAME", mktwtchSelectCriteriaVO.getMwscrIndexName());
		List<MktwtchSelectCriteriaVO> list = super.find(hql,criteriaMap);
		return !list.isEmpty() ? list : null;
	}

	public void modifyStatus(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) throws RepositoryException{
		String hql = sqlConfig.getQuery("MODIFYSTATUSDETAIL");

		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MWSCRRUNID", mktwtchSelectCriteriaVO.getMwscrRunId());
		criteriaMap.put("MWSCRSTATUS", mktwtchSelectCriteriaVO.getMwscrStatus());
		criteriaMap.put("MWSCRCURRDAYFLAG", mktwtchSelectCriteriaVO.getMwscrCurrDayFlag());

		super.update(hql, criteriaMap);
	}

	public void modifyDeleteStatus(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) throws RepositoryException{
		String hql = sqlConfig.getQuery("MODIFYDELETESTATUSDETAIL");
		Map<String, Object> criteriaMap = new HashMap<>();
		criteriaMap.put("MWSCRRUNID", mktwtchSelectCriteriaVO.getMwscrRunId());
		criteriaMap.put("MWSCRSTATUS", StaticConstants.STRING_D);
		super.update(hql, criteriaMap);
	}

}