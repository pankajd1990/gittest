package com.surv.dao.marketreplay;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.surv.config.SqlConfig;
import com.surv.dao.common.GenericRepository;
import com.surv.entity.marketreplay.AlertDetailsVO;
import com.surv.entity.marketreplay.AlertRuleThresholdDetailVO;
import com.surv.entity.marketreplay.AlertRuleVO;
import com.surv.exception.RepositoryException;
import com.surv.utility.Util;

@Repository("setThresholdDAO")
public class SetThresholdDAO extends GenericRepository {

	@Autowired
	private SqlConfig sqlConfig;

	public List<String> getAllAlerts() throws RepositoryException {
		String sql = this.sqlConfig.getQuery("GETALLALERTS");
		List<String> list = super.find(sql);
		return list != null && !list.isEmpty() ? list : null;
	}

	public int searchAlertCountData(List<String> ruleName)throws RepositoryException {
		List<Object[]> listObject = new ArrayList<>();
		if(ruleName != null && !ruleName.isEmpty()){
			String sql = this.sqlConfig.getQuery("SEARCHALERTDATA");
			Map<String, Object> criteriaMap = new HashMap<>();
			criteriaMap.put("RULE_NAME", ruleName);
			listObject = super.find(sql, criteriaMap, AlertRuleVO.class);
		}else{
			String sql = this.sqlConfig.getQuery("SEARCHALERTDATA2");
			listObject = super.find(sql);
		}
		return listObject.size();
	}

	public List<AlertRuleVO> searchAlertData(List<String> ruleName, int from, int recCount) throws RepositoryException {
		Map<String, Object> criteriaMap = new HashMap<>();
		if(ruleName != null && !ruleName.isEmpty()){
			String sql = this.sqlConfig.getQuery("SEARCHALERTDATA");
			sql += " LIMIT :RECCOUNT OFFSET :FROM";

			criteriaMap.put("RULE_NAME", ruleName);
			criteriaMap.put("FROM", from);
			criteriaMap.put("RECCOUNT", recCount);

			List<AlertRuleVO> list = super.find(sql, criteriaMap, AlertRuleVO.class);
			return list != null && !list.isEmpty() ? list : null;		
		}else{

			String sql = this.sqlConfig.getQuery("SEARCHALERTDATA2");
			sql += " LIMIT :RECCOUNT OFFSET :FROM";

			criteriaMap.put("FROM", from);
			criteriaMap.put("RECCOUNT", recCount);

			List<AlertRuleVO> list = super.find(sql,criteriaMap, AlertRuleVO.class);
			return list != null && !list.isEmpty() ? list : null;	
		}
	}

	public int searchSelectedCountData(List<AlertRuleVO> listAlertDetails) throws RepositoryException {

		String hql = this.sqlConfig.getQuery("SEARCHSELECTEDDATA");

		List<Object[]> listObject = new ArrayList<Object[]>();
		List<Integer> list = new ArrayList<Integer>();

		Map<String, Object> criteriaMap = new HashMap<>();
		for (AlertRuleVO alertRuleVO : listAlertDetails) {

			list.add(alertRuleVO.getRuleNum());
			criteriaMap.put("LIST2", list);

		}
		listObject.addAll(super.find(hql, criteriaMap));

		return listObject.size();


	}

	public List<AlertDetailsVO> searchSelectedData(List<AlertRuleVO> listAlertDetails, int from, int recCount) throws RepositoryException {

		String sql = this.sqlConfig.getQuery("SEARCHSELECTEDDATA");
		sql += " LIMIT :RECCOUNT OFFSET :FROM";

		List<Object[]> listObject = new ArrayList<Object[]>();
		List<Integer> list = new ArrayList<Integer>();

		Map<String, Object> criteriaMap = new HashMap<>();
		for (AlertRuleVO alertRuleVO : listAlertDetails) {

			list.add(alertRuleVO.getRuleNum());
			criteriaMap.put("LIST2", list);
			criteriaMap.put("FROM", from);
			criteriaMap.put("RECCOUNT", recCount);
		}
		listObject.addAll(super.find(sql, criteriaMap));

		if (listObject != null && !listObject.isEmpty()) {
			List<AlertDetailsVO> listOut = new ArrayList<>();
			for (Object[] object : listObject) {
				listOut.add(new AlertDetailsVO(object));
			}
			return listOut;
		}
		return null;
	}

	public void updateData(List<AlertRuleThresholdDetailVO> listUpdateDetails) throws RepositoryException {
		String hql = sqlConfig.getQuery("UPDATEALERTDATA");
		Date date = new Date();
		Map<String, Object> criteriaMap = new HashMap<>();
		for(AlertRuleThresholdDetailVO alertRuleThresholdDetailVO : listUpdateDetails){
			criteriaMap.put("THRSH_THRESH_UPDT_BY", Util.getLogonUserId());
			criteriaMap.put("THRESH_UPDT_DATE",Util.dateToSqlDate(date));
			criteriaMap.put("THRSH_RULE_NO",alertRuleThresholdDetailVO.getThrshRuleNo());
			criteriaMap.put("THRSH_THRESHOLD_NUM",alertRuleThresholdDetailVO.getThrshThresholdNum());
			criteriaMap.put("THRSH_NEW_VALUE",alertRuleThresholdDetailVO.getThrshNewValue());
			criteriaMap.put("THRSH_EFF_DATE",Util.getStringDate1(alertRuleThresholdDetailVO.getThrshEffDateString()));
			super.update(hql, criteriaMap);
		}
	}


}
