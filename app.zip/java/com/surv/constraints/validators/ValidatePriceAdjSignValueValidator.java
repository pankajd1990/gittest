package com.surv.constraints.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import com.surv.constraints.annotations.ValidatePriceAdjSignValueValidation;
import com.surv.entity.marketreplay.WhatifOrderFilterVO;
import com.surv.utility.Logger;

public class ValidatePriceAdjSignValueValidator implements ConstraintValidator<ValidatePriceAdjSignValueValidation, WhatifOrderFilterVO>{

	@Override
	public void initialize(ValidatePriceAdjSignValueValidation constraintAnnotation) {

	}

	@Override
	public boolean isValid(WhatifOrderFilterVO whatifOrderFilterVO, ConstraintValidatorContext context) {
		try{
			if (whatifOrderFilterVO.getWhatifPriceadjSign() != null
				&& whatifOrderFilterVO.getWhatifPriceadjVal() != null) {
		
			return true;
		}else if(whatifOrderFilterVO.getWhatifPriceadjSign()== null
				&& whatifOrderFilterVO.getWhatifPriceadjVal() == null){
		
			return true;
		} else 
		
			return false;
		}catch(Exception e){
			try {
				throw new Exception(e.getMessage());
			} catch (Exception e1) {
				Logger.EXCEPTION.error("", e.getMessage()); 
				e1.printStackTrace();
			}	
		}
		return false;
	}
}

