package com.surv.constraints.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.surv.cache.CacheManager;
import com.surv.constant.StaticConstants;
import com.surv.constraints.annotations.CheckRecordLimitValidation;
import com.surv.entity.marketreplay.MktwtchSelectCriteriaVO;
import com.surv.exception.ValidationException;
import com.surv.service.marketreplay.ReplayCriteriaService;
import com.surv.utility.Logger;

public class CheckRecordLimitValidator implements ConstraintValidator<CheckRecordLimitValidation, MktwtchSelectCriteriaVO> {

	@Autowired
	@Qualifier(value="replayCriteriaService")
	ReplayCriteriaService replayCriteriaService;
	
	@Override
	public void initialize(CheckRecordLimitValidation constraintAnnotation) {
		SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
	}

	@Override
	public boolean isValid(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO, ConstraintValidatorContext context){
		try {
			int limit = this.replayCriteriaService.checkLimit(CacheManager.businessDateVO.getBsdtCurrBussDate());
//			if(limit <= CacheManager.marketReplayLimit)
			if(limit < StaticConstants.MARKET_REPLY_LIMIT)
				return true;
		} catch (Exception e) {
			try {
				throw new ValidationException(e.getMessage());
			} catch (ValidationException e1) {
				Logger.EXCEPTION.error("", e.getMessage()); 
			}
		}
		return false;
	}



}
