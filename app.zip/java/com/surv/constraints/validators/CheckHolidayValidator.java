package com.surv.constraints.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.surv.constraints.annotations.CheckHolidayValidation;
import com.surv.entity.marketreplay.MktwtchSelectCriteriaVO;
import com.surv.exception.ValidationException;
import com.surv.service.marketreplay.ReplayCriteriaService;
import com.surv.utility.Logger;



public class CheckHolidayValidator implements ConstraintValidator<CheckHolidayValidation, MktwtchSelectCriteriaVO>{

	@Autowired
	@Qualifier(value="replayCriteriaService")
	ReplayCriteriaService replayCriteriaService;
	
	@Override
	public void initialize(CheckHolidayValidation constraintAnnotation) {
		SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
	}

	@Override
	public boolean isValid(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO, ConstraintValidatorContext context){
		boolean ValidationHoliday = true;
		try {
			ValidationHoliday = this.replayCriteriaService.validationHoliday(mktwtchSelectCriteriaVO);
		} catch (Exception e) {
			try {
				throw new ValidationException(e.getMessage());
			} catch (ValidationException e1) {
				Logger.EXCEPTION.error("", e.getMessage()); 
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return ValidationHoliday;
	}



}
