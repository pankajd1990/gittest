package com.surv.constraints.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.surv.constraints.annotations.CheckThresholdDataValidation;
import com.surv.entity.marketreplay.AlertRuleThresholdDetailVO;
import com.surv.utility.Logger;

public class CheckThresholdDataValidator implements ConstraintValidator<CheckThresholdDataValidation , AlertRuleThresholdDetailVO> {

	@Override
	public void initialize(CheckThresholdDataValidation arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isValid(AlertRuleThresholdDetailVO alertRuleThresholdDetailVO, ConstraintValidatorContext arg1) {
		try{
			if (alertRuleThresholdDetailVO.getThrshEffDateString() != null
				&& alertRuleThresholdDetailVO.getThrshNewValue() != null
				&& alertRuleThresholdDetailVO.getThrshNewValue() != "") {
			return true;
		} else {
			return false;}
		}catch(Exception e){
			try {
				throw new Exception(e.getMessage());
			} catch (Exception e1) {
				Logger.EXCEPTION.error("", e.getMessage()); 
				e1.printStackTrace();
			}	
		}
		return false;
	}

}
