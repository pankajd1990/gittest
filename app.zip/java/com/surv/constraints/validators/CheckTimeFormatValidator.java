package com.surv.constraints.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.surv.constraints.annotations.ValidateTimeformat;
import com.surv.entity.marketreplay.MktwtchSelectCriteriaVO;
import com.surv.exception.ValidationException;
import com.surv.service.marketreplay.ReplayCriteriaService;
import com.surv.utility.Logger;
import com.surv.utility.RegexValidator;

public class CheckTimeFormatValidator implements ConstraintValidator<ValidateTimeformat, MktwtchSelectCriteriaVO>{

	@Autowired
	@Qualifier(value="replayCriteriaService")
	ReplayCriteriaService replayCriteriaService;
	
	@Override
	public void initialize(ValidateTimeformat constraintAnnotation) {
		SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
	}

	@Override
	public boolean isValid(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO, ConstraintValidatorContext context){
		try {
				if( new RegexValidator().validate(mktwtchSelectCriteriaVO.getMwscrFromTimeString()) && new RegexValidator().validate(mktwtchSelectCriteriaVO.getMwscrToTimeString()) && mktwtchSelectCriteriaVO.getMwscrFromTime().before(mktwtchSelectCriteriaVO.getMwscrToTime())) {
					return true;
			}
		
		} catch (Exception e) {
			try {
				throw new ValidationException(e.getMessage());
			} catch (ValidationException e1) {
				Logger.EXCEPTION.error("", e.getMessage()); 
				e1.printStackTrace();
			}
		}
		return false;
	}

}