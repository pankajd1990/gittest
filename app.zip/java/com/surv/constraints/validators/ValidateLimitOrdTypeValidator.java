package com.surv.constraints.validators;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import com.surv.constant.StaticConstants;
import com.surv.constraints.annotations.ValidateLimitOrdTypeValidation;
import com.surv.entity.marketreplay.WhatifOrderFilterVO;

public class ValidateLimitOrdTypeValidator implements ConstraintValidator<ValidateLimitOrdTypeValidation, WhatifOrderFilterVO>{

	@Override
	public void initialize(ValidateLimitOrdTypeValidation constraintAnnotation) {

	}

	@Override
	public boolean isValid(WhatifOrderFilterVO whatifOrderFilterVO, ConstraintValidatorContext context) {
		try{
			if(whatifOrderFilterVO.getWhatifOrdType().equals(StaticConstants.STRING_L )){
				if(whatifOrderFilterVO.getWhatifTriggerPrice()!=null || whatifOrderFilterVO.getWhatifLimitPrice()==null){
					return false;
				}
			}
			else{
				return true;
				}
		}catch (Exception e) {
			try {
				throw new Exception(e.getMessage());
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		return true;
	}

}

