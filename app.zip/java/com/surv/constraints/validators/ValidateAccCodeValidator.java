package com.surv.constraints.validators;



import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.surv.constant.StaticConstants;
import com.surv.constraints.annotations.ValidateAccCodeValidation;
import com.surv.entity.marketreplay.WhatifOrderFilterVO;

public class ValidateAccCodeValidator implements ConstraintValidator<ValidateAccCodeValidation, WhatifOrderFilterVO>{

	@Override
	public void initialize(ValidateAccCodeValidation constraintAnnotation) {

	}

	@Override
	public boolean isValid(WhatifOrderFilterVO whatifOrderFilterVO, ConstraintValidatorContext context) {
		try{
			if((whatifOrderFilterVO.getWhatifProcliType().toString()).equals(StaticConstants.NUMBER_ONE )){
				if(whatifOrderFilterVO.getWhatifAccountCode()==null){
					return false;
				}
			}
			else{
				return true;
				}
		}catch (Exception e) {
			try {
				throw new Exception(e.getMessage());
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		return true;
	}

}
