//public class SLMarketOrdTypeValidator {
package com.surv.constraints.validators;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import com.surv.constant.StaticConstants;
import com.surv.constraints.annotations.ValidateSLMarketOrdTypeValidation;
import com.surv.entity.marketreplay.WhatifOrderFilterVO;

public class ValidateSLMarketOrdTypeValidator implements ConstraintValidator<ValidateSLMarketOrdTypeValidation, WhatifOrderFilterVO>{

	@Override
	public void initialize(ValidateSLMarketOrdTypeValidation constraintAnnotation) {

	}

	@Override
	public boolean isValid(WhatifOrderFilterVO whatifOrderFilterVO, ConstraintValidatorContext context) {
		try{
			if(whatifOrderFilterVO.getWhatifOrdType().equals(StaticConstants.STRING_SM )){
				if(whatifOrderFilterVO.getWhatifTriggerPrice()==null || whatifOrderFilterVO.getWhatifLimitPrice()!=null){
					return false;
				}
			}
			else{
				return true;
				}
		}catch (Exception e) {
			try {
				throw new Exception(e.getMessage());
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		return true;
	}

}


