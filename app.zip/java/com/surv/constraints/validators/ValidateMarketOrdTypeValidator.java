package com.surv.constraints.validators;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.surv.constant.StaticConstants;
import com.surv.constraints.annotations.ValidateMarketOrdTypeValidation;
import com.surv.entity.marketreplay.WhatifOrderFilterVO;

public class ValidateMarketOrdTypeValidator implements ConstraintValidator<ValidateMarketOrdTypeValidation, WhatifOrderFilterVO>{

	@Override
	public void initialize(ValidateMarketOrdTypeValidation constraintAnnotation) {

	}

	@Override
	public boolean isValid(WhatifOrderFilterVO whatifOrderFilterVO, ConstraintValidatorContext context) {
		try{

			if(whatifOrderFilterVO.getWhatifOrdType().equals(StaticConstants.STRING_M )){
				if(whatifOrderFilterVO.getWhatifTriggerPrice()!=null || whatifOrderFilterVO.getWhatifLimitPrice()!=null){
					return false;
				}
			}
			else{
				return true;
			}
		}catch (Exception e) {
			try {
				throw new Exception(e.getMessage());
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		return true;
	}

}

