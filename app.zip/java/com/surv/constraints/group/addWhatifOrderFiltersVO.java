package com.surv.constraints.group;

public interface addWhatifOrderFiltersVO {

}
