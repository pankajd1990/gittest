package com.surv.cache;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Map;

import org.apache.ignite.IgniteCache;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.surv.entity.marketreplay.BusinessDateVO;

@Component
@ConfigurationProperties(prefix ="spring")
public class CacheManager {

	public static String authServer;
	public static Integer marketReplayLimit;

	public static IgniteCache<?, ?> igniteCache;
	public static IgniteCache<?, ?> igniteMrRequest;
	public static IgniteCache<?, ?> igniteEventCache;

	public static BusinessDateVO businessDateVO;
	public static Map<String, String> sqlQueryMap;
	public static Map<String, String> cacheQueryMap;
	public static Map<String, Integer> marketReplayMapping;
	public static Map<String, Map<String, String>> staticReferenceLOV;

	public static DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 

	public static String getAuthServer() {
		return authServer;
	}
	public static void setAuthServer(String authServer) {
		CacheManager.authServer = authServer;
	}
	public static void setMarketReplayLimit(Integer marketReplayLimit) {
		CacheManager.marketReplayLimit = marketReplayLimit;
	}
	public static IgniteCache<?, ?> getIgniteCache() {
		return igniteCache;
	}
	public static void setIgniteCache(IgniteCache<?, ?> igniteCache) {
		CacheManager.igniteCache = igniteCache;
	}
	public static IgniteCache<?, ?> getIgniteEventCache() {
		return igniteEventCache;
	}
	public static void setIgniteEventCache(IgniteCache<?, ?> igniteEventCache) {
		CacheManager.igniteEventCache = igniteEventCache;
	}
	public static BusinessDateVO getBusinessDateVO() {
		return businessDateVO;
	}
	public static void setBusinessDateVO(BusinessDateVO businessDateVO) {
		CacheManager.businessDateVO = businessDateVO;
	}
	public static Map<String, Map<String, String>> getStaticReferenceLOV() {
		return staticReferenceLOV;
	}
	public static void setStaticReferenceLOV(Map<String, Map<String, String>> staticReferenceLOV) {
		CacheManager.staticReferenceLOV = staticReferenceLOV;
	}
	public static Map<String, Integer> getMarketReplayMapping() {
		return marketReplayMapping;
	}
	public static void setMarketReplayMapping(Map<String, Integer> marketReplayMapping) {
		CacheManager.marketReplayMapping = marketReplayMapping;
	}
	public static Map<String, String> getSqlQueryMap() {
		return sqlQueryMap;
	}
	public static void setSqlQueryMap(Map<String, String> sqlQueryMap) {
		CacheManager.sqlQueryMap = sqlQueryMap;
	}
	public static Map<String, String> getCacheQueryMap() {
		return cacheQueryMap;
	}
	public static void setCacheQueryMap(Map<String, String> cacheQueryMap) {
		CacheManager.cacheQueryMap = cacheQueryMap;
	}
}