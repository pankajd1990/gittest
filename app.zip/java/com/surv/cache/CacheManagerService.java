package com.surv.cache;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.ignite.Ignite;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.DataStorageConfiguration;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.spi.communication.tcp.TcpCommunicationSpi;
import org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.ipfinder.vm.TcpDiscoveryVmIpFinder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.surv.config.IgniteProperties;
import com.surv.config.NgsConfig;
import com.surv.config.SqlConfig;
import com.surv.config.StaticReference;
import com.surv.constant.StaticConstants;
import com.surv.service.marketreplay.BusinessDateService;
import com.surv.utility.Logger;
import com.surv.utility.MasterUtil;
import com.surv.utility.common.RequestContext;

@Service("cacheManagerService")
public class CacheManagerService {

	@Autowired
	public NgsConfig ngsConfig;
	
	@Autowired
	private SqlConfig sqlConfig;
	
	@Autowired
	public RequestContext requestContext;

	@Autowired
	@Qualifier(value = "staticReference")
	public StaticReference staticReference;

	@Autowired
	@Qualifier("igniteProperties")
	private IgniteProperties igniteProperties;

	@Autowired
	@Qualifier(value = "businessDateService")
	public BusinessDateService businessDateService;

	public void initCacheManager(boolean startIgniteCache) {
		try {
			MasterUtil.requestContext = requestContext;

			CacheManager.authServer = loadAuthServerUrl();
			CacheManager.sqlQueryMap = loadSqlQuery();
			CacheManager.cacheQueryMap = loadCacheQuery();
			CacheManager.marketReplayMapping = loadMarketReplayMapping();
			CacheManager.staticReferenceLOV = staticReference.initStaticReference();
			CacheManager.businessDateVO = businessDateService.getBusinessDateDetails();

			if(startIgniteCache) {
				startIgniteCache();
			}

		} catch (Exception e) {
			Logger.EXCEPTION.error("Error while load cache details.", e.getMessage()); 
		}
	}

	private String loadAuthServerUrl() {
		Map<String, String> map = ngsConfig.getOauth();
		
		StringBuilder builder = new StringBuilder();
		builder.append("http://");
		builder.append(map.get("hostname"));
		builder.append("/");
		builder.append(map.get("rest"));
		builder.append("/");
		builder.append(map.get("method"));
		
		return builder.toString();
	}

	private Map<String, Integer> loadMarketReplayMapping() {
		try {
			Map<String, Integer> map = new HashMap<>();
			ClassLoader classloader = Thread.currentThread().getContextClassLoader();
			InputStream inputStream = classloader.getResourceAsStream(StaticConstants.MR_MAPPING_FILE_NAME);

			Properties properties = new Properties();
			properties.load(inputStream);

			if(!properties.isEmpty()) {
				for(int i = 0; i < properties.size(); i++) {
					map.put(properties.get(StaticConstants.BLANK + i) != null ? properties.get(StaticConstants.BLANK + i).toString().trim().toUpperCase() : StaticConstants.BLANK, i);
				}
			}

			inputStream.close();

			return map;
		} catch (Exception e) {
			Logger.EXCEPTION.error("Error while load cache details.", e.getMessage()); 
		}
		return null;
	}

	private Map<String, String> loadSqlQuery() {
		try {
			Properties properties = MasterUtil.loadPropertieFile("query.properties");
			if(properties == null) {
				throw new IOException("CacheManagerService > loadSqlQuery :: Properties object is NULL.");
			}

			Set<Object> set = properties.keySet();
			Map<String, String> map = new HashMap<>();
			for (Object object : set) {
				String key = object.toString();
				map.put(key.trim().toUpperCase(), properties.getProperty(key).toString().trim().toUpperCase());
			}
			return map;
		} catch (IOException e) {
			Logger.EXCEPTION.error("CacheManagerService > loadSqlQuery :: Error while load cache details - ", e.getMessage());
		}
		return null;
	}

	private Map<String, String> loadCacheQuery() {
		try {
			Properties properties = MasterUtil.loadPropertieFile("cacheQuery.properties");
			if(properties == null) {
				throw new IOException("CacheManagerService > loadCacheQuery :: Properties object is NULL.");
			}

			Set<Object> set = properties.keySet();
			Map<String, String> map = new HashMap<>();
			for (Object object : set) {
				String key = object.toString();
				map.put(key.trim().toUpperCase(), properties.getProperty(key).toString().trim());
			}
			return map;
		} catch (IOException e) {
			Logger.EXCEPTION.error("CacheManagerService > loadCacheQuery :: Error while load cache details - ", e.getMessage());
		}
		return null;
	}
	
	private void startIgniteCache() {
		try {
			Ignite ignite = null;
			/*TcpDiscoveryVmIpFinder tcpDiscoveryVmIpFinder = new TcpDiscoveryVmIpFinder();
			tcpDiscoveryVmIpFinder.setAddresses(igniteProperties.getIps());

			TcpDiscoverySpi tcpDiscoverySpi = new TcpDiscoverySpi();
			tcpDiscoverySpi.setIpFinder(tcpDiscoveryVmIpFinder);

			IgniteConfiguration igniteConfiguration = new IgniteConfiguration();
			igniteConfiguration.setPeerClassLoadingEnabled(true);
			igniteConfiguration.setDiscoverySpi(tcpDiscoverySpi);
			igniteConfiguration.setPublicThreadPoolSize(Integer.valueOf(16));
			igniteConfiguration.setSystemThreadPoolSize(Integer.valueOf(16));
			igniteConfiguration.setClientMode(true);

			Ignite ignite = Ignition.getOrStart(igniteConfiguration);*/

			TcpDiscoverySpi spi = new TcpDiscoverySpi();
			spi.setLocalPort(Integer.valueOf(igniteProperties.getConfig().get("discoverySpiPort")));
			spi.setLocalPortRange(Integer.valueOf(igniteProperties.getConfig().get("discoverySpiPortRange")));

			TcpDiscoveryVmIpFinder ipFinder = new TcpDiscoveryVmIpFinder();
			ipFinder.setAddresses(igniteProperties.getIps());

			spi.setIpFinder(ipFinder);
			IgniteConfiguration igniteConfiguration = new IgniteConfiguration();
			igniteConfiguration.setPeerClassLoadingEnabled(true);
			//igniteConfiguration.setIgniteInstanceName("collector-caches");
			igniteConfiguration.setDiscoverySpi(spi);

			igniteConfiguration.setClientMode(true);

			//igniteConfiguration.setClientMode(false);

			igniteConfiguration.setFailureDetectionTimeout(90000);

			DataStorageConfiguration storageCfg = new DataStorageConfiguration();
			// storageCfg.setPageSize(4096);
			storageCfg.getDefaultDataRegionConfiguration().setInitialSize(1L * 1024 * 1024 * 1024);
			// Setting the size of the default memory region to *GB to achieve
			// this.
			/*
			 * storageCfg.getDefaultDataRegionConfiguration() .setMaxSize(1L *
			 * 1024 * 1024 * 1024);
			 */

			//storageCfg.getDefaultDataRegionConfiguration().setInitialSize(Long.valueOf(igniteProperties.getIgnite().get("regionInitialSize")) * 1024 * 1024 * 1024);

			// Externalise max region size
			storageCfg.getDefaultDataRegionConfiguration().setMaxSize(Long.valueOf(igniteProperties.getIgnite().get("regionMaxSize")) * 1024 * 1024 * 1024);

			igniteConfiguration.setDataStorageConfiguration(storageCfg);

			TcpCommunicationSpi commSpi = new TcpCommunicationSpi();
			commSpi.setLocalPort(Integer.valueOf(igniteProperties.getConfig().get("commSpiPort")));
			commSpi.setMessageQueueLimit(1024);
			commSpi.setSocketWriteTimeout(10000L);
			igniteConfiguration.setCommunicationSpi(commSpi);

			// All properties should be in YAML
			igniteConfiguration.setDiscoverySpi(spi);

			ignite = Ignition.getOrStart(igniteConfiguration);
			Ignite igniteEventCache = Ignition.getOrStart(igniteConfiguration);
			Ignite igniteMrRequest = Ignition.getOrStart(igniteConfiguration);

			CacheManager.igniteCache = ignite.cache(this.sqlConfig.getCacheQuery("MRMARKETREPLYCACHE"));
			CacheManager.igniteEventCache = igniteEventCache.cache(this.sqlConfig.getCacheQuery("MDEVENTCACHE"));
			CacheManager.igniteMrRequest = igniteMrRequest.cache(this.sqlConfig.getCacheQuery("MRREQUESTCACHE"));


		} catch (Exception e) {
			Logger.EXCEPTION.error("Error while load cache details.", e.getMessage()); 
		}
	}

	public RequestContext getRequestContext() {
		return requestContext;
	}

	public void setRequestContext(RequestContext requestContext) {
		this.requestContext = requestContext;
	}


}