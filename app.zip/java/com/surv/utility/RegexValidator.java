package com.surv.utility;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexValidator {
	public RegexValidator(){
		 pattern = Pattern.compile(TIME24HOURS_PATTERN);
	}
	private  Pattern pattern;
	private  Matcher matcher;
	private static final String TIME24HOURS_PATTERN = "(^([0-1]?\\d|2[0-3]):([0-5]?\\d):([0-5]?\\d)$)|(^([0-5]?\\d):([0-5]?\\d)$)|(^[0-5]?\\d$)";
	
	
	
	 /**
	   * Validate time in 24 hours format with regular expression
	   * @param time time address for validation
	   * @return true valid time fromat, false invalid time format
	   */
	  public  boolean validate(String time){
		  matcher = pattern.matcher(time);
		  return matcher.matches();
	    	    
	  }
	
}