package com.surv.utility;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import com.surv.cache.CacheManager;
import com.surv.constant.StaticConstants;
import com.surv.entity.admin.UadUserVO;
import com.surv.exception.ServiceException;
import com.surv.exception.ValidationException;

public class Util {

	public static UadUserVO getUserDetails() {
		return MasterUtil.getUserDetailCache();
	}

	public static String getLogonUserId() {
		return getUserDetails().getUadUserId();
	}

	public static Long getLogonUserGroupNum() {
		return getUserDetails().getUadUserGroupNum();
	}

	public static Long getLogonUserType() {
		return getUserDetails().getUadUserType();
	}

	public static String toJSONStringFromList(Collection<?> list) throws ServiceException {
		try {
			JSONArray jsonArray = new JSONArray();
			for (Object object : list) {
				if (object != null) {
					JSONObject jsonObject = new JSONObject();
					if (object.getClass().isArray()) {
						Object[] tempX = (Object[]) object;
						jsonObject.put("key", tempX[0]);
						jsonObject.put("value", tempX[1]);
					} else {
						jsonObject.put("key", object.toString());
						jsonObject.put("value", object.toString());
					}
					jsonArray.put(jsonObject);
				}
			}
			return jsonArray.toString();
		}catch (Exception e) {
			Logger.EXCEPTION.error("Error in Convert Map to JSonArray String", e.getMessage());
			throw new ServiceException("Error in Convert Map to JSonArray String");
		}
	}

	public static String toJSONStringFromListNew(Collection<?> list) throws ServiceException {
		try {
			JSONArray jsonArray = new JSONArray();
			for (Object object : list) {
				if (object != null) {
					JSONObject jsonObject = new JSONObject();
					if (object.getClass().isArray()) {
						Object[] tempX = (Object[]) object;

						if(tempX.length > 1) {
							jsonObject.put("key", tempX[0]);
							jsonObject.put("value", tempX[1]);
						}else {
							jsonObject.put("key", tempX[0]);
							jsonObject.put("value", tempX[0]);
						}
					} else {
						jsonObject.put("key", object.toString());
						jsonObject.put("value", object.toString());
					}
					jsonArray.put(jsonObject);
				}
			}
			return jsonArray.toString();
		}catch (Exception e) {
			Logger.EXCEPTION.error("Error in Convert Map to JSonArray String", e.getMessage());
			e.printStackTrace();
			throw new ServiceException("Error in Convert Map to JSonArray String");
		}
	}

	public static String toJSONStringFromMap(Map<String, String> map) throws ServiceException {
		try {
			JSONArray jarray = new JSONArray();
			for (String attrbId : map.keySet()) {
				JSONObject jobj = new JSONObject();
				jobj.put("key", attrbId);
				jobj.put("value", map.get(attrbId));
				jarray.put(jobj);
			}
			return jarray.toString();
		}catch (Exception e) {
			Logger.EXCEPTION.error("Error in Convert Map to JSonArray String", e.getMessage());
			throw new ServiceException("Error in Convert Map to JSonArray String");
		}
	}

	public static String getStringValue(String value) {
		return value != null && !value.isEmpty() && !value.trim().equals("") ? value : null;
	}

	public static Boolean isValidString(String value) {
		return getStringValue(value) != null ? true : false;
	}

	public static String getDateTimeString(Date date) {
		if(date != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			String formattedDate = formatter.format(date);
			return formattedDate;
		}
		return StaticConstants.BLANK;
	}

	public static String getDateString(Date date) {
		if(date != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
			String formattedDate = formatter.format(date);
			return formattedDate;
		}
		return StaticConstants.BLANK;
	}

	public static String convertTimeStamToDate(String time) {
		String dateString  = time.split(" ")[0];
		String year = dateString.split("-")[0];
		String month = dateString.split("-")[1];

		if(month.equals("01")){ month="Jan";}
		else if(month.equals("02")){month="Feb";}
		else if(month.equals("03")){month="Mar";}
		else if(month.equals("04")){month="Apr";}
		else if(month.equals("05")){month="May";}
		else if(month.equals("06")){month="Jun";}
		else if(month.equals("07")){month="Jul";}
		else if(month.equals("08")){month="Aug";}
		else if(month.equals("09")){month="Sep";}
		else if(month.equals("10")){month="Oct";}
		else if(month.equals("11")){month="Nov";}
		else if(month.equals("12")){month="Dec";}

		String date = dateString.split("-")[2];
		date = date+"-"+month+"-"+year;
		return date;
	}

	public static Date getStringTime(String time) {
		if(time == null)
			return null;
		if(time.split(":").length == 2) 
			time += ":00";
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
		Date fromTime = new Date();
		try {
			fromTime = formatter.parse(time);
		} catch (ParseException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			e.printStackTrace();
		} 
		return fromTime;
	}

	public static Date getStringDate(String time) {
		if(time == null)
			return null;
		String date = time.split("-")[0];
		String month = time.split("-")[1];
		String year = time.split("-")[2];
		time = year+"-"+month+"-"+date;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date fromTime = new Date();
		try {
			fromTime      = formatter.parse(time);
		} catch (ParseException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			e.printStackTrace();
		} 
		return fromTime;
	}

	public static String getStringByDate(Date date) {
		if(date == null)
			return null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = formatter.format(date);
		return dateString;
	}

	public static String getDateYYYYMMDD(Date date) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String dtString = formatter.format(date);
		return dtString;
	}

	public static String upperCase(String str) {
		if(str == null)
			return null;
		return str.toUpperCase();
	}

	public static String getTimeString(Date date) {
		if(date == null)
			return "";
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
		String formattedDate = formatter.format(date);
		return formattedDate;
	}

	public static String getTimeStringFromTimeStamp(Date date) {
		if(date == null)
			return "";
		Date dt = new Date();
		dt.setTime(date.getTime());
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		String formattedDate = formatter.format(dt);
		return formattedDate.split(" ")[1];
	}

	public static Date getStringDate1(String time) {

		String date = time.split("-")[0];
		String month = time.split("-")[1];

		if(month.equals("Jan")){month="01";}
		else if(month.equals("Feb")){month="02";}
		else if(month.equals("Mar")){month="03";}
		else if(month.equals("Apr")){month="04";}
		else if(month.equals("May")){month="05";}
		else if(month.equals("Jun")){month="06";}
		else if(month.equals("Jul")){month="07";}
		else if(month.equals("Aug")){month="08";}
		else if(month.equals("Sep")){month="09";}
		else if(month.equals("Oct")){month="10";}
		else if(month.equals("Nov")){month="11";}
		else if(month.equals("Dec")){month="12";}

		String year = time.split("-")[2];
		time = year+"-"+month+"-"+date;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date fromTime = new Date();
		try {
			fromTime = formatter.parse(time);
		} catch (ParseException e) {
			Logger.EXCEPTION.error("", e.getMessage());
			e.printStackTrace();
		} 
		return fromTime;
	}

	public static java.sql.Timestamp dateToSqlDate(Date dt) {
		return new java.sql.Timestamp(dt.getTime());
	}

	public static java.sql.Date dateToSqlDateOnly(Date dt) {
		return new java.sql.Date(dt.getTime());
	}

	public static java.math.BigDecimal numericToBigDecimal(BigDecimal bd) {
		return new java.math.BigDecimal(bd.doubleValue());
	}

	public static String toStringListJSONArray(List<Object[]> list) throws ServiceException{
		List<String> resultList = new ArrayList<>();
		for(Object[] array : list) {
			resultList.add(array[0].toString());
		}
		return toJSONStringFromList(resultList);
	}

	public static String listToString(List<String> list){
		if(list!=null){
			String listString = String.join(",", list);
			return listString;
		}
		return null;
	}

	private static String getValidObjectValue(Object[] objectArray, String fieldName) throws ValidationException {
		if(objectArray != null && objectArray.length > 0) {
			if(CacheManager.marketReplayMapping.get(fieldName.toUpperCase()) != null) {
				if(objectArray[CacheManager.marketReplayMapping.get(fieldName.toUpperCase())] != null) {
					return objectArray[CacheManager.marketReplayMapping.get(fieldName.toUpperCase())].toString().trim();
				}else {
					return null;
				}
			}
		}
		throw new ValidationException("no data found in object array...!!!");
	}

	public static String getStringValue(Object object) throws ValidationException {
		return object != null ? object.toString().trim() : "";
	}

	public static String getStringValue(Object[] object, String fieldName) throws ValidationException {
		return getValidObjectValue(object, fieldName) != null ? getValidObjectValue(object, fieldName) : "";
	}

	public static Integer getIntegerValue(Object object) throws ValidationException {
		return object != null ? Integer.parseInt(object.toString().trim()) : null;
	}

	public static Integer getIntegerValue(Object[] object, String fieldName) throws ValidationException {
		return getValidObjectValue(object, fieldName) != null ? Integer.parseInt(getValidObjectValue(object, fieldName)) : null;
	}

	public static Long getLongValue(Object object) throws ValidationException {
		return object != null ? Long.parseLong(object.toString().trim()) : null;
	}

	public static Long getLongValue(Object[] object, String fieldName) throws ValidationException {
		return getValidObjectValue(object, fieldName) != null ? Long.parseLong(getValidObjectValue(object, fieldName)) : null;
	}

	public static Double getDoubleValue(Object object) throws ValidationException {
		return object != null ? Double.parseDouble(object.toString().trim()) : null;
	}

	public static Double getDoubleValue(Object[] object, String fieldName) throws ValidationException {
		return getValidObjectValue(object, fieldName) != null ? Double.parseDouble(getValidObjectValue(object, fieldName)) : null;
	}

	public static Date getDateValue(Object object) throws ValidationException, ParseException {
		return object != null ? CacheManager.dateFormat.parse(object.toString().trim()) : null;
	}

	public static Date getDateValue(Object[] object, String fieldName) throws ParseException, ValidationException {
		return getValidObjectValue(object, fieldName) != null ? CacheManager.dateFormat.parse(getValidObjectValue(object, fieldName)) : null;
	}

	public static String getTradeLogData(Object[] object, String fieldName) throws NumberFormatException, ValidationException {
		return getValidObjectValue(object, fieldName) != null ? String.format("%.2f", getRoundTwoDecimal(Double.parseDouble(getValidObjectValue(object, fieldName)))) : "0.00";
	}

	public static Double getRoundTwoDecimal(Double value) {
		return Math.round(value * 100.0) / 100.0;
	}

	public static String convertArrayToString(String[] array){
		if(array != null && array.length > 0) {
			return String.join(",", array); 
		}
		return null;
	}

	public static String[] convertStringToArray(String string){
		if(string != null && !string.isEmpty()) {
			return string.split(","); 
		}
		return null;
	}

	public static java.sql.Date utilToSqlDate(Date dt) {
		return new java.sql.Date(dt.getTime());
	}

}