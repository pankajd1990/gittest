package com.surv.utility;

import org.slf4j.LoggerFactory;

import com.surv.constant.StaticConstants;

public class Logger {

	public static final org.slf4j.Logger STARTUP = LoggerFactory.getLogger(StaticConstants.STARTUP_LOG);
	public static final org.slf4j.Logger EXCEPTION = LoggerFactory.getLogger(StaticConstants.EXCEPTION_LOG);
	public static final org.slf4j.Logger REQ_RES = LoggerFactory.getLogger(StaticConstants.REQRES_LOG);
	public static final org.slf4j.Logger MASTER = LoggerFactory.getLogger(StaticConstants.MASTER_LOG);

}