package com.surv.utility.common;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;

@Component
public interface RequestContext {

	public HttpServletRequest getRequest();

	public Object getContext();

}