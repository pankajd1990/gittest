package com.surv.utility;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.surv.cache.CacheManager;
import com.surv.entity.admin.UadUserVO;
import com.surv.utility.common.RequestContext;

public class MasterUtil {

	public static RequestContext requestContext;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static UadUserVO getUserDetailCache() {
		try {
			String params = requestContext.getRequest().getHeader("random-finger");

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add("Content-Type", "application/json"); 

			HttpEntity<String> httpEntity = new HttpEntity<String>(params, httpHeaders);

			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<Map> responseEntity = restTemplate.exchange(CacheManager.authServer, HttpMethod.POST, httpEntity, Map.class);

			if(responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
				Map<String, Object> map = (Map<String, Object>) responseEntity.getBody();
				if(map != null && map.size() > 0) {
					if(map.get("UadUserVO") != null) {
						ObjectMapper mapper = new ObjectMapper();
						UadUserVO uadUserVO = mapper.convertValue(map.get("UadUserVO"), UadUserVO.class);
						return uadUserVO;
					}
				}
			}	
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static Properties loadPropertieFile(String fileName) throws IOException {
		InputStream inputStream = null;
		try {
			ClassLoader classloader = Thread.currentThread().getContextClassLoader();
			inputStream = classloader.getResourceAsStream(fileName);

			Properties properties = new Properties();
			properties.load(inputStream);

			if(properties == null || properties.isEmpty()) {
				return null;
			}
			return properties;

		} catch (Exception e) {
			Logger.EXCEPTION.error("Util > loadPropertieFile :: Error while load query properties - ", e.getMessage());
		}finally {
			inputStream.close();
		}
		return null;
	}

	public static String queryGenerater(String query, Map<String, Object> map) {
		query = query.toUpperCase();

		if(map != null) {
			for(Entry<String, Object> entry : map.entrySet()) {
				if(entry.getValue() instanceof String) {
					query = query.replace(":" + entry.getKey().trim().toUpperCase(), "'"+entry.getValue().toString()+"'");
				}
				else if(entry.getValue() instanceof Date) {
					query = query.replace(":" + entry.getKey().trim().toUpperCase(), "'"+entry.getValue().toString()+"'");
				}
				else  {
					query = query.replace(":" + entry.getKey().trim().toUpperCase(), entry.getValue().toString());
				}
			}
		}
		return query;
	}
}