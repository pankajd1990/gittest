package com.surv.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

import com.surv.cache.CacheManager;
import com.surv.cache.CacheManagerService;
import com.surv.constant.StaticConstants;
import com.surv.constant.StaticMsgConstants;
import com.surv.entity.marketreplay.AlertRuleThresholdDetailVO;
import com.surv.entity.marketreplay.AlertRuleVO;
import com.surv.entity.marketreplay.MktwtchHighlightVO;
import com.surv.entity.marketreplay.MktwtchSelectCriteriaVO;
import com.surv.entity.marketreplay.SCmSecurityMasterVO;
import com.surv.entity.marketreplay.WhatifOrderFilterVO;
import com.surv.entity.marketreplay.WhatifSelectCriteria;
import com.surv.exception.ServiceException;
import com.surv.json.ResponseSetter;
import com.surv.json.ResponseVO;
import com.surv.service.marketreplay.MarketReplayService;
import com.surv.service.marketreplay.ReplayCriteriaService;
import com.surv.service.marketreplay.SetThresholdService;
import com.surv.service.marketreplay.WhatIfService;
import com.surv.utility.Logger;


@Controller("marketReplayController")
public class MarketReplayController {

	@Autowired
	@Qualifier(value = "marketReplayService")
	private MarketReplayService marketReplayService;

	@Autowired
	@Qualifier(value = "replayCriteriaService")
	private ReplayCriteriaService replayCriteriaService;

	@Autowired
	@Qualifier(value = "setThresholdService")
	private SetThresholdService setThresholdService;

	@Autowired
	@Qualifier(value = "whatIfService")
	private WhatIfService whatIfService;
	@Autowired
	@Qualifier(value = "cacheManagerService")
	protected CacheManagerService cacheManagerService;

	/**
	 * START
	 * Market Replay
	 * @author Durgesh Jain
	 */
	public ResponseVO playMarketReplay(Long runId,Integer mrSeqNmbr) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.marketReplayService.playMarketReplay(runId,mrSeqNmbr, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage()); 
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());

		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage()); 
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO marketReplayPopupGridDataCount(String flag, Long runId, Integer mrSeqNmbr, Double limitPrice,Integer thresholdQty,Integer thresholdCxlQty ,Integer mrStartSeqNmbr ) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.marketReplayService.marketReplayPopupGridDataCount(flag, runId, mrSeqNmbr, limitPrice ,thresholdQty,thresholdCxlQty, mrStartSeqNmbr, responseVO );
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage()); 
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());

		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage()); 
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO marketReplayPopupGridData(String flag, Long runId, Integer mrSeqNmbr, Double limitPrice,Integer thresholdQty,Integer thresholdCxlQty ,Integer mrStartSeqNmbr,Integer pageSize ,Integer from  ) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.marketReplayService.marketReplayPopupGridData(flag, runId, mrSeqNmbr, limitPrice ,thresholdQty,thresholdCxlQty, mrStartSeqNmbr ,pageSize,from, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage()); 
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());

		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage()); 
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO pushMrRequestCache(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.pushMrRequestCache(mktwtchSelectCriteriaVO, responseVO);
		}catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage()); 
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());

		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getStatusCache(Integer mwscrRunId) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.getStatusCache(mwscrRunId, responseVO);
		}catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage()); 
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());

		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getHighlightCondition(MktwtchHighlightVO mktwtchHighlightVO){
		ResponseVO responseVO = new ResponseVO();
		try{
			this.marketReplayService.getHighlightCondition(mktwtchHighlightVO, responseVO);
		}catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO submitHighlightCondition(MktwtchHighlightVO mktwtchHighlightVO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.marketReplayService.submitHighlightCondition(mktwtchHighlightVO, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage()); 
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());

		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage()); 
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	/**
	 * START
	 * Replay Criteria
	 * @author Kalpana
	 */

	public ResponseVO getMarketWatchGridCount(String runId) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.getMarketWatchGridCount(runId, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getMarketWatchGridData(String runId, int from, int recCount) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.getMarketWatchGridData(runId, from,recCount, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getQueryGridCount(Date mwscrBussDate) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.getQueryGridCount(mwscrBussDate, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getQueryGridData(Date mwscrBussDate, int from, int recCount) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.getQueryGridData(mwscrBussDate, from,recCount, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getIndexLovdata(Date runDate) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.getIndexLovdata(runDate, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getRunId() {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.getRunId(responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getReplyCriteria() {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.getReplyCriteria(responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getSymbolSeriesCount(SCmSecurityMasterVO sCmSecurityMasterVO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.getSymbolSeriesCount(sCmSecurityMasterVO, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;

	}

	public ResponseVO getSymbolSeriesData(SCmSecurityMasterVO sCmSecurityMasterVO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.getSymbolSeriesData(sCmSecurityMasterVO, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;

	}

	public ResponseVO modifyReplayCriteria(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.modifyReplayCriteria(mktwtchSelectCriteriaVO, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	//	public ResponseVO modifyStatus(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) {
	//		try {
	//			this.replayCriteriaService.pushMrRequestCache(mktwtchSelectCriteriaVO);
	//		} catch (ServiceException e) {
	//			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
	//			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
	//		} catch (Exception e) {
	//			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
	//			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
	//		}
	//		return responseVO;
	//	}

	public ResponseVO addReplayCriteria(MktwtchSelectCriteriaVO mktwtchSelectCriteriaVO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.addReplayCriteria(mktwtchSelectCriteriaVO, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getMinRunDate() {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.replayCriteriaService.getMinRunDate(responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}
	/**
	 * End Select Criteria
	 */


	/**
	 * START
	 * Set Threshold
	 * @author Shivangi/Swati
	 */

	public ResponseVO getAllAlerts() {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.setThresholdService.getAllAlerts(responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO searchAlertCountData(List<String> ruleName) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.setThresholdService.searchAlertCountData(ruleName, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO searchAlertData(List<String> ruleName, int from, int recCount) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.setThresholdService.searchAlertData(ruleName, from, recCount, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO searchSelectedCountData(List<AlertRuleVO> listAlertDetails) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.setThresholdService.searchSelectedCountData(listAlertDetails, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}

		return responseVO;
	}

	public ResponseVO searchSelectedData(List<AlertRuleVO> listAlertDetails, int from, int recCount) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.setThresholdService.searchSelectedData(listAlertDetails, from, recCount, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}

		return responseVO;
	}

	public ResponseVO updateData(List<AlertRuleThresholdDetailVO> listUpdateDetails) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.setThresholdService.updateData(listUpdateDetails, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}
	/**
	 * END
	 * Alert Rule
	 * @author Shivangi and Swati
	 */

	/**
	 * START
	 * What-If
	 * @author Swati
	 */

	public ResponseVO getAllRunId() {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.getAllRunId(responseVO);
		} catch (ServiceException e) {
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO searchRunCount(String runId) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.searchRunCount(runId, responseVO);
		} catch (ServiceException e) {
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}
	public ResponseVO searchRunIdData(String runId, int from, int recCount) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.searchRunIdData(runId, from, recCount, responseVO);
		} catch (ServiceException e) {
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getActionLOV() {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.getActionLOV(responseVO);
		} catch (ServiceException e) {
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getAddLOV() {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.getAddLOV(responseVO);
		} catch (ServiceException e) {
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO addNewOrd(WhatifOrderFilterVO whatifOrderFilterVO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.addNewOrd(whatifOrderFilterVO, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,StaticMsgConstants.ERR_SYSTEM_ERROR,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO addModOrd(WhatifOrderFilterVO whatifOrderFilterVO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.addModOrd(whatifOrderFilterVO, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,StaticMsgConstants.ERR_SYSTEM_ERROR,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO addRemoveOrd(WhatifOrderFilterVO whatifOrderFilterVO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.addRemoveOrd(whatifOrderFilterVO, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,StaticMsgConstants.ERR_SYSTEM_ERROR,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO ModNewOrd(WhatifOrderFilterVO whatifOrderFilterVO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.ModNewOrd(whatifOrderFilterVO, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,StaticMsgConstants.ERR_SYSTEM_ERROR,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO ModModOrd(WhatifOrderFilterVO whatifOrderFilterVO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.ModModOrd(whatifOrderFilterVO, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,StaticMsgConstants.ERR_SYSTEM_ERROR,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO ModRemoveOrd(WhatifOrderFilterVO whatifOrderFilterVO) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.ModRemoveOrd(whatifOrderFilterVO, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,StaticMsgConstants.ERR_SYSTEM_ERROR,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO deleteOrderFilter(int whatifFilterNumber, int whatifRunId) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.deleteOrderFilter(whatifFilterNumber, whatifRunId, responseVO);
		} catch (ServiceException e) {
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	/**
	 * END
	 * What-If
	 * @author Swati
	 */

	/**
	 * START
	 * What-If: What-If Tab
	 * @author Bansari
	 */
	public ResponseVO getWhatIfRunId() {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.getWhatIfRunId(responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getWhatIfGridCount(String runId) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.getWhatIfGridCount(runId, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO getWhatIfGridData(String runId, int from, int recCount) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.getWhatIfGridData(runId, from,recCount, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO addWhatIfData(WhatifSelectCriteria whatifSelectCriteria) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.addWhatIfData(whatifSelectCriteria, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}

	public ResponseVO modifyWhatIfData(WhatifSelectCriteria whatifSelectCriteria) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.whatIfService.modifyWhatIfData(whatifSelectCriteria, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}


	/**
	 * END
	 * What-If: What-If Tab
	 * @author Bansari
	 */
	/**
	 * START
	 * Refresh Cache
	 * @author Durgesh Jain
	 */
	public ResponseVO refreshSystemCache() {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.cacheManagerService.initCacheManager(false);
			ResponseSetter.getResponseString(responseVO,StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, CacheManager.businessDateVO);
		} catch (Exception e) {
			Logger.EXCEPTION.error("",StaticConstants.FAILURE_CODE,StaticMsgConstants.ERR_SYSTEM_ERROR,e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}
		return responseVO;
	}
	/**
	 * END
	 * Refresh Cache
	 * @author Durgesh Jain
	 */

	public ResponseVO playMarketReplaySocket(Integer runId ,Integer mrSeqNmbr , Integer lastSeqNmbr,Integer prevForwardFlag,Integer gotoStartSeqNmbr) {
		ResponseVO responseVO = new ResponseVO();
		try {

			Map<String, Object> map = this.marketReplayService.playMarketReplaySocket(runId, mrSeqNmbr, lastSeqNmbr, prevForwardFlag, gotoStartSeqNmbr);
			ResponseSetter.getResponseString(responseVO,StaticConstants.SUCCESS_CODE, StaticConstants.SUCCESS, map);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}

		return responseVO;
	}

	public ResponseVO goToMarketReplay(Integer mrSeqNmbr, String mrRecordTimeString, String mrPan, Long mrOrderNmbr, Long mrFillNmbr,Integer runId) {
		ResponseVO responseVO = new ResponseVO();
		try {
			this.marketReplayService.goToMarketReplay(mrSeqNmbr,mrRecordTimeString,mrPan,mrOrderNmbr,mrFillNmbr, runId, responseVO);
		} catch (ServiceException e) {
			Logger.EXCEPTION.error(e.getLocalizedMessage(), e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, e.getLocalizedMessage());
		} catch (Exception e) {
			Logger.EXCEPTION.error(StaticMsgConstants.ERR_SYSTEM_ERROR, e.getMessage());
			ResponseSetter.getResponseString(responseVO, StaticConstants.FAILURE_CODE, StaticMsgConstants.ERR_SYSTEM_ERROR);
		}

		return responseVO;
	}

}
